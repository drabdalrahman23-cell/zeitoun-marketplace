"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "./store";
import { Btn, Field, Modal, Select, Spinner, Stars, TextInput, TextArea } from "./ui";
import { api, errMsg } from "@/lib/api";
import { fmtDate, timeAgo } from "@/lib/utils";
import {
  ADOPTION_PHASES,
  phaseIndex,
  phaseProgress,
  type AdoptionStats,
  type FarmerMini,
  type ProgramView,
  type TreeView,
  type UpdateView,
} from "@/lib/adoption-types";

/* ---------------- transparency note (required on program + checkout) ---------------- */

export function TransparencyNote({ compact }: { compact?: boolean }) {
  const { t } = useStore();
  return (
    <div
      className={`rounded-2xl border border-gold-300/60 bg-gold-300/10 ${compact ? "p-3" : "p-4 md:p-5"} text-xs md:text-sm text-ink-700 leading-relaxed`}
    >
      <div className="font-bold text-ink-900 mb-1 flex items-center gap-2">
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-gold-500" strokeWidth="2">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 8v5M12 16.5v.5" strokeLinecap="round" />
        </svg>
        {t("ad_transparency_title")}
      </div>
      {t("ad_transparency_body")}
      {!compact && <p className="mt-2 text-ink-500">{t("ad_yield_note")}</p>}
    </div>
  );
}

/* ---------------- phase timeline ---------------- */

export function PhaseTimeline({ phase, progress, compact }: { phase: string; progress?: number; compact?: boolean }) {
  const { t } = useStore();
  const current = phaseIndex(phase);
  const pct = progress ?? phaseProgress(phase);
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-bold text-ink-400">{t("ad_timeline")}</span>
        <span className="text-xs font-bold text-olive-700">{pct}%</span>
      </div>
      <div className={`h-2 rounded-full bg-cream-200 overflow-hidden ${compact ? "" : "mb-5"}`}>
        <div className="h-full bg-olive-600 rounded-full transition-all" style={{ width: `${pct}%` }} />
      </div>
      {!compact && (
        <ol className="grid sm:grid-cols-3 gap-2">
          {ADOPTION_PHASES.map((p, i) => {
            const done = i <= current;
            return (
              <li
                key={p}
                className={`rounded-xl border px-3 py-2 text-xs font-bold flex items-center gap-2 ${
                  i === current
                    ? "border-olive-600 bg-olive-50 text-olive-900"
                    : done
                      ? "border-cream-200 bg-white text-ink-600"
                      : "border-cream-200 bg-cream-50 text-ink-300"
                }`}
              >
                <span className={done ? "text-olive-600" : ""}>{done ? "●" : "○"}</span>
                {t(`ad_phase_${p}`)}
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

/* ---------------- tree card ---------------- */

export function TreeCard({ tree, onAdopt }: { tree: TreeView; onAdopt?: (t: TreeView) => void }) {
  const { t, d, fmt, lang } = useStore();
  const name = d({ ar: tree.nameAr, en: tree.nameEn }) || tree.treeCode;
  const available = tree.status === "available";
  return (
    <div className="group rounded-3xl border border-cream-200 bg-white overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all flex flex-col">
      <Link href={`/trees/${tree.treeCode}`} className="relative block aspect-[4/3] bg-cream-100 overflow-hidden">
        {tree.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={tree.images[0]} alt={name} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">🌿</div>
        )}
        <div className="absolute top-2.5 start-2.5 flex flex-col gap-1.5 items-start">
          {tree.verified && (
            <span className="rounded-full bg-olive-700 text-cream-50 text-[10px] font-bold px-2.5 py-1 shadow">✓ {t("ad_verified")}</span>
          )}
          {!available && (
            <span className="rounded-full bg-ink-900/80 text-cream-50 text-[10px] font-bold px-2.5 py-1 shadow">
              {t(`ad_status_${tree.status}`)}
            </span>
          )}
        </div>
        <span className="absolute bottom-2.5 end-2.5 rounded-full bg-cream-50/95 px-2.5 py-1 text-[10px] font-bold text-ink-700" dir="ltr">
          {tree.treeCode}
        </span>
      </Link>
      <div className="p-4 flex flex-col gap-2 flex-1">
        <div className="flex items-start justify-between gap-2">
          <Link href={`/trees/${tree.treeCode}`} className="font-display font-bold text-ink-900 leading-snug hover:text-olive-700 line-clamp-2">
            {name}
          </Link>
          {tree.farmer.rating > 0 && <Stars value={tree.farmer.rating} className="shrink-0 mt-1" />}
        </div>
        <div className="text-xs text-ink-400 font-semibold space-y-0.5">
          <div>🧑‍🌾 {tree.farmer.nameEn} {tree.farmer.farmNameEn && `· ${tree.farmer.farmNameEn}`}</div>
          <div>📍 {tree.region ?? tree.farmer.city ?? "Palestine"} · {t("ad_age")}: {tree.approximateAge} {t("ad_years")}</div>
          {tree.oliveVariety && <div>🫒 {t("ad_variety")}: {tree.oliveVariety}</div>}
        </div>
        <div className="rounded-xl bg-cream-100/70 px-3 py-2">
          <PhaseTimeline phase={tree.phase} progress={tree.progressPercent} compact />
          <div className="text-[11px] font-bold text-olive-800">{t(`ad_phase_${tree.phase}`)}</div>
        </div>
        <div className="mt-auto pt-2 flex items-end justify-between gap-2">
          <div>
            <div className="text-[11px] text-ink-400 font-bold">{t("ad_season")} {tree.season}</div>
            <div className="text-[11px] text-ink-400">
              {tree.maxSponsors > 1 ? `${tree.sponsorCount}/${tree.maxSponsors} ${t("ad_sponsors_max")}` : available ? t("ad_status_available") : t("ad_adopted_by")}
            </div>
          </div>
          {available ? (
            <Btn onClick={() => (onAdopt ? onAdopt(tree) : undefined)} className="!px-3.5 !py-2 !text-xs">
              {t("ad_adopt_btn")}
            </Btn>
          ) : (
            <Link href={`/trees/${tree.treeCode}`} className="text-xs font-bold text-olive-700 hover:underline">
              {t("ad_view_farmer")} →
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- farmer card ---------------- */

export function FarmerCard({ farmer, onSupport }: { farmer: FarmerMini; onSupport?: (f: FarmerMini) => void }) {
  const { t, d, lang } = useStore();
  return (
    <div className="group rounded-3xl border border-cream-200 bg-white overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all">
      <Link href={`/farmers/${farmer.slug}`} className="block aspect-[16/10] bg-cream-100 overflow-hidden relative">
        {farmer.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={farmer.images[0]} alt={d({ ar: farmer.nameAr, en: farmer.nameEn })} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">🧑‍🌾</div>
        )}
        <span className="absolute bottom-2.5 start-2.5 rounded-full bg-cream-50/95 px-2.5 py-1 text-[10px] font-bold text-ink-700">
          📍 {farmer.city ?? farmer.region ?? "Palestine"}
        </span>
      </Link>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <Link href={`/farmers/${farmer.slug}`} className="font-display font-bold text-ink-900 hover:text-olive-700 truncate">
            {d({ ar: farmer.nameAr, en: farmer.nameEn })}
          </Link>
          {farmer.rating > 0 && (
            <span className="flex items-center gap-1 shrink-0">
              <Stars value={farmer.rating} />
              <span className="text-[11px] text-ink-400 font-bold">{farmer.rating.toFixed(1)}</span>
            </span>
          )}
        </div>
        {farmer.farmNameEn && <div className="text-xs text-ink-400 mt-0.5 truncate">{d({ ar: farmer.farmNameAr, en: farmer.farmNameEn })}</div>}
        <div className="flex items-center gap-3 mt-2.5 text-[11px] font-bold text-ink-500">
          <span>🌳 {farmer.availableTrees ?? farmer.treeCount} {t("ad_trees_count")}</span>
          <span>🗓️ {farmer.yearsFarming} {t("ad_years_farming")}</span>
        </div>
        <div className="flex gap-2 mt-3.5">
          <Link href={`/farmers/${farmer.slug}`} className="flex-1 text-center rounded-xl border border-cream-300 text-ink-700 font-bold text-xs py-2.5 hover:border-olive-400 transition">
            {t("ad_view_farmer")}
          </Link>
          <button
            onClick={() => onSupport?.(farmer)}
            className="flex-1 rounded-xl bg-olive-700 text-cream-50 font-bold text-xs py-2.5 hover:bg-olive-800 transition"
          >
            {t("ad_support_btn")}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- program card ---------------- */

export function ProgramCard({ program, selected, onSelect }: { program: ProgramView; selected?: boolean; onSelect?: () => void }) {
  const { t, d, fmt } = useStore();
  const price = program.allowPriceOverride && program.customPriceCents ? program.customPriceCents : program.priceCents;
  const Wrapper = onSelect ? "button" : "div";
  return (
    <Wrapper
      onClick={onSelect}
      className={`w-full text-start rounded-2xl border p-4 transition ${
        selected ? "border-olive-600 bg-olive-50 shadow-sm" : "border-cream-200 bg-white hover:border-olive-300"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display font-bold text-ink-900">{d({ ar: program.nameAr, en: program.nameEn })}</h3>
          <p className="text-[11px] font-bold text-olive-700 mt-0.5">
            {program.kind === "tree" ? t("ad_adm_kind_tree") : program.kind === "farmer" ? t("ad_adm_kind_farmer") : t("ad_adm_kind_both")}
            {" · "}
            {program.durationDays} {t("ad_days_n")}
          </p>
        </div>
        <div className="text-end shrink-0">
          <div className="font-display font-bold text-lg text-olive-800">{fmt(price)}</div>
          <div className="text-[10px] text-ink-400 font-bold">{t("ad_renew_price")}: {fmt(program.renewalPriceCents)}</div>
        </div>
      </div>
      {d({ ar: program.descriptionAr, en: program.descriptionEn }) && (
        <p className="text-xs text-ink-600 mt-2.5 leading-relaxed">{d({ ar: program.descriptionAr, en: program.descriptionEn })}</p>
      )}
      {program.benefits?.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {program.benefits.map((b, i) => (
            <li key={i} className="text-xs text-ink-700 flex items-start gap-2">
              <span className="text-olive-600 mt-0.5">✓</span>
              {d(b)}
            </li>
          ))}
        </ul>
      )}
      {program.includedProducts?.length > 0 && (
        <div className="mt-3 pt-3 border-t border-cream-200">
          <div className="text-[11px] font-bold text-ink-400 mb-1.5">{t("ad_included_products")}</div>
          <div className="flex flex-wrap gap-1.5">
            {program.includedProducts.map((p, i) => (
              <span key={i} className="rounded-full bg-cream-100 px-2.5 py-1 text-[11px] font-bold text-ink-700">
                {d({ ar: p.labelAr, en: p.labelEn })} ×{p.qty}
              </span>
            ))}
          </div>
        </div>
      )}
      <div className="mt-3 flex items-center gap-3 text-[11px] font-bold text-ink-500">
        <span>{program.shippingIncluded ? `🚚 ${t("ad_adm_shipping_inc")}` : `🚚 ${t("shipping_fee")}: +`}</span>
        {program.giftEnabled && <span>🎁 {t("ad_gift_option")}</span>}
      </div>
    </Wrapper>
  );
}

/* ---------------- updates list ---------------- */

export function UpdatesList({ updates, showFarmer }: { updates: UpdateView[]; showFarmer?: boolean }) {
  const { t, d, lang } = useStore();
  if (!updates.length)
    return (
      <div className="rounded-2xl border border-dashed border-cream-300 p-6 text-center text-sm text-ink-400">{t("ad_no_updates")}</div>
    );
  return (
    <div className="space-y-3">
      {updates.map((u) => (
        <article key={u.id} className="rounded-2xl border border-cream-200 bg-white p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <h4 className="font-bold text-sm text-ink-900">{d({ ar: u.titleAr, en: u.titleEn })}</h4>
            <span className="text-[11px] text-ink-400 font-semibold">{timeAgo(u.createdAt, lang)}</span>
          </div>
          {showFarmer && (u.farmerNameEn || u.treeCode) && (
            <div className="text-[11px] text-olive-700 font-bold mt-1">
              {u.treeCode ? `${d({ ar: u.treeNameAr ?? "", en: u.treeNameEn ?? "" }) || u.treeCode}` : d({ ar: u.farmerNameAr ?? "", en: u.farmerNameEn ?? "" })}
            </div>
          )}
          {u.image && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={u.image} alt="" loading="lazy" className="mt-3 rounded-xl w-full max-h-64 object-cover" />
          )}
          {u.video && (
            <video src={u.video} controls className="mt-3 rounded-xl w-full max-h-64" />
          )}
          {(u.bodyAr || u.bodyEn) && <p className="text-sm text-ink-600 mt-2.5 leading-relaxed">{d({ ar: u.bodyAr, en: u.bodyEn })}</p>}
          {u.phase && (
            <div className="mt-2.5">
              <span className="rounded-full bg-olive-100 text-olive-800 px-2.5 py-1 text-[11px] font-bold">{t(`ad_phase_${u.phase}`)}</span>
            </div>
          )}
        </article>
      ))}
    </div>
  );
}

/* ---------------- impact stats ---------------- */

export function ImpactStats() {
  const { t, fmt } = useStore();
  const [s, setS] = useState<AdoptionStats | null>(null);
  useEffect(() => {
    fetch("/api/adoption/stats", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then(setS)
      .catch(() => {});
  }, []);
  if (!s) return null;
  const items = [
    { v: s.trees, l: t("ad_trees_sponsored") },
    { v: s.farmers, l: t("ad_farmers_n") },
    { v: s.regions, l: t("ad_regions_n") },
    { v: s.countries, l: t("ad_countries_n") },
    { v: s.sponsors, l: t("ad_sponsors_n") },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {items.map((i, k) => (
        <div key={k} className="rounded-2xl border border-cream-200 bg-white p-4 text-center">
          <div className="font-display text-2xl md:text-3xl font-bold text-olive-800">{i.v.toLocaleString("en-US")}</div>
          <div className="text-[11px] font-bold text-ink-400 mt-1">{i.l}</div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- FAQ ---------------- */

export function FaqSection() {
  const { t } = useStore();
  const [open, setOpen] = useState<number | null>(0);
  const qs = Array.from({ length: 10 }, (_, i) => i + 1);
  return (
    <div className="divide-y divide-cream-200 rounded-2xl border border-cream-200 bg-white overflow-hidden">
      {qs.map((n, i) => (
        <div key={n}>
          <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-start hover:bg-cream-100/50 transition">
            <span className="font-bold text-sm text-ink-900">{t(`ad_faq_q${n}`)}</span>
            <span className={`text-olive-700 transition-transform shrink-0 ${open === i ? "rotate-45" : ""}`}>＋</span>
          </button>
          {open === i && <p className="px-4 pb-4 text-sm text-ink-600 leading-relaxed">{t(`ad_faq_a${n}`)}</p>}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Adoption checkout modal ---------------- */

interface FarmProduct {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  priceCents: number;
  images: string[];
  stock: number;
  weightGrams: number;
}

export function AdoptModal({
  open,
  onClose,
  tree,
  farmer,
  programs,
  products = [],
}: {
  open: boolean;
  onClose: () => void;
  tree?: TreeView | null;
  farmer: FarmerMini | null;
  programs: ProgramView[];
  products?: FarmProduct[];
}) {
  const { t, d, fmt, me, lang, toast } = useStore();
  const router = useRouter();

  const eligible = useMemo(
    () => programs.filter((p) => (tree ? p.kind === "tree" || p.kind === "both" : p.kind === "farmer" || p.kind === "both")),
    [programs, tree],
  );
  const [programId, setProgramId] = useState<number>(eligible[0]?.id ?? 0);
  const [displayName, setDisplayName] = useState("");
  const [isGift, setIsGift] = useState(false);
  const [gift, setGift] = useState({ recipient: "", message: "", occasion: "general", sendAt: "" });
  const [occasions, setOccasions] = useState<{ key: string; nameAr: string; nameEn: string }[]>([]);
  const [picked, setPicked] = useState<Record<number, number>>({});
  const [countries, setCountries] = useState<{ code: string; nameAr: string; nameEn: string }[]>([]);
  const [methods, setMethods] = useState<{ id: number; nameAr: string; nameEn: string }[]>([]);
  const [methodId, setMethodId] = useState(1);
  const [addr, setAddr] = useState({ fullName: "", phone: "", countryCode: "US", country: "", state: "", city: "", addressLine: "", postalCode: "" });
  const [payment, setPayment] = useState<"card" | "cod">("card");
  const [card, setCard] = useState({ name: "", number: "", exp: "", cvc: "" });
  const [shipping, setShipping] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState<{ orderNumber: string; certificateCode: string | null } | null>(null);

  useEffect(() => {
    if (!open) return;
    setProgramId(eligible[0]?.id ?? 0);
    setDone(null);
    setErr("");
    fetch("/api/adoption/occasions").then((r) => (r.ok ? r.json() : null)).then((x) => x?.items && setOccasions(x.items)).catch(() => {});
    fetch("/api/meta").then((r) => (r.ok ? r.json() : null)).then((m) => {
      if (m?.countries) setCountries(m.countries);
      if (m?.shippingMethods) setMethods(m.shippingMethods);
    }).catch(() => {});
  }, [open, eligible]);

  const program = eligible.find((p) => p.id === programId) ?? eligible[0];
  const items = Object.entries(picked).filter(([, q]) => q > 0).map(([id, q]) => ({ productId: Number(id), quantity: q }));
  const itemsSubtotal = items.reduce((s, it) => {
    const p = products.find((x) => x.id === it.productId);
    return s + (p ? p.priceCents * it.quantity : 0);
  }, 0);
  const itemsWeight = items.reduce((s, it) => {
    const p = products.find((x) => x.id === it.productId);
    return s + (p ? p.weightGrams * it.quantity : 0);
  }, 0);
  const programPrice = program ? (program.allowPriceOverride && program.customPriceCents ? program.customPriceCents : program.priceCents) : 0;

  useEffect(() => {
    if (!items.length || !addr.countryCode || !methods.length) {
      setShipping(null);
      return;
    }
    const ctl = new AbortController();
    fetch("/api/shipping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ countryCode: addr.countryCode, weightGrams: itemsWeight, methodId }),
      signal: ctl.signal,
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((q) => setShipping(q?.quoteCents ?? null))
      .catch(() => {});
    return () => ctl.abort();
  }, [items.length, itemsWeight, addr.countryCode, methodId, methods.length]);

  const shippingCost = program?.shippingIncluded ? 0 : shipping ?? 0;
  const total = programPrice + itemsSubtotal + shippingCost;

  const addrOk = !items.length || !!(addr.fullName && addr.phone && addr.countryCode && addr.city && addr.addressLine && addr.postalCode);
  const payOk = payment === "cod" || (card.name.length > 1 && card.number.replace(/\D/g, "").length >= 12 && /^\d{2}\/\d{2}$/.test(card.exp) && card.cvc.length >= 3);

  const submit = async () => {
    if (!me) {
      toast(t("login_required"), "err");
      router.push("/auth/login?next=/adopt");
      return;
    }
    if (!program || !farmer) return;
    if (!addrOk) return setErr(lang === "ar" ? "أكمل عنوان الشحن للمنتجات" : "Complete the shipping address for products");
    if (!payOk) return setErr(lang === "ar" ? "بيانات البطاقة غير صالحة" : "Card details are invalid");
    setBusy(true);
    setErr("");
    try {
      const res = await api("/api/adoption/checkout", {
        body: {
          programId: program.id,
          treeId: tree?.id ?? undefined,
          farmerId: farmer.id,
          displayName: displayName.trim() || undefined,
          isGift,
          giftRecipientName: isGift ? gift.recipient : undefined,
          giftMessage: isGift ? gift.message : undefined,
          giftOccasion: isGift ? gift.occasion : undefined,
          giftSendAt: isGift && gift.sendAt ? gift.sendAt : undefined,
          items,
          address: items.length ? addr : undefined,
          methodId: items.length ? methodId : undefined,
          paymentProvider: payment,
          cardLast4: payment === "card" ? card.number.replace(/\D/g, "").slice(-4) : undefined,
        },
      });
      setDone({ orderNumber: res.orderNumber, certificateCode: res.certificateCode });
      toast(t("ad_t_adopted"));
    } catch (e) {
      setErr(errMsg(e, lang));
    } finally {
      setBusy(false);
    }
  };

  if (!open) return null;

  return (
    <Modal open={open} onClose={onClose} title={tree ? t("ad_adopt_btn") : t("ad_support_btn")}>
      {done ? (
        <div className="text-center anim-pop">
          <div className="w-16 h-16 mx-auto rounded-full bg-olive-700 text-cream-50 flex items-center justify-center text-3xl">🌿</div>
          <h3 className="font-display text-xl font-bold text-ink-900 mt-4">{t("ad_done_title")}</h3>
          <p className="text-sm text-ink-400 mt-2">{t("ad_done_sub")}</p>
          <div className="rounded-2xl border border-cream-200 bg-cream-100/60 p-4 mt-5">
            <div className="text-[11px] font-bold text-ink-400">{t("orders_placed")}</div>
            <div className="font-display font-bold text-lg text-olive-800" dir="ltr">{done.orderNumber}</div>
          </div>
          <div className="flex gap-2 mt-5">
            {done.certificateCode && (
              <Link href={`/certificate/${done.certificateCode}`} className="flex-1 rounded-xl bg-olive-700 text-cream-50 font-bold py-3 hover:bg-olive-800 transition">
                {t("ad_view_cert")}
              </Link>
            )}
            <Link href="/my-trees" className="flex-1 rounded-xl border border-olive-300 text-olive-800 font-bold py-3 hover:bg-olive-50 transition">
              {t("ad_my_trees")}
            </Link>
          </div>
        </div>
      ) : !program ? (
        <div className="text-center py-6 text-sm text-ink-400">{t("ad_no_trees")}</div>
      ) : (
        <div className="space-y-5">
          {tree && (
            <div className="flex items-center gap-3 rounded-2xl bg-cream-100/70 p-3">
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-cream-200 shrink-0">
                {tree.images[0] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={tree.images[0]} alt="" className="w-full h-full object-cover" />
                ) : null}
              </div>
              <div className="min-w-0">
                <div className="font-bold text-sm text-ink-900 truncate">{d({ ar: tree.nameAr, en: tree.nameEn }) || tree.treeCode}</div>
                <div className="text-[11px] text-ink-400 font-bold" dir="ltr">{tree.treeCode} · {tree.region}</div>
              </div>
            </div>
          )}

          <TransparencyNote compact />

          <div>
            <div className="text-sm font-bold text-ink-700 mb-2">{t("ad_program")}</div>
            <div className="space-y-2.5">
              {eligible.map((p) => (
                <ProgramCard key={p.id} program={p} selected={p.id === programId} onSelect={() => setProgramId(p.id)} />
              ))}
            </div>
          </div>

          {tree && (
            <Field label={t("ad_name_tree")} hint={t("ad_name_tree_hint")}>
              <TextInput value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder={d({ ar: tree.nameAr, en: tree.nameEn }) || ""} />
            </Field>
          )}

          {program.giftEnabled && (
            <div className="rounded-2xl border border-cream-200 p-3.5">
              <label className="flex items-center gap-2.5 text-sm font-bold text-ink-700 cursor-pointer">
                <input type="checkbox" checked={isGift} onChange={(e) => setIsGift(e.target.checked)} className="w-4.5 h-4.5 accent-olive-700" />
                🎁 {t("ad_gift_option")}
              </label>
              {isGift && (
                <div className="mt-3.5 space-y-3">
                  <p className="text-[11px] text-ink-400">{t("ad_gift_note")}</p>
                  <div className="grid grid-cols-2 gap-3">
                    <Field label={t("ad_gift_recipient")}>
                      <TextInput value={gift.recipient} onChange={(e) => setGift({ ...gift, recipient: e.target.value })} />
                    </Field>
                    <Field label={t("ad_gift_occasion")}>
                      <Select value={gift.occasion} onChange={(e) => setGift({ ...gift, occasion: e.target.value })}>
                        {occasions.map((o) => (
                          <option key={o.key} value={o.key}>{d({ ar: o.nameAr, en: o.nameEn })}</option>
                        ))}
                      </Select>
                    </Field>
                  </div>
                  <Field label={t("ad_gift_message")}>
                    <TextArea value={gift.message} onChange={(e) => setGift({ ...gift, message: e.target.value })} className="!min-h-[64px]" />
                  </Field>
                  <Field label={t("ad_gift_send_at")}>
                    <TextInput type="date" dir="ltr" value={gift.sendAt} onChange={(e) => setGift({ ...gift, sendAt: e.target.value })} />
                  </Field>
                </div>
              )}
            </div>
          )}

          {products.length > 0 && (
            <div className="rounded-2xl border border-cream-200 p-3.5">
              <div className="text-sm font-bold text-ink-700 mb-1">{t("ad_option_buy")}</div>
              <p className="text-[11px] text-ink-400 mb-3">{t("ad_from_farm")}</p>
              <div className="space-y-2">
                {products.slice(0, 6).map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-cream-100 overflow-hidden shrink-0">
                      {p.images[0] ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                      ) : null}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-ink-900 truncate">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                      <div className="text-[11px] text-ink-400">{fmt(p.priceCents)}</div>
                    </div>
                    <div className="flex items-center rounded-lg border border-cream-300 overflow-hidden">
                      <button onClick={() => setPicked((v) => ({ ...v, [p.id]: Math.max(0, (v[p.id] ?? 0) - 1) }))} className="w-7 h-7 text-ink-600 hover:bg-cream-100">−</button>
                      <span className="w-6 text-center text-xs font-bold">{picked[p.id] ?? 0}</span>
                      <button onClick={() => setPicked((v) => ({ ...v, [p.id]: Math.min(p.stock, (v[p.id] ?? 0) + 1) }))} className="w-7 h-7 text-ink-600 hover:bg-cream-100">+</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {items.length > 0 && (
            <div className="rounded-2xl border border-cream-200 p-3.5 space-y-3">
              <div className="text-sm font-bold text-ink-700">{t("orders_address")}</div>
              <div className="grid grid-cols-2 gap-2.5">
                <TextInput placeholder={t("co_full_name")} value={addr.fullName} onChange={(e) => setAddr({ ...addr, fullName: e.target.value })} />
                <TextInput dir="ltr" placeholder={t("co_phone")} value={addr.phone} onChange={(e) => setAddr({ ...addr, phone: e.target.value })} />
                <Select
                  value={addr.countryCode}
                  onChange={(e) => {
                    const c = countries.find((x) => x.code === e.target.value);
                    setAddr({ ...addr, countryCode: e.target.value, country: c ? d({ ar: c.nameAr, en: c.nameEn }) : "" });
                  }}
                >
                  {countries.map((c) => (
                    <option key={c.code} value={c.code}>{d({ ar: c.nameAr, en: c.nameEn })}</option>
                  ))}
                </Select>
                <TextInput placeholder={t("co_city")} value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} />
                <TextInput className="col-span-2" placeholder={t("co_address")} value={addr.addressLine} onChange={(e) => setAddr({ ...addr, addressLine: e.target.value })} />
                <TextInput dir="ltr" placeholder={t("co_postal")} value={addr.postalCode} onChange={(e) => setAddr({ ...addr, postalCode: e.target.value })} />
                <Select value={methodId} onChange={(e) => setMethodId(Number(e.target.value))}>
                  {methods.map((m) => (
                    <option key={m.id} value={m.id}>{d({ ar: m.nameAr, en: m.nameEn })}</option>
                  ))}
                </Select>
              </div>
            </div>
          )}

          <div className="rounded-2xl border border-cream-200 p-3.5 space-y-2.5">
            <div className="text-sm font-bold text-ink-700">{t("co_step3")}</div>
            <div className="flex gap-2">
              <button onClick={() => setPayment("card")} className={`flex-1 rounded-xl border py-2 text-xs font-bold ${payment === "card" ? "border-olive-600 bg-olive-50 text-olive-900" : "border-cream-300 text-ink-600"}`}>
                💳 {t("co_card_number")}
              </button>
              <button onClick={() => setPayment("cod")} className={`flex-1 rounded-xl border py-2 text-xs font-bold ${payment === "cod" ? "border-olive-600 bg-olive-50 text-olive-900" : "border-cream-300 text-ink-600"}`}>
                💵 {t("co_cod")}
              </button>
            </div>
            {payment === "card" && (
              <div className="grid grid-cols-2 gap-2.5">
                <TextInput className="col-span-2" placeholder={t("co_card_name")} value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} />
                <TextInput className="col-span-2" dir="ltr" placeholder="4242 4242 4242 4242" value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value })} />
                <TextInput dir="ltr" placeholder="MM/YY" value={card.exp} onChange={(e) => setCard({ ...card, exp: e.target.value })} />
                <TextInput dir="ltr" placeholder="CVC" maxLength={4} value={card.cvc} onChange={(e) => setCard({ ...card, cvc: e.target.value })} />
              </div>
            )}
            <p className="text-[10px] text-ink-400">{t("co_payment_sub")}</p>
          </div>

          <div className="rounded-2xl bg-cream-100/70 border border-cream-200 p-3.5 space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-ink-400">{t("ad_program")}</span><b>{fmt(programPrice)}</b></div>
            {itemsSubtotal > 0 && <div className="flex justify-between"><span className="text-ink-400">{t("products")}</span><b>{fmt(itemsSubtotal)}</b></div>}
            {items.length > 0 && (
              <div className="flex justify-between">
                <span className="text-ink-400">{t("shipping_fee")}</span>
                <b>{program?.shippingIncluded ? fmt(0) : shipping === null ? "…" : fmt(shipping)}</b>
              </div>
            )}
            <div className="flex justify-between border-t border-cream-300 pt-2"><span className="font-bold">{t("total")}</span><b className="font-display text-lg">{fmt(total)}</b></div>
          </div>

          {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
          <Btn onClick={submit} disabled={busy} className="w-full">
            {busy ? <><Spinner className="!w-4 !h-4 !text-white" /> {t("co_processing")}</> : `${t("ad_place")} · ${fmt(total)}`}
          </Btn>
        </div>
      )}
    </Modal>
  );
}
