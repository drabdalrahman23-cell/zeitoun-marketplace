"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useStore } from "./store";
import { Btn, EmptyState, Field, Modal, ProductCard, Stars, TextArea, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";
import type { ProductView } from "@/lib/types";
import { fmtDate } from "@/lib/utils";

export interface SellerData {
  id: number;
  slug: string;
  shopName: string;
  region: string | null;
  city: string | null;
  about: string | null;
  story: string | null;
  images: string[];
  rating: number;
  orderCount: number;
  joinedAt: string;
  productCount: number;
}

export function SellerView({ seller, products }: { seller: SellerData; products: ProductView[] }) {
  const { t, lang, me, toast } = useStore();
  const router = useRouter();
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState("");

  const contact = async () => {
    if (!me) {
      toast(t("login_required"), "err");
      return;
    }
    try {
      await api("/api/messages", { body: { sellerId: seller.id } });
      router.push("/messages");
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const submitReport = async () => {
    if (!reason.trim()) return;
    try {
      await api("/api/reports", { body: { targetType: "user", targetId: seller.id, reason } });
      setReportOpen(false);
      setReason("");
      toast(t("msg_reported"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  return (
    <div className="anim-fade-up">
      {/* cover */}
      <div className="h-44 md:h-64 bg-olive-900 relative overflow-hidden">
        {seller.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={seller.images[0]} alt="" className="w-full h-full object-cover opacity-60" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-olive-950/80 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="-mt-10 md:-mt-14 relative">
          <div className="bg-white rounded-3xl border border-cream-200 shadow-sm p-5 md:p-7 flex flex-col md:flex-row gap-5">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-3xl bg-olive-100 border-4 border-white shadow overflow-hidden shrink-0 flex items-center justify-center text-3xl">
              {seller.images[1] ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={seller.images[1]} alt="" className="w-full h-full object-cover" />
              ) : (
                "🫒"
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">{seller.shopName}</h1>
              <div className="flex items-center gap-3 mt-1.5 flex-wrap text-sm text-ink-400 font-semibold">
                <span className="flex items-center gap-1">
                  <Stars value={seller.rating} /> {seller.rating > 0 ? seller.rating.toFixed(1) : "—"}
                </span>
                <span>📍 {seller.city ?? seller.region ?? "Palestine"}</span>
                <span>
                  {t("member_since")} {fmtDate(seller.joinedAt, lang)}
                </span>
              </div>
              {seller.about && <p className="text-sm text-ink-600 mt-3 leading-relaxed max-w-2xl">{seller.about}</p>}
              <div className="flex items-center gap-4 mt-4 flex-wrap">
                <div className="text-center">
                  <div className="font-display font-bold text-lg text-ink-900">{seller.productCount}</div>
                  <div className="text-[11px] text-ink-400 font-bold">{t("products")}</div>
                </div>
                <div className="text-center">
                  <div className="font-display font-bold text-lg text-ink-900">{seller.orderCount}</div>
                  <div className="text-[11px] text-ink-400 font-bold">{t("orders_n")}</div>
                </div>
                <div className="ms-auto flex gap-2">
                  <Btn variant="outline" onClick={contact}>
                    {t("p_contact_seller")}
                  </Btn>
                  <button onClick={() => setReportOpen(true)} className="text-[11px] text-ink-400 hover:text-clay-600 underline underline-offset-2">
                    {t("msg_report")}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {seller.story && (
          <section className="mt-8 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-6">
            <h2 className="font-display text-lg font-bold text-ink-900">{t("sd_story_shop")}</h2>
            <p className="text-ink-700 mt-2 leading-relaxed max-w-3xl whitespace-pre-line">{seller.story}</p>
          </section>
        )}

        <section className="py-8">
          <h2 className="font-display text-xl md:text-2xl font-bold text-ink-900 mb-5">{t("products")}</h2>
          {products.length ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              {products.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
          ) : (
            <EmptyState icon={<span className="text-3xl">🫒</span>} title={t("sd_no_products")} />
          )}
        </section>
      </div>

      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title={t("msg_report")}>
        <Field label={t("msg_report_reason")}>
          <TextArea value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
        <Btn onClick={submitReport} className="w-full mt-4">
          {t("send")}
        </Btn>
      </Modal>
    </div>
  );
}
