"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useStore } from "./store";
import { Btn, Field, Modal, Select, Spinner, TextArea, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";
import { ADOPTION_PHASES, phaseProgress, type ProgramView, type TreeView } from "@/lib/adoption-types";
import { fmtDate } from "@/lib/utils";

type Sub = "analytics" | "trees" | "programs" | "farmers" | "adoptions" | "updates" | "certificates" | "occasions";

const ADOPTION_STATUSES = ["pending", "active", "paused", "completed", "expired", "renewed", "cancelled"];
const TREE_STATUSES = ["available", "reserved", "adopted", "inactive", "under_review"];

export function AdminAdoptionTab() {
  const { t, d, fmt, lang, toast } = useStore();
  const [sub, setSub] = useState<Sub>("analytics");
  const [analytics, setAnalytics] = useState<any | null>(null);
  const [trees, setTrees] = useState<any[] | null>(null);
  const [treeFilter, setTreeFilter] = useState("");
  const [programs, setPrograms] = useState<any[] | null>(null);
  const [farmers, setFarmers] = useState<any[] | null>(null);
  const [sellers, setSellers] = useState<{ id: number; shopName: string }[]>([]);
  const [adoptions, setAdoptions] = useState<any[] | null>(null);
  const [updates, setUpdates] = useState<any[] | null>(null);
  const [certs, setCerts] = useState<any[] | null>(null);
  const [occasions, setOccasions] = useState<any[] | null>(null);
  const [progModal, setProgModal] = useState<any | null>(null);
  const [treeModal, setTreeModal] = useState<any | null>(null);
  const [farmerModal, setFarmerModal] = useState<any | null>(null);
  const [linkModal, setLinkModal] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    if (sub === "analytics") fetch("/api/admin/adoption/analytics", { cache: "no-store" }).then((r) => r.json()).then(setAnalytics).catch(() => {});
    if (sub === "trees") fetch(`/api/admin/adoption/trees?status=${treeFilter}`, { cache: "no-store" }).then((r) => r.json()).then((x) => setTrees(x.items)).catch(() => setTrees([]));
    if (sub === "programs") fetch("/api/admin/adoption/programs", { cache: "no-store" }).then((r) => r.json()).then((x) => setPrograms(x.items)).catch(() => setPrograms([]));
    if (sub === "farmers") fetch("/api/admin/adoption/farmers", { cache: "no-store" }).then((r) => r.json()).then((x) => { setFarmers(x.items); setSellers(x.sellers ?? []); }).catch(() => setFarmers([]));
    if (sub === "adoptions") fetch("/api/admin/adoption/adoptions", { cache: "no-store" }).then((r) => r.json()).then((x) => setAdoptions(x.items)).catch(() => setAdoptions([]));
    if (sub === "updates") fetch("/api/admin/adoption/updates", { cache: "no-store" }).then((r) => r.json()).then((x) => setUpdates(x.items)).catch(() => setUpdates([]));
    if (sub === "certificates") fetch("/api/admin/adoption/certificates", { cache: "no-store" }).then((r) => r.json()).then((x) => setCerts(x.items)).catch(() => setCerts([]));
    if (sub === "occasions") fetch("/api/admin/adoption/occasions", { cache: "no-store" }).then((r) => r.json()).then((x) => setOccasions(x.items)).catch(() => setOccasions([]));
  };

  useEffect(load, [sub, treeFilter]);

  const put = async (resource: string, body: Record<string, unknown>) => {
    setBusy(true);
    try {
      await api(`/api/admin/adoption/${resource}`, { method: "PUT", body });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };
  const post = async (resource: string, body: Record<string, unknown>) => {
    setBusy(true);
    try {
      await api(`/api/admin/adoption/${resource}`, { body });
      toast(t("t_saved"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };
  const del = async (resource: string, body: Record<string, unknown>) => {
    setBusy(true);
    try {
      await api(`/api/admin/adoption/${resource}`, { method: "DELETE", body });
      toast(t("t_deleted"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  const subs: { id: Sub; label: string }[] = [
    { id: "analytics", label: t("ad_adm_analytics") },
    { id: "trees", label: t("ad_adm_trees") },
    { id: "programs", label: t("ad_adm_programs") },
    { id: "farmers", label: t("ad_adm_farmers") },
    { id: "adoptions", label: t("ad_adm_sponsors") },
    { id: "updates", label: t("ad_adm_updates") },
    { id: "certificates", label: t("ad_adm_certs") },
    { id: "occasions", label: t("ad_gift_occasion") },
  ];

  return (
    <div className="space-y-5">
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {subs.map((s) => (
          <button
            key={s.id}
            onClick={() => setSub(s.id)}
            className={`rounded-xl px-3.5 py-2 text-xs font-bold whitespace-nowrap transition ${sub === s.id ? "bg-olive-700 text-cream-50" : "bg-white border border-cream-300 text-ink-600 hover:border-olive-400"}`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {sub === "analytics" && (
        <div className="space-y-5">
          {!analytics ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {[
                  { l: t("ad_adm_an_available"), v: analytics.availableTrees },
                  { l: t("ad_adm_an_adopted"), v: analytics.adoptedTrees },
                  { l: t("ad_adm_pending_trees"), v: analytics.pendingTrees },
                  { l: t("ad_adm_an_sponsors"), v: analytics.sponsors },
                  { l: t("ad_adm_active_adoptions"), v: analytics.activeAdoptions },
                  { l: t("ad_adm_an_countries"), v: analytics.countries },
                  { l: t("ad_adm_an_value"), v: fmt(analytics.valueCents) },
                  { l: t("ad_adm_an_renewals"), v: analytics.renewals },
                  { l: t("ad_programs"), v: analytics.activePrograms },
                  { l: t("ad_trees_count"), v: analytics.totalTrees },
                ].map((c, i) => (
                  <div key={i} className="rounded-2xl border border-cream-200 bg-white p-4">
                    <div className="text-[11px] font-bold text-ink-400">{c.l}</div>
                    <div className="font-display text-lg font-bold text-ink-900 mt-1 truncate">{c.v}</div>
                  </div>
                ))}
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="rounded-2xl border border-cream-200 bg-white p-5">
                  <h3 className="font-bold text-sm text-ink-900 mb-3">{t("ad_adm_an_regions")}</h3>
                  {analytics.topRegions?.length ? (
                    <div className="space-y-2">
                      {analytics.topRegions.map((r: any) => (
                        <div key={r.label} className="flex items-center gap-3">
                          <span className="text-xs font-bold text-ink-600 w-28 truncate">{r.label}</span>
                          <div className="flex-1 h-2 rounded-full bg-cream-200 overflow-hidden">
                            <div className="h-full bg-olive-600" style={{ width: `${Math.min(100, r.count * 20)}%` }} />
                          </div>
                          <span className="text-xs font-bold text-ink-900">{r.count}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-ink-400">—</p>
                  )}
                </div>
                <div className="rounded-2xl border border-cream-200 bg-white p-5">
                  <h3 className="font-bold text-sm text-ink-900 mb-3">{t("ad_adm_an_programs")}</h3>
                  {analytics.topPrograms?.length ? (
                    <div className="space-y-2">
                      {analytics.topPrograms.map((p: any) => (
                        <div key={p.label} className="flex items-center gap-3">
                          <span className="text-xs font-bold text-ink-600 flex-1 truncate">{p.label}</span>
                          <span className="text-xs font-bold text-ink-900">{p.count}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-ink-400">—</p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {sub === "trees" && (
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap items-center">
            <Select value={treeFilter} onChange={(e) => setTreeFilter(e.target.value)} className="!w-auto">
              <option value="">{t("all")}</option>
              {TREE_STATUSES.map((s) => (
                <option key={s} value={s}>{t(`ad_status_${s}`)}</option>
              ))}
            </Select>
            <Btn onClick={() => setTreeModal({ farmerId: farmers?.[0]?.id ?? 0, nameAr: "", nameEn: "", approximateAge: "80", oliveVariety: "", region: "", storyAr: "", storyEn: "", images: "", maxSponsors: "1", season: String(new Date().getFullYear()), verified: true, status: "available" })}>
              + {t("ad_st_add_tree")}
            </Btn>
          </div>
          {!trees ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : (
            <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
              <table className="w-full text-sm min-w-[820px]">
                <thead>
                  <tr className="border-b border-cream-200 text-xs text-ink-400">
                    <th className="text-start p-3 font-bold">{t("ad_tree_code")}</th>
                    <th className="text-start p-3 font-bold">{t("name")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_farmer")}</th>
                    <th className="text-start p-3 font-bold">{t("status")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_st_phase")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_st_sponsors")}</th>
                    <th className="p-3" />
                  </tr>
                </thead>
                <tbody>
                  {trees.map((tr) => (
                    <tr key={tr.id} className="border-b border-cream-100 last:border-0">
                      <td className="p-3 font-bold" dir="ltr">{tr.treeCode}</td>
                      <td className="p-3">
                        <div className="font-bold text-ink-900">{d({ ar: tr.nameAr, en: tr.nameEn }) || "—"}</div>
                        <div className="text-[11px] text-ink-400">{tr.region} · {tr.approximateAge} {t("ad_years")} · {tr.oliveVariety}</div>
                      </td>
                      <td className="p-3">
                        <Link href={`/farmers/${tr.farmer.slug}`} className="text-olive-700 hover:underline font-bold">{d({ ar: tr.farmer.nameAr, en: tr.farmer.nameEn })}</Link>
                      </td>
                      <td className="p-3">
                        <Select value={tr.status} onChange={(e) => put("trees", { id: tr.id, status: e.target.value })} className="!w-32 !py-1.5 !text-xs">
                          {TREE_STATUSES.map((s) => (
                            <option key={s} value={s}>{t(`ad_status_${s}`)}</option>
                          ))}
                        </Select>
                      </td>
                      <td className="p-3">
                        <Select value={tr.phase} onChange={(e) => put("trees", { id: tr.id, phase: e.target.value, progressPercent: phaseProgress(e.target.value) })} className="!w-40 !py-1.5 !text-xs">
                          {ADOPTION_PHASES.map((p) => (
                            <option key={p} value={p}>{t(`ad_phase_${p}`)}</option>
                          ))}
                        </Select>
                      </td>
                      <td className="p-3 font-bold">{tr.sponsorCount}/{tr.maxSponsors}</td>
                      <td className="p-3">
                        <div className="flex gap-2 justify-end items-center flex-wrap">
                          {!tr.verified ? (
                            <Btn onClick={() => put("trees", { id: tr.id, verified: true })} className="!px-3 !py-1.5 !text-xs">✓ {t("ad_adm_verify")}</Btn>
                          ) : (
                            <>
                              <span className="text-[11px] font-bold text-olive-700">✓ {t("ad_verified")}</span>
                              <button onClick={() => put("trees", { id: tr.id, verified: false })} className="text-[11px] font-bold text-ink-400 hover:underline">
                                {t("ad_adm_unverify")}
                              </button>
                            </>
                          )}
                          <button onClick={() => del("trees", { id: tr.id })} className="text-[11px] font-bold text-clay-600 hover:underline">{t("delete")}</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {sub === "programs" && (
        <div className="space-y-4">
          <Btn onClick={() => setProgModal({ nameAr: "", nameEn: "", descriptionAr: "", descriptionEn: "", kind: "tree", priceCents: 12000, renewalPriceCents: 10000, durationDays: 365, benefitsText: "", productsText: "", shippingIncluded: false, maxSponsorsPerTree: 1, giftEnabled: true, active: true })}>
            + {t("ad_adm_add_program")}
          </Btn>
          {!programs ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {programs.map((p) => (
                <div key={p.id} className="rounded-2xl border border-cream-200 bg-white p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-bold text-ink-900">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                      <div className="text-[11px] text-ink-400 mt-0.5">
                        {p.kind} · {p.durationDays} {t("ad_days_n")} · {p.maxSponsorsPerTree} {t("ad_sponsors_max")}
                        {p.shippingIncluded ? ` · 🚚 ${t("ad_adm_shipping_inc")}` : ""}
                        {p.giftEnabled ? " · 🎁" : ""}
                      </div>
                    </div>
                    <div className="text-end shrink-0">
                      <div className="font-display font-bold text-olive-800">{fmt(p.priceCents)}</div>
                      <div className="text-[10px] text-ink-400 font-bold">{t("ad_renew_price")}: {fmt(p.renewalPriceCents)}</div>
                    </div>
                  </div>
                  <div className="mt-2.5 text-xs text-ink-600 space-y-1">
                    {p.benefits?.map((b: any, i: number) => (
                      <div key={i}>✓ {d(b)}</div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-3.5 items-center flex-wrap">
                    <button
                      onClick={() =>
                        setProgModal({
                          id: p.id,
                          nameAr: p.nameAr,
                          nameEn: p.nameEn,
                          descriptionAr: p.descriptionAr ?? "",
                          descriptionEn: p.descriptionEn ?? "",
                          kind: p.kind,
                          priceCents: p.priceCents,
                          renewalPriceCents: p.renewalPriceCents,
                          durationDays: p.durationDays,
                          benefitsText: (p.benefits ?? []).map((b: any) => `${b.ar}|${b.en}`).join("\n"),
                          productsText: (p.includedProducts ?? []).map((x: any) => `${x.labelAr}|${x.labelEn}|${x.qty}`).join("\n"),
                          shippingIncluded: p.shippingIncluded,
                          maxSponsorsPerTree: p.maxSponsorsPerTree,
                          giftEnabled: p.giftEnabled,
                          active: p.active,
                        })
                      }
                      className="text-xs font-bold text-ink-600 hover:underline"
                    >
                      {t("edit")}
                    </button>
                    <button onClick={() => put("programs", { id: p.id, active: !p.active })} className="text-xs font-bold text-olive-700 hover:underline">
                      {p.active ? t("inactive") : t("active")}
                    </button>
                    <button onClick={() => del("programs", { id: p.id })} className="text-xs font-bold text-clay-600 hover:underline">
                      {t("delete")}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {sub === "farmers" && (
        <div className="space-y-4">
          <Btn onClick={() => setFarmerModal({ nameAr: "", nameEn: "", farmNameAr: "", farmNameEn: "", region: "", city: "", yearsFarming: 10, storyAr: "", storyEn: "", sellerId: sellers[0]?.id ?? 0 })}>
            + {t("ad_adm_add_farmer")}
          </Btn>
          {!farmers ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : (
            <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
              <table className="w-full text-sm min-w-[760px]">
                <thead>
                  <tr className="border-b border-cream-200 text-xs text-ink-400">
                    <th className="text-start p-3 font-bold">{t("ad_farmer")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_region")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_trees_count")}</th>
                    <th className="text-start p-3 font-bold">{t("ad_st_sponsors")}</th>
                    <th className="text-start p-3 font-bold">{t("status")}</th>
                    <th className="p-3" />
                  </tr>
                </thead>
                <tbody>
                  {farmers.map((f) => (
                    <tr key={f.id} className="border-b border-cream-100 last:border-0">
                      <td className="p-3">
                        <Link href={`/farmers/${f.slug}`} className="font-bold text-olive-800 hover:underline">{d({ ar: f.nameAr, en: f.nameEn })}</Link>
                        <div className="text-[11px] text-ink-400">{f.shopName ?? "—"}</div>
                      </td>
                      <td className="p-3">{f.city ?? f.region ?? "—"}</td>
                      <td className="p-3 font-bold">{f.trees}</td>
                      <td className="p-3 font-bold">{f.sponsorCount}</td>
                      <td className="p-3">{f.active ? t("active") : t("inactive")}</td>
                      <td className="p-3">
                        <div className="flex gap-2 justify-end flex-wrap">
                          <button onClick={() => setLinkModal({ farmerId: f.id, farmerName: d({ ar: f.nameAr, en: f.nameEn }) })} className="text-xs font-bold text-ink-600 hover:underline">
                            {t("ad_programs")}
                          </button>
                          <button onClick={() => put("farmers", { id: f.id, active: !f.active })} className="text-xs font-bold text-olive-700 hover:underline">
                            {f.active ? t("inactive") : t("active")}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {sub === "adoptions" && (
        !adoptions ? (
          <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
        ) : (
          <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
            <table className="w-full text-sm min-w-[860px]">
              <thead>
                <tr className="border-b border-cream-200 text-xs text-ink-400">
                  <th className="text-start p-3 font-bold">#</th>
                  <th className="text-start p-3 font-bold">{t("ad_st_sponsors")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_tree_code")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_program")}</th>
                  <th className="text-start p-3 font-bold">{t("price")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_end_date")}</th>
                  <th className="p-3">{t("status")}</th>
                </tr>
              </thead>
              <tbody>
                {adoptions.map((a) => (
                  <tr key={a.id} className="border-b border-cream-100 last:border-0">
                    <td className="p-3 font-bold">{a.id}</td>
                    <td className="p-3">
                      <div className="font-bold text-ink-900">{a.sponsor}</div>
                      <div className="text-[11px] text-ink-400" dir="ltr">{a.sponsorEmail}</div>
                      {a.isGift && <div className="text-[11px] text-clay-600 font-bold">🎁 {a.giftRecipientName}</div>}
                    </td>
                    <td className="p-3" dir="ltr">{a.treeCode ?? "—"}</td>
                    <td className="p-3">{a.program}</td>
                    <td className="p-3 font-bold">{fmt(a.priceCents)}</td>
                    <td className="p-3 text-ink-400">{a.endDate ? fmtDate(a.endDate, lang) : "—"}</td>
                    <td className="p-3">
                      <Select value={a.status} onChange={(e) => put("adoptions", { id: a.id, status: e.target.value })} className="!w-36 !py-1.5 !text-xs">
                        {ADOPTION_STATUSES.map((s) => (
                          <option key={s} value={s}>{t(`ad_status_${s}`)}</option>
                        ))}
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}

      {sub === "updates" && (
        !updates ? (
          <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
        ) : (
          <div className="space-y-3">
            {updates.map((u) => (
              <div key={u.id} className="rounded-2xl border border-cream-200 bg-white p-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div className="font-bold text-sm text-ink-900">{d({ ar: u.titleAr, en: u.titleEn })}</div>
                    <div className="text-[11px] text-ink-400 mt-0.5">
                      {u.farmer} {u.treeCode && <span dir="ltr">· {u.treeCode}</span>} · {timeAgoLocal(u.createdAt, lang)}
                    </div>
                  </div>
                  <div className="flex gap-2 items-center">
                    <button onClick={() => put("updates", { id: u.id, published: !u.published })} className="text-xs font-bold text-olive-700 hover:underline">
                      {u.published ? t("inactive") : t("active")}
                    </button>
                  </div>
                </div>
                {(u.bodyAr || u.bodyEn) && <p className="text-sm text-ink-600 mt-2">{d({ ar: u.bodyAr, en: u.bodyEn })}</p>}
                {u.phase && <span className="inline-block mt-2 rounded-full bg-olive-100 text-olive-800 px-2.5 py-1 text-[11px] font-bold">{t(`ad_phase_${u.phase}`)}</span>}
              </div>
            ))}
          </div>
        )
      )}

      {sub === "certificates" && (
        !certs ? (
          <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
        ) : (
          <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
            <table className="w-full text-sm min-w-[720px]">
              <thead>
                <tr className="border-b border-cream-200 text-xs text-ink-400">
                  <th className="text-start p-3 font-bold">{t("ad_cert_number")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_cert_sponsor")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_cert_tree")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_cert_farmer")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_cert_issued")}</th>
                  <th className="p-3" />
                </tr>
              </thead>
              <tbody>
                {certs.map((c) => (
                  <tr key={c.id} className="border-b border-cream-100 last:border-0">
                    <td className="p-3 font-bold" dir="ltr">{c.code}</td>
                    <td className="p-3">{c.sponsorName}</td>
                    <td className="p-3" dir="ltr">{c.treeCode ?? "—"}</td>
                    <td className="p-3">{c.farmerName}</td>
                    <td className="p-3 text-ink-400">{fmtDate(c.issuedAt, lang)}</td>
                    <td className="p-3 text-end">
                      <Link href={`/certificate/${c.code}`} className="text-xs font-bold text-olive-700 hover:underline">{t("ad_view_cert")}</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}

      {sub === "occasions" && (
        <OccasionsManager occasions={occasions} onPost={post} onPut={put} onDelete={del} />
      )}

      {/* program modal */}
      <Modal open={!!progModal} onClose={() => setProgModal(null)} title={progModal?.id ? t("edit") : t("ad_adm_add_program")}>
        {progModal && (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_adm_prog_name_ar")}><TextInput value={progModal.nameAr} onChange={(e) => setProgModal({ ...progModal, nameAr: e.target.value })} /></Field>
              <Field label={t("ad_adm_prog_name_en")}><TextInput dir="ltr" value={progModal.nameEn} onChange={(e) => setProgModal({ ...progModal, nameEn: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_adm_prog_kind")}>
                <Select value={progModal.kind} onChange={(e) => setProgModal({ ...progModal, kind: e.target.value })}>
                  <option value="tree">{t("ad_adm_kind_tree")}</option>
                  <option value="farmer">{t("ad_adm_kind_farmer")}</option>
                  <option value="both">{t("ad_adm_kind_both")}</option>
                </Select>
              </Field>
              <Field label={t("ad_adm_prog_duration")}>
                <TextInput dir="ltr" type="number" value={progModal.durationDays} onChange={(e) => setProgModal({ ...progModal, durationDays: Number(e.target.value) })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_adm_prog_price")}>
                <TextInput dir="ltr" type="number" step="0.01" value={(progModal.priceCents / 100).toString()} onChange={(e) => setProgModal({ ...progModal, priceCents: Math.round(Number(e.target.value || 0) * 100) })} />
              </Field>
              <Field label={t("ad_adm_prog_renewal")}>
                <TextInput dir="ltr" type="number" step="0.01" value={(progModal.renewalPriceCents / 100).toString()} onChange={(e) => setProgModal({ ...progModal, renewalPriceCents: Math.round(Number(e.target.value || 0) * 100) })} />
              </Field>
            </div>
            <Field label={t("ad_adm_prog_benefits")} hint="ar|en">
              <TextArea value={progModal.benefitsText} onChange={(e) => setProgModal({ ...progModal, benefitsText: e.target.value })} placeholder={"شهادة رقمية|Digital certificate\nتحديثات موسمية|Seasonal updates"} />
            </Field>
            <Field label={t("ad_adm_prog_products")} hint="ar|en|qty">
              <TextArea value={progModal.productsText} onChange={(e) => setProgModal({ ...progModal, productsText: e.target.value })} placeholder={"زيت زيتون 500مل|Olive oil 500ml|2"} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_sponsors_max")}>
                <TextInput dir="ltr" type="number" min={1} value={progModal.maxSponsorsPerTree} onChange={(e) => setProgModal({ ...progModal, maxSponsorsPerTree: Number(e.target.value) })} />
              </Field>
              <div className="space-y-2 pt-6">
                <label className="flex items-center gap-2 text-xs font-bold text-ink-700 cursor-pointer">
                  <input type="checkbox" checked={!!progModal.shippingIncluded} onChange={(e) => setProgModal({ ...progModal, shippingIncluded: e.target.checked })} className="w-4 h-4 accent-olive-700" />
                  {t("ad_adm_shipping_inc")}
                </label>
                <label className="flex items-center gap-2 text-xs font-bold text-ink-700 cursor-pointer">
                  <input type="checkbox" checked={!!progModal.giftEnabled} onChange={(e) => setProgModal({ ...progModal, giftEnabled: e.target.checked })} className="w-4 h-4 accent-olive-700" />
                  {t("ad_adm_gift_enabled")}
                </label>
              </div>
            </div>
            <Btn
              disabled={busy}
              className="w-full"
              onClick={() => {
                const benefits = (progModal.benefitsText as string)
                  .split("\n")
                  .map((l: string) => l.trim())
                  .filter(Boolean)
                  .map((l: string) => {
                    const [ar, en] = l.split("|");
                    return { ar: ar?.trim() ?? "", en: (en ?? ar)?.trim() ?? "" };
                  });
                const includedProducts = (progModal.productsText as string)
                  .split("\n")
                  .map((l: string) => l.trim())
                  .filter(Boolean)
                  .map((l: string) => {
                    const [labelAr, labelEn, qty] = l.split("|");
                    return { labelAr: labelAr?.trim() ?? "", labelEn: (labelEn ?? labelAr)?.trim() ?? "", qty: Number(qty ?? 1) };
                  });
                const body = { ...progModal, benefits, includedProducts };
                delete (body as any).benefitsText;
                delete (body as any).productsText;
                if (progModal.id) put("programs", body).then(() => setProgModal(null));
                else post("programs", body).then(() => setProgModal(null));
              }}
            >
              {t("save")}
            </Btn>
          </div>
        )}
      </Modal>

      {/* tree modal */}
      <Modal open={!!treeModal} onClose={() => setTreeModal(null)} title={t("ad_st_add_tree")}>
        {treeModal && (
          <div className="space-y-3.5">
            <Field label={t("ad_adm_farmer_link")}>
              <Select value={treeModal.farmerId} onChange={(e) => setTreeModal({ ...treeModal, farmerId: Number(e.target.value) })}>
                {(farmers ?? []).map((f) => (
                  <option key={f.id} value={f.id}>{d({ ar: f.nameAr, en: f.nameEn })}</option>
                ))}
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_st_tree_name_ar")}><TextInput value={treeModal.nameAr} onChange={(e) => setTreeModal({ ...treeModal, nameAr: e.target.value })} /></Field>
              <Field label={t("ad_st_tree_name_en")}><TextInput dir="ltr" value={treeModal.nameEn} onChange={(e) => setTreeModal({ ...treeModal, nameEn: e.target.value })} /></Field>
              <Field label={t("ad_st_age")}><TextInput dir="ltr" type="number" value={treeModal.approximateAge} onChange={(e) => setTreeModal({ ...treeModal, approximateAge: e.target.value })} /></Field>
              <Field label={t("ad_st_variety")}><TextInput value={treeModal.oliveVariety} onChange={(e) => setTreeModal({ ...treeModal, oliveVariety: e.target.value })} /></Field>
              <Field label={t("ad_region")}><TextInput value={treeModal.region} onChange={(e) => setTreeModal({ ...treeModal, region: e.target.value })} /></Field>
              <Field label={t("ad_season")}><TextInput dir="ltr" value={treeModal.season} onChange={(e) => setTreeModal({ ...treeModal, season: e.target.value })} /></Field>
            </div>
            <Field label={t("ad_st_story")}><TextArea value={treeModal.storyAr} onChange={(e) => setTreeModal({ ...treeModal, storyAr: e.target.value })} /></Field>
            <Field label={t("ad_st_images")}><TextArea dir="ltr" value={treeModal.images} onChange={(e) => setTreeModal({ ...treeModal, images: e.target.value })} /></Field>
            <Btn
              disabled={busy}
              className="w-full"
              onClick={() =>
                post("trees", {
                  ...treeModal,
                  approximateAge: Number(treeModal.approximateAge || 1),
                  maxSponsors: Number(treeModal.maxSponsors || 1),
                  images: String(treeModal.images).split("\n").map((x: string) => x.trim()).filter(Boolean),
                }).then(() => setTreeModal(null))
              }
            >
              {t("save")}
            </Btn>
          </div>
        )}
      </Modal>

      {/* farmer modal */}
      <Modal open={!!farmerModal} onClose={() => setFarmerModal(null)} title={t("ad_adm_add_farmer")}>
        {farmerModal && (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label={`${t("name")} (ع)`}><TextInput value={farmerModal.nameAr} onChange={(e) => setFarmerModal({ ...farmerModal, nameAr: e.target.value })} /></Field>
              <Field label={`${t("name")} (EN)`}><TextInput dir="ltr" value={farmerModal.nameEn} onChange={(e) => setFarmerModal({ ...farmerModal, nameEn: e.target.value })} /></Field>
              <Field label={`${t("ad_farm")} (ع)`}><TextInput value={farmerModal.farmNameAr} onChange={(e) => setFarmerModal({ ...farmerModal, farmNameAr: e.target.value })} /></Field>
              <Field label={`${t("ad_farm")} (EN)`}><TextInput dir="ltr" value={farmerModal.farmNameEn} onChange={(e) => setFarmerModal({ ...farmerModal, farmNameEn: e.target.value })} /></Field>
              <Field label={t("ad_region")}><TextInput value={farmerModal.region} onChange={(e) => setFarmerModal({ ...farmerModal, region: e.target.value })} /></Field>
              <Field label={t("apply_city")}><TextInput value={farmerModal.city} onChange={(e) => setFarmerModal({ ...farmerModal, city: e.target.value })} /></Field>
            </div>
            <Field label={t("ad_years_farming")}>
              <TextInput dir="ltr" type="number" value={farmerModal.yearsFarming} onChange={(e) => setFarmerModal({ ...farmerModal, yearsFarming: Number(e.target.value) })} />
            </Field>
            <Field label={t("ad_adm_farmer_link")}>
              <Select value={farmerModal.sellerId} onChange={(e) => setFarmerModal({ ...farmerModal, sellerId: Number(e.target.value) })}>
                {sellers.map((s) => (
                  <option key={s.id} value={s.id}>{s.shopName}</option>
                ))}
              </Select>
            </Field>
            <Field label={t("ad_story_farmer")}><TextArea value={farmerModal.storyAr} onChange={(e) => setFarmerModal({ ...farmerModal, storyAr: e.target.value })} /></Field>
            <Btn disabled={busy} className="w-full" onClick={() => post("farmers", farmerModal).then(() => setFarmerModal(null))}>{t("save")}</Btn>
          </div>
        )}
      </Modal>

      {/* farmer ↔ programs modal */}
      <Modal open={!!linkModal} onClose={() => setLinkModal(null)} title={`${t("ad_programs")} — ${linkModal?.farmerName ?? ""}`}>
        {linkModal && <FarmerPrograms farmerId={linkModal.farmerId} programs={programs ?? []} onPost={post} />}
      </Modal>
    </div>
  );
}

function FarmerPrograms({ farmerId, programs, onPost }: { farmerId: number; programs: any[]; onPost: (r: string, b: Record<string, unknown>) => Promise<void> }) {
  const { t, fmt, lang, toast } = useStore();
  const [rows, setRows] = useState<any[] | null>(null);

  const load = () => fetch(`/api/admin/adoption/farmer-programs?farmerId=${farmerId}`, { cache: "no-store" }).then((r) => r.json()).then((x) => setRows(x.items ?? [])).catch(() => setRows([]));
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [farmerId]);

  const toggle = async (programId: number, patch: Record<string, unknown>) => {
    await onPost("farmer-programs", { farmerId, programId, ...patch });
    load();
  };

  if (!rows) return <div className="flex justify-center py-6"><Spinner /></div>;
  const byProgram = new Map(rows.map((r) => [r.programId, r]));

  return (
    <div className="space-y-2.5">
      {programs.map((p) => {
        const link = byProgram.get(p.id);
        return (
          <div key={p.id} className="rounded-xl border border-cream-200 p-3.5">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div>
                <div className="font-bold text-sm text-ink-900">{p.nameEn}</div>
                <div className="text-[11px] text-ink-400">{fmt(p.priceCents)} · {p.kind}</div>
              </div>
              <label className="flex items-center gap-2 text-xs font-bold text-ink-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={!!link?.allowed}
                  onChange={(e) => toggle(p.id, { allowed: e.target.checked })}
                  className="w-4 h-4 accent-olive-700"
                />
                {t("active")}
              </label>
            </div>
            {link?.allowed && (
              <div className="mt-3 grid grid-cols-2 gap-2.5">
                <label className="flex items-center gap-2 text-[11px] font-bold text-ink-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!link.allowPriceOverride}
                    onChange={(e) => toggle(p.id, { allowed: true, allowPriceOverride: e.target.checked })}
                    className="w-4 h-4 accent-olive-700"
                  />
                  {t("ad_adm_allow_price_override")}
                </label>
                <TextInput
                  dir="ltr"
                  type="number"
                  step="0.01"
                  placeholder={`${t("ad_adm_prog_price")}`}
                  defaultValue={link.customPriceCents ? (link.customPriceCents / 100).toString() : ""}
                  onBlur={(e) =>
                    toggle(p.id, {
                      allowed: true,
                      allowPriceOverride: !!link.allowPriceOverride,
                      customPriceCents: e.target.value ? Math.round(Number(e.target.value) * 100) : null,
                    })
                  }
                  className="!py-1.5 !text-xs"
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function OccasionsManager({
  occasions,
  onPost,
  onPut,
  onDelete,
}: {
  occasions: any[] | null;
  onPost: (r: string, b: Record<string, unknown>) => Promise<void>;
  onPut: (r: string, b: Record<string, unknown>) => Promise<void>;
  onDelete: (r: string, b: Record<string, unknown>) => Promise<void>;
}) {
  const { t, d } = useStore();
  const [form, setForm] = useState({ key: "", nameAr: "", nameEn: "" });
  if (!occasions) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-cream-200 bg-white p-4 flex flex-wrap items-end gap-3">
        <div className="w-32"><Field label="Key"><TextInput dir="ltr" value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value })} placeholder="birthday" /></Field></div>
        <div className="flex-1 min-w-[140px]"><Field label={t("ad_cat_name_ar")}><TextInput value={form.nameAr} onChange={(e) => setForm({ ...form, nameAr: e.target.value })} /></Field></div>
        <div className="flex-1 min-w-[140px]"><Field label={t("ad_cat_name_en")}><TextInput dir="ltr" value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} /></Field></div>
        <Btn disabled={!form.key || !form.nameEn} onClick={() => onPost("occasions", form).then(() => setForm({ key: "", nameAr: "", nameEn: "" }))}>
          + {t("save")}
        </Btn>
      </div>
      <div className="rounded-2xl border border-cream-200 bg-white divide-y divide-cream-100">
        {occasions.map((o) => (
          <div key={o.id} className="p-3.5 flex items-center justify-between gap-3 flex-wrap">
            <div>
              <span className="font-bold text-sm text-ink-900">{d({ ar: o.nameAr, en: o.nameEn })}</span>
              <span className="text-[11px] text-ink-400 ms-2" dir="ltr">{o.key}</span>
            </div>
            <div className="flex items-center gap-3">
              <input type="checkbox" checked={o.active} onChange={(e) => onPut("occasions", { id: o.id, active: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
              <button onClick={() => onDelete("occasions", { id: o.id })} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function timeAgoLocal(iso: string, lang: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 60) return lang === "ar" ? `منذ ${min} دقيقة` : `${min}m ago`;
  if (min < 1440) return lang === "ar" ? `منذ ${Math.floor(min / 60)} ساعة` : `${Math.floor(min / 60)}h ago`;
  return lang === "ar" ? `منذ ${Math.floor(min / 1440)} يوم` : `${Math.floor(min / 1440)}d ago`;
}
