"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useStore } from "./store";
import { Btn, EmptyState, Field, Modal, Select, Spinner, TextArea, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";
import { ADOPTION_PHASES, phaseProgress, type ProgramView, type TreeView, type UpdateView } from "@/lib/adoption-types";
import { fmtDate, timeAgo } from "@/lib/utils";

const EMPTY_TREE = {
  id: 0,
  nameAr: "",
  nameEn: "",
  treeNumber: "",
  approximateAge: "80",
  oliveVariety: "",
  region: "",
  season: String(new Date().getFullYear()),
  storyAr: "",
  storyEn: "",
  images: "",
  farmImages: "",
  maxSponsors: "1",
  status: "under_review",
};

export function SellerTreesTab() {
  const { t, d, lang, toast } = useStore();
  const [farmer, setFarmer] = useState<any | null>(null);
  const [stats, setStats] = useState<any | null>(null);
  const [trees, setTrees] = useState<TreeView[] | null>(null);
  const [programs, setPrograms] = useState<ProgramView[]>([]);
  const [sponsors, setSponsors] = useState<any[] | null>(null);
  const [updates, setUpdates] = useState<UpdateView[] | null>(null);
  const [editing, setEditing] = useState<typeof EMPTY_TREE | null>(null);
  const [updateOpen, setUpdateOpen] = useState(false);
  const [upd, setUpd] = useState({ treeId: "", titleAr: "", titleEn: "", bodyAr: "", bodyEn: "", image: "", video: "", phase: "" });
  const [busy, setBusy] = useState(false);

  const load = () => {
    fetch("/api/farmer/status", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => {
      if (x) {
        setFarmer(x.farmer);
        setStats(x.stats);
      }
    }).catch(() => {});
    fetch("/api/farmer/trees", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => {
      if (x) {
        setTrees(x.items);
        setPrograms(x.programs ?? []);
      }
    }).catch(() => setTrees([]));
    fetch("/api/farmer/sponsors", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setSponsors(x?.items ?? [])).catch(() => setSponsors([]));
    fetch("/api/farmer/updates", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setUpdates(x?.items ?? [])).catch(() => setUpdates([]));
  };

  useEffect(load, []);

  if (trees === null || !farmer) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <Spinner className="w-8 h-8" />
      </div>
    );
  }

  if (!farmer) {
    return <EmptyState icon={<span className="text-3xl">🌿</span>} title={t("ad_st_no_farmer")} />;
  }

  const saveTree = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const body = {
        nameAr: editing.nameAr,
        nameEn: editing.nameEn,
        treeNumber: editing.treeNumber ? Number(editing.treeNumber) : undefined,
        approximateAge: Number(editing.approximateAge || 1),
        oliveVariety: editing.oliveVariety,
        region: editing.region,
        season: editing.season,
        storyAr: editing.storyAr,
        storyEn: editing.storyEn,
        images: editing.images.split("\n").map((x) => x.trim()).filter(Boolean),
        farmImages: editing.farmImages.split("\n").map((x) => x.trim()).filter(Boolean),
        maxSponsors: Number(editing.maxSponsors || 1),
      };
      if (editing.id) await api("/api/farmer/trees", { method: "PUT", body: { id: editing.id, ...body } });
      else await api("/api/farmer/trees", { body });
      toast(t("ad_t_tree_saved"));
      setEditing(null);
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  const setTreeStatus = async (id: number, status: string) => {
    try {
      await api("/api/farmer/trees", { method: "PUT", body: { id, status } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const deleteTree = async (id: number) => {
    try {
      await api("/api/farmer/trees", { method: "DELETE", body: { id } });
      toast(t("t_deleted"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const publishUpdate = async () => {
    setBusy(true);
    try {
      const res = await api<{ notified?: number }>("/api/farmer/updates", {
        body: {
          treeId: upd.treeId ? Number(upd.treeId) : undefined,
          titleAr: upd.titleAr,
          titleEn: upd.titleEn,
          bodyAr: upd.bodyAr,
          bodyEn: upd.bodyEn,
          image: upd.image || undefined,
          video: upd.video || undefined,
          phase: upd.phase || undefined,
        },
      });
      toast(`${t("ad_t_update_posted")} · ${res.notified ?? 0} 🌿`);
      setUpdateOpen(false);
      setUpd({ treeId: "", titleAr: "", titleEn: "", bodyAr: "", bodyEn: "", image: "", video: "", phase: "" });
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { l: t("ad_trees_count"), v: stats?.trees ?? 0 },
          { l: t("ad_st_sponsored"), v: stats?.sponsoredTrees ?? 0 },
          { l: t("ad_st_sponsors"), v: stats?.sponsors ?? 0 },
          { l: t("ad_updates"), v: stats?.updates ?? 0 },
        ].map((c, i) => (
          <div key={i} className="rounded-2xl border border-cream-200 bg-white p-4">
            <div className="text-[11px] font-bold text-ink-400">{c.l}</div>
            <div className="font-display text-xl font-bold text-ink-900 mt-1">{c.v}</div>
          </div>
        ))}
      </div>

      {/* trees */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h3 className="font-bold text-ink-900">{t("ad_st_my_trees")}</h3>
        <div className="flex gap-2">
          <Btn variant="outline" onClick={() => setUpdateOpen(true)}>📣 {t("ad_st_post_update")}</Btn>
          <Btn onClick={() => setEditing({ ...EMPTY_TREE, region: farmer.region ?? farmer.city ?? "" })}>+ {t("ad_st_add_tree")}</Btn>
        </div>
      </div>

      {trees.length === 0 ? (
        <EmptyState icon={<span className="text-3xl">🌿</span>} title={t("ad_no_trees")} hint={t("ad_st_trees_pending")} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {trees.map((tr) => (
            <div key={tr.id} className="rounded-2xl border border-cream-200 bg-white overflow-hidden">
              <div className="aspect-[16/10] bg-cream-100 overflow-hidden relative">
                {tr.images[0] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={tr.images[0]} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-3xl">🌿</div>
                )}
                <span className={`absolute top-2 start-2 rounded-full px-2.5 py-1 text-[10px] font-bold ${tr.verified ? "bg-olive-700 text-cream-50" : "bg-gold-300/90 text-ink-900"}`}>
                  {tr.verified ? `✓ ${t("ad_verified")}` : t("ad_status_under_review")}
                </span>
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-ink-900 truncate">{d({ ar: tr.nameAr, en: tr.nameEn }) || tr.treeCode}</div>
                    <div className="text-[11px] text-ink-400 font-bold" dir="ltr">{tr.treeCode}</div>
                  </div>
                  <span className="text-[11px] font-bold text-olive-700 shrink-0">
                    {tr.sponsorCount}/{tr.maxSponsors}
                  </span>
                </div>
                <div className="mt-2.5 flex items-center justify-between gap-2">
                  <span className="rounded-full bg-olive-100 text-olive-800 px-2.5 py-1 text-[11px] font-bold">
                    {t(`ad_phase_${tr.phase}`)}
                  </span>
                  <button
                    onClick={() => {
                      setUpd({ treeId: String(tr.id), titleAr: "", titleEn: "", bodyAr: "", bodyEn: "", image: "", video: "", phase: "" });
                      setUpdateOpen(true);
                    }}
                    className="text-[11px] font-bold text-olive-700 hover:underline"
                  >
                    {t("ad_st_phase")} ↑
                  </button>
                </div>
                <div className="flex items-center justify-between mt-2 text-[11px] text-ink-400 font-bold">
                  <span>{t("ad_status")}: {t(`ad_status_${tr.status}`)}</span>
                  <span>{t("ad_progress")}: {tr.progressPercent}%</span>
                </div>
                <div className="flex gap-2 mt-3 flex-wrap">
                  {tr.verified && (
                    <Link href={`/trees/${tr.treeCode}`} className="text-[11px] font-bold text-olive-700 hover:underline">{t("ad_public_page")}</Link>
                  )}
                  <button
                    onClick={() =>
                      setEditing({
                        id: tr.id,
                        nameAr: tr.nameAr ?? "",
                        nameEn: tr.nameEn ?? "",
                        treeNumber: tr.treeNumber ? String(tr.treeNumber) : "",
                        approximateAge: String(tr.approximateAge),
                        oliveVariety: tr.oliveVariety ?? "",
                        region: tr.region ?? "",
                        season: tr.season,
                        storyAr: "",
                        storyEn: "",
                        images: tr.images.join("\n"),
                        farmImages: "",
                        maxSponsors: String(tr.maxSponsors),
                        status: tr.status,
                      })
                    }
                    className="text-[11px] font-bold text-ink-600 hover:underline"
                  >
                    {t("edit")}
                  </button>
                  {tr.status === "available" && (
                    <button onClick={() => setTreeStatus(tr.id, "inactive")} className="text-[11px] font-bold text-ink-400 hover:underline">
                      {t("inactive")}
                    </button>
                  )}
                  {tr.status === "inactive" && (
                    <button onClick={() => setTreeStatus(tr.id, "available")} className="text-[11px] font-bold text-olive-700 hover:underline">
                      {t("active")}
                    </button>
                  )}
                  <button onClick={() => deleteTree(tr.id)} className="text-[11px] font-bold text-clay-600 hover:underline">
                    {t("delete")}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* programs the farmer participates in (read-only pricing) */}
      {programs.length > 0 && (
        <div>
          <h3 className="font-bold text-ink-900 mb-3">{t("ad_programs")}</h3>
          <div className="rounded-2xl border border-cream-200 bg-white divide-y divide-cream-100">
            {programs.map((p) => (
              <div key={p.id} className="p-4 flex items-center justify-between gap-3 flex-wrap">
                <div>
                  <div className="font-bold text-sm text-ink-900">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                  <div className="text-[11px] text-ink-400 mt-0.5">
                    {p.kind === "tree" ? t("ad_adm_kind_tree") : p.kind === "farmer" ? t("ad_adm_kind_farmer") : t("ad_adm_kind_both")}
                    {" · "}
                    {p.durationDays} {t("ad_days_n")}
                    {" · "}
                    {p.allowed ? t("active") : t("inactive")}
                    {p.allowPriceOverride ? ` · ${t("ad_adm_allow_price_override")}` : ""}
                  </div>
                </div>
                <div className="font-display font-bold text-olive-800">
                  {p.allowPriceOverride && p.customPriceCents ? `${(p.customPriceCents / 100).toFixed(2)}$` : `${(p.priceCents / 100).toFixed(2)}$`}
                </div>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-ink-400 mt-2">
            {t("ad_price")}: {t("ad_adm_allow_price_override")} — Admin
          </p>
        </div>
      )}

      {/* sponsors */}
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_st_sponsors")}</h3>
        {sponsors && sponsors.length > 0 ? (
          <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
            <table className="w-full text-sm min-w-[560px]">
              <thead>
                <tr className="border-b border-cream-200 text-xs text-ink-400">
                  <th className="text-start p-3 font-bold">{t("ad_st_sponsors")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_tree_code")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_program")}</th>
                  <th className="text-start p-3 font-bold">{t("status")}</th>
                  <th className="text-start p-3 font-bold">{t("ad_start_date")}</th>
                </tr>
              </thead>
              <tbody>
                {sponsors.map((s) => (
                  <tr key={s.id} className="border-b border-cream-100 last:border-0">
                    <td className="p-3 font-bold text-ink-900">
                      {s.sponsorName}
                      {s.isGift && <span className="text-[10px] text-clay-600 font-bold ms-1.5">🎁 {s.giftRecipientName}</span>}
                      {s.displayName && <div className="text-[11px] text-ink-400 font-semibold">"{s.displayName}"</div>}
                    </td>
                    <td className="p-3 text-ink-600" dir="ltr">{s.treeCode ?? "—"}</td>
                    <td className="p-3 text-ink-600">{s.program}</td>
                    <td className="p-3 text-ink-600">{t(`ad_status_${s.status}`)}</td>
                    <td className="p-3 text-ink-400">{fmtDate(s.startDate, lang)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-ink-400">—</p>
        )}
      </div>

      {/* updates history */}
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_updates")}</h3>
        {updates && updates.length > 0 ? (
          <div className="space-y-2.5">
            {updates.map((u) => (
              <div key={u.id} className="rounded-2xl border border-cream-200 bg-white p-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="font-bold text-sm text-ink-900">{d({ ar: u.titleAr, en: u.titleEn })}</div>
                  <span className="text-[11px] text-ink-400">{timeAgo(u.createdAt, lang)} {u.treeCode && <span dir="ltr">· {u.treeCode}</span>}</span>
                </div>
                {(u.bodyAr || u.bodyEn) && <p className="text-sm text-ink-600 mt-1.5">{d({ ar: u.bodyAr, en: u.bodyEn })}</p>}
                {u.phase && <span className="inline-block mt-2 rounded-full bg-olive-100 text-olive-800 px-2.5 py-1 text-[11px] font-bold">{t(`ad_phase_${u.phase}`)}</span>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-ink-400">{t("ad_no_updates")}</p>
        )}
      </div>

      {/* tree modal */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? t("ad_st_edit_tree") : t("ad_st_add_tree")}>
        {editing && (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_st_tree_name_ar")}>
                <TextInput value={editing.nameAr} onChange={(e) => setEditing({ ...editing, nameAr: e.target.value })} />
              </Field>
              <Field label={t("ad_st_tree_name_en")}>
                <TextInput dir="ltr" value={editing.nameEn} onChange={(e) => setEditing({ ...editing, nameEn: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Field label={t("ad_tree_number")}>
                <TextInput dir="ltr" type="number" value={editing.treeNumber} onChange={(e) => setEditing({ ...editing, treeNumber: e.target.value })} />
              </Field>
              <Field label={t("ad_st_age")}>
                <TextInput dir="ltr" type="number" value={editing.approximateAge} onChange={(e) => setEditing({ ...editing, approximateAge: e.target.value })} />
              </Field>
              <Field label={t("ad_st_variety")}>
                <TextInput value={editing.oliveVariety} onChange={(e) => setEditing({ ...editing, oliveVariety: e.target.value })} placeholder="Nabali" />
              </Field>
              <Field label={t("ad_st_max_sponsors")}>
                <TextInput dir="ltr" type="number" min={1} value={editing.maxSponsors} onChange={(e) => setEditing({ ...editing, maxSponsors: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("ad_region")}>
                <TextInput value={editing.region} onChange={(e) => setEditing({ ...editing, region: e.target.value })} />
              </Field>
              <Field label={t("ad_season")}>
                <TextInput dir="ltr" value={editing.season} onChange={(e) => setEditing({ ...editing, season: e.target.value })} />
              </Field>
            </div>
            <Field label={t("ad_st_story")} hint={t("ad_privacy_note")}>
              <TextArea value={editing.storyAr} onChange={(e) => setEditing({ ...editing, storyAr: e.target.value })} />
            </Field>
            <Field label={`${t("ad_st_story")} (EN)`}>
              <TextArea dir="ltr" value={editing.storyEn} onChange={(e) => setEditing({ ...editing, storyEn: e.target.value })} />
            </Field>
            <Field label={t("ad_st_images")}>
              <TextArea dir="ltr" value={editing.images} onChange={(e) => setEditing({ ...editing, images: e.target.value })} placeholder={"https://…/tree-1.jpg\nhttps://…/tree-2.jpg"} />
            </Field>
            <div className="rounded-xl bg-cream-100/70 border border-cream-200 p-3 text-[11px] text-ink-600 leading-relaxed">
              {t("ad_st_trees_pending")}
            </div>
            <Btn onClick={saveTree} disabled={busy} className="w-full">
              {editing.id ? t("sd_submit_edit") : t("ad_st_submit")}
            </Btn>
          </div>
        )}
      </Modal>

      {/* update modal */}
      <Modal open={updateOpen} onClose={() => setUpdateOpen(false)} title={t("ad_st_post_update")}>
        <div className="space-y-3.5">
          <Field label={t("ad_st_my_trees")}>
            <Select value={upd.treeId} onChange={(e) => setUpd({ ...upd, treeId: e.target.value })}>
              <option value="">{t("all")} ({t("ad_st_sponsors")})</option>
              {trees.map((tr) => (
                <option key={tr.id} value={tr.id}>
                  {tr.treeCode} — {d({ ar: tr.nameAr, en: tr.nameEn }) || "🌿"}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t("ad_st_phase")}>
            <Select value={upd.phase} onChange={(e) => setUpd({ ...upd, phase: e.target.value })}>
              <option value="">—</option>
              {ADOPTION_PHASES.map((p) => (
                <option key={p} value={p}>{t(`ad_phase_${p}`)} ({phaseProgress(p)}%)</option>
              ))}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={`${t("ad_st_update_title")} (ع)`}>
              <TextInput value={upd.titleAr} onChange={(e) => setUpd({ ...upd, titleAr: e.target.value })} />
            </Field>
            <Field label={`${t("ad_st_update_title")} (EN)`}>
              <TextInput dir="ltr" value={upd.titleEn} onChange={(e) => setUpd({ ...upd, titleEn: e.target.value })} />
            </Field>
          </div>
          <Field label={`${t("ad_st_update_body")} (ع)`}>
            <TextArea value={upd.bodyAr} onChange={(e) => setUpd({ ...upd, bodyAr: e.target.value })} />
          </Field>
          <Field label={`${t("ad_st_update_body")} (EN)`}>
            <TextArea dir="ltr" value={upd.bodyEn} onChange={(e) => setUpd({ ...upd, bodyEn: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("ad_st_update_image")}>
              <TextInput dir="ltr" value={upd.image} onChange={(e) => setUpd({ ...upd, image: e.target.value })} />
            </Field>
            <Field label={t("ad_st_update_video")}>
              <TextInput dir="ltr" value={upd.video} onChange={(e) => setUpd({ ...upd, video: e.target.value })} />
            </Field>
          </div>
          <Btn onClick={publishUpdate} disabled={busy || (!upd.titleAr && !upd.titleEn)} className="w-full">
            {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("ad_st_publish")}
          </Btn>
        </div>
      </Modal>
    </div>
  );
}
