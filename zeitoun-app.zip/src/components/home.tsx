"use client";

import Link from "next/link";
import { useStore } from "./store";
import { ProductCard, SectionHead, Stars } from "./ui";
import type { CategoryView, ProductView, ReviewView } from "@/lib/types";
import { AdoptHomeSections } from "./adoption-pages";
import { fmtNum } from "@/lib/utils";

interface SellerMini {
  id: number;
  slug: string;
  shopName: string;
  region: string | null;
  city: string | null;
  about: string | null;
  rating: number;
  orderCount: number;
  images: string[];
  productCount: number;
  joinedAt: string;
}

interface ReviewMini extends ReviewView {
  productAr: string;
  productEn: string;
}

export function HomeClient({
  categories,
  featured,
  popular,
  newest,
  sellers,
  reviews,
  hero,
  stats,
  adoptTrees,
  adoptFarmers,
  adoptPrograms,
}: {
  categories: CategoryView[];
  featured: ProductView[];
  popular: ProductView[];
  newest: ProductView[];
  sellers: SellerMini[];
  reviews: ReviewMini[];
  hero: { ar?: { title: string; subtitle: string }; en?: { title: string; subtitle: string } } | null;
  stats: { products: number; sellers: number; countries: number; reviews: number };
  adoptTrees?: any[];
  adoptFarmers?: any[];
  adoptPrograms?: any[];
}) {
  const { t, d, lang } = useStore();
  const heroTitle = (hero && hero[lang]?.title) || t("hero_title");
  const heroSub = (hero && hero[lang]?.subtitle) || t("hero_sub");

  const howSteps = [
    { n: "01", title: t("how_t1"), desc: t("how_d1") },
    { n: "02", title: t("how_t2"), desc: t("how_d2") },
    { n: "03", title: t("how_t3"), desc: t("how_d3") },
    { n: "04", title: t("how_t4"), desc: t("how_d4") },
  ];

  return (
    <div className="anim-fade-up">
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden bg-olive-950 text-cream-50">
        <img
          src="/images/hero.jpg"
          alt="Palestinian artisan products"
          className="absolute inset-0 w-full h-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-olive-950 via-olive-950/70 to-olive-950/30" />
        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-28 lg:py-32">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-cream-50/10 border border-cream-50/25 px-4 py-1.5 text-[12px] font-bold backdrop-blur">
              <svg viewBox="0 0 20 20" className="w-3.5 h-3.5 fill-olive-300"><path d="M10 2C6 6 3 8 3 12a7 7 0 0014 0c0-4-3-6-7-10zm0 15.5a5.5 5.5 0 01-5.5-5.5c0-.9.2-1.8.6-2.6 2 .8 4.4.6 6.4-1.2-1.4 2.6-1 5.5 2.4 6.6a5.5 5.5 0 01-3.9 2.7z" /></svg>
              {t("hero_badge")}
            </span>
            <h1 className="font-display text-4xl md:text-6xl font-bold mt-5 leading-[1.1]">{heroTitle}</h1>
            <p className="mt-4 text-cream-200 text-base md:text-lg leading-relaxed max-w-xl">{heroSub}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/products"
                className="rounded-xl bg-cream-50 text-olive-900 font-bold px-6 py-3.5 hover:bg-white transition shadow-lg"
              >
                {t("hero_shop")}
              </Link>
              <Link
                href="/apply-seller"
                className="rounded-xl border-2 border-cream-50/60 text-cream-50 font-bold px-6 py-3.5 hover:bg-cream-50/10 transition"
              >
                {t("hero_sell")}
              </Link>
            </div>
          </div>
          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl">
            {[
              { v: stats.products, l: t("stat_products") },
              { v: stats.sellers, l: t("stat_sellers") },
              { v: stats.countries, l: t("stat_countries") },
              { v: stats.reviews, l: t("stat_reviews") },
            ].map((s, i) => (
              <div key={i} className="bg-cream-50/8 border border-cream-50/15 rounded-2xl px-4 py-3 backdrop-blur">
                <div className="font-display text-2xl font-bold">{fmtNum(s.v)}+</div>
                <div className="text-[11px] text-cream-200/90 font-semibold">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <div className="embroidery-strip" />

      {/* ---------- CATEGORIES ---------- */}
      <section className="max-w-7xl mx-auto px-4 py-12 md:py-16">
        <SectionHead title={t("home_categories_title")} sub={t("home_categories_sub")} />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {categories.map((c) => (
            <Link
              key={c.slug}
              href={`/products?category=${c.slug}`}
              className="group bg-white border border-cream-200 rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-olive-400 hover:shadow-md transition text-center"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform">{c.icon}</span>
              <span className="text-[13px] font-bold text-ink-700 leading-tight">{d({ ar: c.nameAr, en: c.nameEn })}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------- FEATURED ---------- */}
      <section className="max-w-7xl mx-auto px-4 pb-12 md:pb-16">
        <SectionHead
          title={t("home_featured_title")}
          sub={t("home_featured_sub")}
          action={
            <Link href="/products" className="text-sm font-bold text-olive-700 hover:text-olive-900 shrink-0">
              {t("view_all")} ←
            </Link>
          }
        />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {featured.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      </section>

      {/* ---------- STORY ---------- */}
      <section className="leaf-bg bg-cream-100/60 py-14 md:py-20">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/34803738/pexels-photo-34803738.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Olive grove"
              loading="lazy"
              className="rounded-3xl shadow-xl w-full aspect-[4/3] object-cover"
            />
            <div className="absolute -bottom-4 -end-4 bg-olive-700 text-cream-50 rounded-2xl px-5 py-4 shadow-lg max-w-[200px]">
              <div className="font-display text-2xl font-bold">100+</div>
              <div className="text-[11px] font-semibold opacity-90">
                {lang === "ar" ? "سنة عمر أشجار زيتون مزارعنا" : "years old are our olive trees"}
              </div>
            </div>
          </div>
          <div>
            <span className="text-clay-600 font-bold text-sm">{t("home_story_kicker")}</span>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-ink-900 mt-2 leading-tight">{t("home_story_title")}</h2>
            <p className="text-ink-600 leading-relaxed mt-4">{t("home_story_body")}</p>
            <div className="mt-6 flex gap-3">
              <Link href="/about" className="rounded-xl bg-olive-700 text-cream-50 font-bold px-5 py-3 text-sm hover:bg-olive-800 transition">
                {t("nav_about")}
              </Link>
              <Link href="/how-it-works" className="rounded-xl border border-olive-300 text-olive-800 font-bold px-5 py-3 text-sm hover:bg-olive-50 transition">
                {t("nav_how")}
              </Link>
            </div>
          </div>
        </div>
      </section>

      <AdoptHomeSections initialTrees={adoptTrees} initialFarmers={adoptFarmers} initialPrograms={adoptPrograms} />

      {/* ---------- NEW ARRIVALS ---------- */}
      <section className="max-w-7xl mx-auto px-4 py-12 md:py-16">
        <SectionHead title={t("home_new_title")} />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {newest.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      </section>

      {/* ---------- HOW IT WORKS ---------- */}
      <section className="bg-olive-950 text-cream-50 py-14 md:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl md:text-4xl font-bold">{t("how_title")}</h2>
            <p className="text-cream-300 mt-2">{t("how_sub")}</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {howSteps.map((s) => (
              <div key={s.n} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition">
                <div className="font-display text-4xl font-bold text-olive-300/70">{s.n}</div>
                <h3 className="font-bold mt-3">{s.title}</h3>
                <p className="text-sm text-cream-300 mt-2 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- SELLERS ---------- */}
      <section className="max-w-7xl mx-auto px-4 py-12 md:py-16">
        <SectionHead title={t("home_sellers_title")} sub={t("home_sellers_sub")} />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {sellers.map((s) => (
            <Link
              key={s.id}
              href={`/seller/${s.slug}`}
              className="group bg-white border border-cream-200 rounded-2xl overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition"
            >
              {s.images[0] ? (
                <img src={s.images[0]} alt={s.shopName} loading="lazy" className="w-full aspect-[16/9] object-cover group-hover:scale-105 transition-transform duration-500" />
              ) : (
                <div className="w-full aspect-[16/9] bg-olive-100" />
              )}
              <div className="p-4">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-bold text-ink-900 truncate">{s.shopName}</h3>
                  <span className="text-xs text-ink-400 shrink-0">{s.city ?? s.region ?? "Palestine"}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <Stars value={s.rating} />
                  <span className="text-[11px] text-ink-400">{s.productCount} {t("products")}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------- POPULAR ---------- */}
      <section className="max-w-7xl mx-auto px-4 pb-12 md:pb-16">
        <SectionHead
          title={t("home_popular_title")}
          action={
            <Link href="/products?sort=selling" className="text-sm font-bold text-olive-700 hover:text-olive-900 shrink-0">
              {t("view_all")} ←
            </Link>
          }
        />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {popular.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      </section>

      {/* ---------- REVIEWS ---------- */}
      {reviews.length > 0 && (
        <section className="leaf-bg bg-cream-100/60 py-14 md:py-20">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="font-display text-3xl font-bold text-ink-900 text-center mb-10">{t("home_review_title")}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {reviews.map((r) => (
                <div key={r.id} className="bg-white rounded-2xl border border-cream-200 p-5">
                  <Stars value={r.rating} />
                  <p className="text-sm text-ink-700 mt-3 leading-relaxed line-clamp-4">{d({ ar: r.commentAr ?? "", en: r.commentEn ?? "" }) || "★★★★★"}</p>
                  <div className="mt-4 pt-3 border-t border-cream-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-ink-900">{r.userName}</span>
                    <span className="text-[11px] text-ink-400">{d({ ar: r.productAr ?? "", en: r.productEn ?? "" })}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ---------- SELLER CTA ---------- */}
      <section className="max-w-7xl mx-auto px-4 py-14 md:py-20">
        <div className="rounded-3xl bg-olive-700 text-cream-50 px-6 py-12 md:py-16 text-center relative overflow-hidden">
          <div className="embroidery-strip absolute top-0 inset-x-0" />
          <h2 className="font-display text-3xl md:text-4xl font-bold">{t("home_cta_title")}</h2>
          <p className="text-cream-100/90 mt-3 max-w-xl mx-auto">{t("home_cta_body")}</p>
          <Link href="/apply-seller" className="inline-block mt-7 rounded-xl bg-cream-50 text-olive-900 font-bold px-7 py-3.5 hover:bg-white transition shadow-lg">
            {t("home_cta_btn")}
          </Link>
        </div>
      </section>
    </div>
  );
}
