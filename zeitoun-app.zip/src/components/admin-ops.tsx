"use client";

import { useEffect, useState } from "react";
import { useStore } from "./store";
import { Btn, Field, Select, Spinner, StatusBadge, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";
import { fmtDate } from "@/lib/utils";

const ALL = ["pending", "confirmed", "preparing", "ready", "shipped", "in_transit", "delivered", "cancelled", "refunded"];

export function OrdersTab() {
  const { t, fmt, lang, toast } = useStore();
  const [items, setItems] = useState<any[] | null>(null);

  const load = () => fetch("/api/admin/orders", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const setStatus = async (id: number, status: string) => {
    try {
      await api(`/api/orders/${id}`, { method: "PATCH", body: { status } });
      toast(t("t_order_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
      <table className="w-full text-sm min-w-[760px]">
        <thead>
          <tr className="border-b border-cream-200 text-xs text-ink-400">
            <th className="text-start p-3 font-bold">{t("ad_orders")}</th>
            <th className="text-start p-3 font-bold">{t("ad_users")}</th>
            <th className="text-start p-3 font-bold">{t("ad_sellers")}</th>
            <th className="text-start p-3 font-bold">{t("total")}</th>
            <th className="text-start p-3 font-bold">{t("date")}</th>
            <th className="p-3">{t("status")}</th>
          </tr>
        </thead>
        <tbody>
          {items.map((o) => (
            <tr key={o.id} className="border-b border-cream-100 last:border-0">
              <td className="p-3 font-display font-bold" dir="ltr">{o.orderNumber}</td>
              <td className="p-3">{o.customer}<div className="text-[11px] text-ink-400" dir="ltr">{o.customerEmail}</div></td>
              <td className="p-3">{o.seller.shopName}</td>
              <td className="p-3 font-bold">{fmt(o.totalCents)}</td>
              <td className="p-3 text-ink-400">{fmtDate(o.createdAt, lang)}</td>
              <td className="p-3">
                <Select value={o.status} onChange={(e) => setStatus(o.id, e.target.value)} className="!w-36 !py-1.5 !text-xs">
                  {ALL.map((s) => (
                    <option key={s} value={s}>{t(`st_${s}`)}</option>
                  ))}
                </Select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function ReviewsTab() {
  const { t, d, lang, toast } = useStore();
  const [items, setItems] = useState<any[] | null>(null);

  const load = () => fetch("/api/admin/reviews", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const del = async (id: number) => {
    try {
      await api(`/api/admin/reviews/${id}`, { method: "DELETE" });
      toast(t("t_deleted"));
      load();
    } catch {
      /* review deletion is admin-only; fallback endpoint */
      try {
        await api("/api/reviews/" + id, { method: "DELETE" });
        load();
      } catch (e2) {
        toast(errMsg(e2, lang), "err");
      }
    }
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-3">
      {items.map((r) => (
        <div key={r.id} className={`rounded-2xl border p-4 ${r.status === "removed" ? "border-cream-200 bg-cream-100/50 opacity-60" : "border-cream-200 bg-white"}`}>
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <span className="text-gold-400 font-bold">{"★".repeat(r.rating)}</span>
              <div>
                <div className="text-sm font-bold text-ink-900">{r.productAr} <span className="text-ink-400 font-normal">({r.userName})</span></div>
                <div className="text-xs text-ink-400">{fmtDate(r.createdAt, lang)}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <StatusBadge status={r.status === "active" ? "active" : "archived"} />
              {r.status === "active" && <button onClick={() => del(r.id)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>}
            </div>
          </div>
          {(r.commentAr || r.commentEn) && <p className="text-sm text-ink-600 mt-2">{d({ ar: r.commentAr, en: r.commentEn })}</p>}
        </div>
      ))}
    </div>
  );
}

export function ReportsTab() {
  const { t, lang, toast } = useStore();
  const [items, setItems] = useState<any[] | null>(null);

  const load = () => fetch("/api/admin/reports", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const act = async (id: number, status: string) => {
    try {
      await api("/api/admin/reports", { method: "PUT", body: { id, status } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-3">
      {items.length === 0 && <p className="text-sm text-ink-400">—</p>}
      {items.map((r) => (
        <div key={r.id} className="rounded-2xl border border-cream-200 bg-white p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <span className="text-xs font-bold rounded-full bg-clay-100 text-clay-700 px-2.5 py-1">
                {r.targetType === "user" ? t("ad_users") : t("nav_messages")} #{r.targetId}
              </span>
              <span className="text-xs text-ink-400 ms-2">{r.reporter} · {fmtDate(r.createdAt, lang)}</span>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={r.status} />
              {r.status === "open" && (
                <>
                  <Btn onClick={() => act(r.id, "resolved")} className="!px-3 !py-1.5 !text-xs">{t("ad_resolved")}</Btn>
                  <Btn variant="ghost" onClick={() => act(r.id, "dismissed")} className="!px-3 !py-1.5 !text-xs">{t("ad_dismiss")}</Btn>
                </>
              )}
            </div>
          </div>
          <p className="text-sm text-ink-600 mt-2">{r.reason}</p>
        </div>
      ))}
    </div>
  );
}

export function ContentTab() {
  const { t, toast, lang } = useStore();
  const [hero, setHero] = useState<any>(null);
  const [ann, setAnn] = useState<any>(null);

  useEffect(() => {
    fetch("/api/admin/content", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => {
      const h = x?.items?.find((i: any) => i.key === "hero");
      const a = x?.items?.find((i: any) => i.key === "announcement");
      setHero(h?.value ?? { ar: { title: "", subtitle: "" }, en: { title: "", subtitle: "" } });
      setAnn(a?.value ?? { ar: "", en: "" });
    }).catch(() => {});
  }, []);

  const save = async () => {
    try {
      await api("/api/admin/content", { method: "PUT", body: { key: "hero", value: hero } });
      await api("/api/admin/content", { method: "PUT", body: { key: "announcement", value: ann } });
      toast(t("t_saved"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!hero) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="max-w-2xl space-y-4">
      <p className="text-sm text-ink-400">{t("ad_content_hint")}</p>
      <div className="rounded-2xl border border-cream-200 bg-white p-5 space-y-3.5">
        <h3 className="font-bold text-ink-900">Hero</h3>
        <div className="grid md:grid-cols-2 gap-3">
          <Field label="Hero title (ع)"><TextInput value={hero.ar?.title ?? ""} onChange={(e) => setHero({ ...hero, ar: { ...hero.ar, title: e.target.value } })} /></Field>
          <Field label="Hero title (EN)"><TextInput dir="ltr" value={hero.en?.title ?? ""} onChange={(e) => setHero({ ...hero, en: { ...hero.en, title: e.target.value } })} /></Field>
          <Field label="Hero subtitle (ع)"><TextInput value={hero.ar?.subtitle ?? ""} onChange={(e) => setHero({ ...hero, ar: { ...hero.ar, subtitle: e.target.value } })} /></Field>
          <Field label="Hero subtitle (EN)"><TextInput dir="ltr" value={hero.en?.subtitle ?? ""} onChange={(e) => setHero({ ...hero, en: { ...hero.en, subtitle: e.target.value } })} /></Field>
        </div>
      </div>
      <div className="rounded-2xl border border-cream-200 bg-white p-5 space-y-3.5">
        <h3 className="font-bold text-ink-900">Announcement bar</h3>
        <Field label="Arabic"><TextInput value={ann.ar ?? ""} onChange={(e) => setAnn({ ...ann, ar: e.target.value })} /></Field>
        <Field label="English"><TextInput dir="ltr" value={ann.en ?? ""} onChange={(e) => setAnn({ ...ann, en: e.target.value })} /></Field>
      </div>
      <Btn onClick={save}>{t("save")}</Btn>
    </div>
  );
}

export function CurrenciesTab() {
  const { t, d, toast, lang } = useStore();
  const [items, setItems] = useState<any[] | null>(null);

  const load = () => fetch("/api/admin/currencies", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const act = async (id: number, body: Record<string, unknown>) => {
    await api("/api/admin/currencies", { method: "PUT", body: { id, ...body } }).catch((e) => toast(errMsg(e, lang), "err"));
    load();
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="max-w-2xl rounded-2xl border border-cream-200 bg-white overflow-x-auto">
      <table className="w-full text-sm min-w-[480px]">
        <thead>
          <tr className="border-b border-cream-200 text-xs text-ink-400">
            <th className="text-start p-3 font-bold">Code</th>
            <th className="text-start p-3 font-bold">{t("name")}</th>
            <th className="text-start p-3 font-bold">{t("ad_rate")}</th>
            <th className="p-3">{t("active")}</th>
          </tr>
        </thead>
        <tbody>
          {items.map((c) => (
            <tr key={c.id} className="border-b border-cream-100 last:border-0">
              <td className="p-3 font-bold" dir="ltr">{c.symbol} {c.code}</td>
              <td className="p-3">{d({ ar: c.nameAr, en: c.nameEn })}</td>
              <td className="p-3">
                <TextInput dir="ltr" type="number" step="0.0001" defaultValue={c.ratePerUsd}
                  onBlur={(e) => parseFloat(e.target.value) !== c.ratePerUsd && act(c.id, { ratePerUsd: parseFloat(e.target.value) || 1 })} className="!w-28 !py-1.5 !text-xs" />
              </td>
              <td className="p-3 text-center">
                <input type="checkbox" checked={c.active} onChange={(e) => act(c.id, { active: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function ShippingTab() {
  const { t, d, toast, lang } = useStore();
  const [data, setData] = useState<any | null>(null);

  const load = () => fetch("/api/admin/shipping", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then(setData).catch(() => {});
  useEffect(() => { load(); }, []);

  const act = async (kind: string, id: number, body: Record<string, unknown>) => {
    try {
      await api("/api/admin/shipping", { method: "PUT", body: { kind, id, ...body } });
      toast(t("t_saved"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!data) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_methods")}</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {data.methods.map((m: any) => (
            <div key={m.id} className="rounded-2xl border border-cream-200 bg-white p-4 space-y-2.5">
              <div className="flex gap-2">
                <TextInput value={m.nameAr} onChange={(e) => act("method", m.id, { nameAr: e.target.value })} className="!py-1.5 !text-xs" />
                <TextInput dir="ltr" value={m.nameEn} onChange={(e) => act("method", m.id, { nameEn: e.target.value })} className="!py-1.5 !text-xs" />
              </div>
              <div className="grid grid-cols-4 gap-2">
                <Field label={t("ad_days")}>
                  <div className="flex gap-1">
                    <TextInput dir="ltr" type="number" value={m.daysMin} onChange={(e) => act("method", m.id, { daysMin: Number(e.target.value) })} className="!py-1.5 !text-xs !w-12" />
                    <TextInput dir="ltr" type="number" value={m.daysMax} onChange={(e) => act("method", m.id, { daysMax: Number(e.target.value) })} className="!py-1.5 !text-xs !w-12" />
                  </div>
                </Field>
                <Field label={t("ad_base")}>
                  <TextInput dir="ltr" type="number" value={(m.baseCents / 100).toString()} onChange={(e) => act("method", m.id, { baseCents: Math.round(Number(e.target.value || 0) * 100) })} className="!py-1.5 !text-xs" />
                </Field>
                <Field label={t("ad_per_kg")}>
                  <TextInput dir="ltr" type="number" value={(m.perKgCents / 100).toString()} onChange={(e) => act("method", m.id, { perKgCents: Math.round(Number(e.target.value || 0) * 100) })} className="!py-1.5 !text-xs" />
                </Field>
                <div className="flex items-end">
                  <label className="flex items-center gap-1.5 text-xs font-bold text-ink-600">
                    <input type="checkbox" checked={m.active} onChange={(e) => act("method", m.id, { active: e.target.checked })} className="w-4 h-4 accent-olive-700" />
                    {t("active")}
                  </label>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_countries")}</h3>
        <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
          <table className="w-full text-sm min-w-[520px]">
            <thead>
              <tr className="border-b border-cream-200 text-xs text-ink-400">
                <th className="text-start p-3 font-bold">Country</th>
                <th className="text-start p-3 font-bold">{t("apply_region")}</th>
                <th className="text-start p-3 font-bold">{t("ad_surcharge")}</th>
                <th className="p-3">{t("active")}</th>
              </tr>
            </thead>
            <tbody>
              {data.countries.map((c: any) => (
                <tr key={c.id} className="border-b border-cream-100 last:border-0">
                  <td className="p-3 font-bold">{d({ ar: c.nameAr, en: c.nameEn })} <span className="text-ink-300 text-xs" dir="ltr">{c.code}</span></td>
                  <td className="p-3 text-ink-400">{c.region}</td>
                  <td className="p-3">
                    <TextInput dir="ltr" type="number" value={(c.surchargeCents / 100).toString()} onChange={(e) => act("country", c.id, { surchargeCents: Math.round(Number(e.target.value || 0) * 100) })} className="!w-24 !py-1.5 !text-xs" />
                  </td>
                  <td className="p-3 text-center">
                    <input type="checkbox" checked={c.active} onChange={(e) => act("country", c.id, { active: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function OffersTab() {
  const { t, toast, lang } = useStore();
  const [items, setItems] = useState<any[] | null>(null);
  const [form, setForm] = useState({ code: "", type: "percent", value: "10", minSubtotalCents: "0" });

  const load = () => fetch("/api/admin/offers", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  useEffect(() => { load(); }, []);

  const add = async () => {
    try {
      await api("/api/admin/offers", {
        body: { code: form.code, type: form.type, value: Number(form.value), minSubtotalCents: Number(form.minSubtotalCents) },
      });
      setForm({ code: "", type: "percent", value: "10", minSubtotalCents: "0" });
      toast(t("t_saved"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };
  const act = async (id: number, body: Record<string, unknown>) => {
    await api("/api/admin/offers", { method: "PUT", body: { id, ...body } }).catch((e) => toast(errMsg(e, lang), "err"));
    load();
  };
  const del = async (id: number) => {
    await api("/api/admin/offers", { method: "DELETE", body: { id } }).catch((e) => toast(errMsg(e, lang), "err"));
    load();
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="max-w-2xl space-y-4">
      <div className="rounded-2xl border border-cream-200 bg-white p-4 flex flex-wrap items-end gap-3">
        <div className="w-28"><Field label={t("ad_code")}><TextInput dir="ltr" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} /></Field></div>
        <div className="w-32">
          <Field label={t("ad_type")}>
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="percent">{t("ad_percent")}</option>
              <option value="fixed">{t("ad_fixed")}</option>
            </Select>
          </Field>
        </div>
        <div className="w-24"><Field label={t("ad_value")}><TextInput dir="ltr" type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} /></Field></div>
        <div className="w-32"><Field label={t("ad_min_sub")}><TextInput dir="ltr" type="number" value={form.minSubtotalCents} onChange={(e) => setForm({ ...form, minSubtotalCents: e.target.value })} /></Field></div>
        <Btn onClick={add} disabled={!form.code.trim()}>{t("ad_add_offer")}</Btn>
      </div>
      <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
        <table className="w-full text-sm min-w-[520px]">
          <thead>
            <tr className="border-b border-cream-200 text-xs text-ink-400">
              <th className="text-start p-3 font-bold">{t("ad_code")}</th>
              <th className="text-start p-3 font-bold">{t("ad_type")}</th>
              <th className="text-start p-3 font-bold">{t("ad_value")}</th>
              <th className="text-start p-3 font-bold">Uses</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {items.map((o) => (
              <tr key={o.id} className="border-b border-cream-100 last:border-0">
                <td className="p-3 font-bold font-display" dir="ltr">{o.code}</td>
                <td className="p-3">{o.type === "percent" ? t("ad_percent") : t("ad_fixed")}</td>
                <td className="p-3">{o.type === "percent" ? `${o.value}%` : `$${o.value / 100}`}</td>
                <td className="p-3">{o.usageCount}</td>
                <td className="p-3">
                  <div className="flex gap-2 justify-end items-center">
                    <input type="checkbox" checked={o.active} onChange={(e) => act(o.id, { active: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
                    <button onClick={() => del(o.id)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
