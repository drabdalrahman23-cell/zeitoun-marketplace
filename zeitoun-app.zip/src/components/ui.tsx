"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";
import { useStore } from "./store";
import { errMsg, api } from "@/lib/api";
import type { ProductView } from "@/lib/types";

/* ---------------- Buttons ---------------- */

export function Btn({
  children,
  onClick,
  variant = "primary",
  className = "",
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "outline" | "ghost" | "danger" | "clay";
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none";
  const styles = {
    primary: "bg-olive-700 text-cream-50 hover:bg-olive-800 shadow-sm",
    outline: "border border-olive-300 text-olive-800 hover:bg-olive-50 bg-white/60",
    ghost: "text-ink-600 hover:bg-cream-100",
    danger: "bg-clay-600 text-white hover:bg-clay-700",
    clay: "bg-clay-500 text-white hover:bg-clay-600",
  }[variant];
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${styles} px-4 py-2.5 text-sm ${className}`}>
      {children}
    </button>
  );
}

/* ---------------- Form fields ---------------- */

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="block text-sm font-semibold text-ink-700 mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-xs text-ink-400 mt-1">{hint}</span>}
    </label>
  );
}

const inputCls =
  "w-full rounded-xl border border-cream-300 bg-white px-3.5 py-2.5 text-sm outline-none focus:border-olive-500 focus:ring-2 focus:ring-olive-100 transition placeholder:text-ink-300";

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`${inputCls} ${props.className ?? ""}`} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`${inputCls} min-h-[90px] ${props.className ?? ""}`} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`${inputCls} ${props.className ?? ""}`} />;
}

/* ---------------- Misc ---------------- */

export function Stars({ value, className = "" }: { value: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-0.5 ${className}`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} viewBox="0 0 20 20" className={`w-3.5 h-3.5 ${i <= Math.round(value) ? "fill-gold-400" : "fill-cream-300"}`}>
          <path d="M10 1.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L10 14.9l-5.3 2.7 1-5.8L1.5 7.7l5.9-.9z" />
        </svg>
      ))}
    </span>
  );
}

export function Badge({ children, tone = "olive" }: { children: ReactNode; tone?: "olive" | "clay" | "gold" | "gray" | "green" }) {
  const tones = {
    olive: "bg-olive-100 text-olive-800",
    clay: "bg-clay-100 text-clay-700",
    gold: "bg-gold-300/30 text-gold-500",
    gray: "bg-cream-100 text-ink-600",
    green: "bg-olive-700 text-cream-50",
  }[tone];
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ${tones}`}>{children}</span>;
}

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <svg className={`animate-spin h-5 w-5 text-olive-600 ${className}`} viewBox="0 0 24 24" fill="none">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}

export function EmptyState({ icon, title, hint, action }: { icon: ReactNode; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center anim-fade-up">
      <div className="w-16 h-16 rounded-2xl bg-olive-50 flex items-center justify-center text-olive-600 mb-4">{icon}</div>
      <h3 className="font-display text-lg font-bold text-ink-900">{title}</h3>
      {hint && <p className="text-sm text-ink-400 mt-1 max-w-sm">{hint}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function SectionHead({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-6">
      <div>
        <h2 className="font-display text-2xl md:text-3xl font-bold text-ink-900 tracking-tight">{title}</h2>
        {sub && <p className="text-ink-400 text-sm mt-1">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end md:items-center justify-center p-0 md:p-6">
      <div className="absolute inset-0 bg-ink-900/50 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative bg-cream-50 w-full md:max-w-lg rounded-t-3xl md:rounded-3xl shadow-2xl anim-pop max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-cream-50/95 backdrop-blur flex items-center justify-between px-5 py-4 border-b border-cream-200 z-10">
          <h3 className="font-bold text-ink-900">{title}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-cream-100 flex items-center justify-center text-ink-400">
            <svg viewBox="0 0 20 20" className="w-4 h-4 fill-current"><path d="M6 5l8 8m0-8L6 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" /></svg>
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

/* ---------------- Product card ---------------- */

export function ProductCard({ p }: { p: ProductView }) {
  const { t, d, fmt, addToCart, toast, me, lang } = useStore();
  const [faved, setFaved] = useState(false);

  const add = () => {
    if (p.stock <= 0) return;
    addToCart(p, 1);
    toast(t("t_added"));
  };

  const fav = async () => {
    if (!me) {
      toast(t("login_required"), "err");
      return;
    }
    try {
      if (faved) await api("/api/favorites", { method: "DELETE", body: { productId: p.id } });
      else await api("/api/favorites", { body: { productId: p.id } });
      setFaved(!faved);
      toast(t(faved ? "t_fav_removed" : "t_fav_added"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  return (
    <div className="group bg-white rounded-2xl border border-cream-200 overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all flex flex-col">
      <Link href={`/products/${p.slug}`} className="relative block aspect-[4/3] overflow-hidden bg-cream-100">
        {p.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={p.images[0]} alt={d({ ar: p.nameAr, en: p.nameEn })} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-3xl">🫒</div>
        )}
        {p.stock <= 0 && (
          <span className="absolute top-2 start-2 bg-ink-900/85 text-cream-50 text-[11px] font-bold rounded-full px-2.5 py-1">{t("out_of_stock")}</span>
        )}
        {p.isFeatured && p.stock > 0 && (
          <span className="absolute top-2 start-2 bg-clay-500 text-white text-[11px] font-bold rounded-full px-2.5 py-1">{t("featured")}</span>
        )}
        <button
          onClick={(e) => {
            e.preventDefault();
            fav();
          }}
          className="absolute top-2 end-2 w-8 h-8 rounded-full bg-white/90 shadow flex items-center justify-center hover:scale-110 transition"
          aria-label="favorite"
        >
          <svg viewBox="0 0 24 24" className={`w-4.5 h-4.5 ${faved ? "fill-clay-500 stroke-clay-500" : "fill-none stroke-ink-600"}`} strokeWidth="2">
            <path d="M12 21s-7.5-4.8-9.5-9.2C.9 8.4 3 5 6.4 5c2 0 3.4 1 4.1 2.2h3C14.2 6 15.6 5 17.6 5 21 5 23.1 8.4 21.5 11.8 19.5 16.2 12 21 12 21z" transform="scale(0.9) translate(1.3 1)" />
          </svg>
        </button>
      </Link>
      <div className="p-3.5 flex flex-col gap-1.5 flex-1">
        <div className="flex items-center gap-1.5 text-[11px] text-ink-400 font-semibold">
          <span className="truncate">{p.seller.shopName}</span>
          {p.originRegion && <span className="shrink-0 rounded-full bg-cream-100 px-1.5 py-0.5">{p.originRegion}</span>}
        </div>
        <Link href={`/products/${p.slug}`} className="font-bold text-sm text-ink-900 leading-snug line-clamp-2 hover:text-olive-700">
          {d({ ar: p.nameAr, en: p.nameEn })}
        </Link>
        <div className="flex items-center gap-1.5">
          <Stars value={p.rating} />
          <span className="text-[11px] text-ink-400">
            {p.rating > 0 ? `${p.rating.toFixed(1)} (${p.reviewCount})` : p.reviewCount === 0 ? "—" : ""}
          </span>
        </div>
        <div className="mt-auto flex items-center justify-between pt-2">
          <span className="font-display font-bold text-ink-900">{fmt(p.priceCents)}</span>
          <button
            onClick={add}
            disabled={p.stock <= 0}
            className="w-9 h-9 rounded-xl bg-olive-700 text-cream-50 flex items-center justify-center hover:bg-olive-800 active:scale-95 transition disabled:opacity-40"
            aria-label={t("add_to_cart")}
          >
            <svg viewBox="0 0 24 24" className="w-4.5 h-4.5 fill-none stroke-current" strokeWidth="2.2" strokeLinecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Status badge ---------------- */

export function StatusBadge({ status }: { status: string }) {
  const { t } = useStore();
  const tones: Record<string, string> = {
    pending: "bg-gold-300/40 text-gold-500",
    confirmed: "bg-olive-100 text-olive-800",
    preparing: "bg-olive-100 text-olive-800",
    ready: "bg-olive-100 text-olive-800",
    shipped: "bg-blue-100 text-blue-700",
    in_transit: "bg-blue-100 text-blue-700",
    delivered: "bg-olive-700 text-white",
    cancelled: "bg-cream-200 text-ink-600",
    refunded: "bg-clay-100 text-clay-700",
    active: "bg-olive-700 text-white",
    approved: "bg-olive-700 text-white",
    rejected: "bg-clay-100 text-clay-700",
    archived: "bg-cream-200 text-ink-600",
    suspended: "bg-clay-100 text-clay-700",
    open: "bg-clay-100 text-clay-700",
    resolved: "bg-olive-700 text-white",
    dismissed: "bg-cream-200 text-ink-600",
  };
  const label = status === "active" || status === "approved" || status === "open" || status === "resolved" || status === "dismissed" || status === "archived" || status === "suspended"
    ? t(status === "active" ? "active" : status === "approved" ? "approved" : status)
    : t(`st_${status}`);
  return <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ${tones[status] ?? "bg-cream-100 text-ink-600"}`}>{label}</span>;
}
