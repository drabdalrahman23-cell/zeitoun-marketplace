"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useStore } from "./store";

export function OliveLogo({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden>
      <path d="M8 34 C14 26 22 15 32 7" stroke="#465628" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M20 18 C14 16 10 17 6.5 20 C10 24 16 24 20 18z" fill="#718a41" />
      <path d="M27 11 C23 5.5 18 4 13 5.5 C14 11 20 14 27 11z" fill="#576d2f" />
      <circle cx="12" cy="30" r="3.4" fill="#333d21" />
      <circle cx="18" cy="25.5" r="2.6" fill="#465628" />
      <circle cx="12" cy="30" r="1" fill="#718a41" opacity="0.7" />
    </svg>
  );
}

export function Header() {
  const { t, lang, setLang, me, refreshMe, signOut, cartCount, currency, setCurrency, currencies, d } = useStore();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [menu, setMenu] = useState(false);
  const [unread, setUnread] = useState(0);
  const [announce, setAnnounce] = useState<{ ar: string; en: string } | null>(null);

  useEffect(() => {
    refreshMe();
  }, [refreshMe]);

  useEffect(() => {
    if (!me) return;
    const load = () =>
      fetch("/api/notifications", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => setUnread(data?.unread ?? 0))
        .catch(() => {});
    load();
    const iv = setInterval(load, 45000);
    return () => clearInterval(iv);
  }, [me]);

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        const row = (data?.content ?? []).find((c: { key: string }) => c.key === "announcement");
        if (row) setAnnounce(row.value);
      })
      .catch(() => {});
  }, []);

  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    router.push(q.trim() ? `/products?q=${encodeURIComponent(q.trim())}` : "/products");
  };

  return (
    <header className="sticky top-0 z-50">
      {announce && d(announce) && (
        <div className="bg-olive-900 text-cream-50 text-center text-[12px] font-semibold py-1.5 px-3">{d(announce)}</div>
      )}
      <div className="bg-cream-50/95 backdrop-blur border-b border-cream-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-3">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <OliveLogo />
            <span className="leading-none">
              <span className="font-display font-bold text-lg text-ink-900 block">Zeitoun</span>
              <span className="text-[11px] text-olive-700 font-bold block -mt-0.5">زيتون</span>
            </span>
          </Link>

          <Link
            href="/adopt"
            className="hidden xl:flex items-center gap-1.5 rounded-xl bg-olive-100 hover:bg-olive-200 text-olive-900 px-3 py-2 text-xs font-bold transition shrink-0"
          >
            🌿 {t("ad_nav")}
          </Link>

          <form onSubmit={submitSearch} className="hidden md:flex flex-1 max-w-xl mx-auto">
            <div className="flex w-full rounded-xl border border-cream-300 bg-white overflow-hidden focus-within:border-olive-500 focus-within:ring-2 focus-within:ring-olive-100">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("search_ph")}
                className="flex-1 px-4 py-2.5 text-sm outline-none placeholder:text-ink-300"
              />
              <button type="submit" className="px-4 bg-olive-700 text-cream-50 hover:bg-olive-800 transition" aria-label={t("search_btn")}>
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2.4" strokeLinecap="round">
                  <circle cx="11" cy="11" r="7" />
                  <path d="M20 20l-3.5-3.5" />
                </svg>
              </button>
            </div>
          </form>

          <div className="flex items-center gap-1.5 ms-auto">
            <button
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              className="h-9 px-3 rounded-xl border border-cream-300 bg-white text-xs font-bold text-ink-700 hover:border-olive-400 transition"
            >
              {lang === "ar" ? "EN" : "ع"}
            </button>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="hidden lg:block h-9 rounded-xl border border-cream-300 bg-white text-xs font-bold text-ink-700 px-1.5 outline-none"
              aria-label="currency"
            >
              {currencies.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>

            <Link href="/notifications" className="relative w-9 h-9 rounded-xl flex items-center justify-center text-ink-600 hover:bg-cream-100">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.8">
                <path d="M18 9a6 6 0 10-12 0c0 6-2.5 7-2.5 7h17S18 15 18 9zM10.3 20a2 2 0 003.4 0" />
              </svg>
              {unread > 0 && (
                <span className="absolute -top-0.5 -end-0.5 min-w-4.5 h-4.5 px-1 rounded-full bg-clay-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unread}
                </span>
              )}
            </Link>

            <Link href="/cart" className="relative w-9 h-9 rounded-xl flex items-center justify-center text-ink-600 hover:bg-cream-100" aria-label={t("nav_cart")}>
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.8">
                <path d="M6 7h14l-1.5 8.5a2 2 0 01-2 1.5H9.4a2 2 0 01-2-1.6L5.2 4.5H2.5" />
                <circle cx="10" cy="21" r="1.4" fill="currentColor" stroke="none" />
                <circle cx="16.5" cy="21" r="1.4" fill="currentColor" stroke="none" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -end-0.5 min-w-4.5 h-4.5 px-1 rounded-full bg-olive-700 text-white text-[10px] font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>

            <div className="relative">
              <button
                onClick={() => (me ? setMenu(!menu) : router.push("/auth/login"))}
                className="w-9 h-9 rounded-xl flex items-center justify-center text-ink-600 hover:bg-cream-100"
                aria-label={t("nav_account")}
              >
                {me ? (
                  <span className="w-7 h-7 rounded-full bg-olive-700 text-cream-50 text-xs font-bold flex items-center justify-center">
                    {me.name.slice(0, 1).toUpperCase()}
                  </span>
                ) : (
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.8">
                    <circle cx="12" cy="8" r="4" />
                    <path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5" />
                  </svg>
                )}
              </button>
              {menu && me && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenu(false)} />
                  <div className="absolute end-0 top-11 z-20 w-56 bg-white rounded-2xl shadow-xl border border-cream-200 p-2 anim-pop">
                    <div className="px-3 py-2 border-b border-cream-100 mb-1">
                      <p className="text-sm font-bold text-ink-900 truncate">{me.name}</p>
                      <p className="text-[11px] text-ink-400 truncate">{me.email}</p>
                    </div>
                    {[
                      { href: "/account", label: t("nav_account") },
                      { href: "/orders", label: t("nav_orders") },
                      { href: "/favorites", label: t("nav_favorites") },
                      { href: "/messages", label: t("nav_messages") },
                      me.role === "seller" ? { href: "/dashboard/seller", label: t("seller_dash") } : null,
                      me.role === "admin" ? { href: "/dashboard/admin", label: t("admin_dash") } : null,
                      { href: "/apply-seller", label: t("nav_sell") },
                    ]
                      .filter(Boolean)
                      .map((item, i) => (
                        <Link
                          key={i}
                          href={(item as { href: string; label: string }).href}
                          onClick={() => setMenu(false)}
                          className="block px-3 py-2 rounded-xl text-sm text-ink-700 hover:bg-cream-100 font-semibold"
                        >
                          {(item as { href: string; label: string }).label}
                        </Link>
                      ))}
                    <button
                      onClick={async () => {
                        setMenu(false);
                        await signOut();
                      }}
                      className="w-full text-start px-3 py-2 rounded-xl text-sm text-clay-600 hover:bg-clay-50 font-semibold"
                    >
                      {t("nav_logout")}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* mobile search */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={submitSearch} className="flex w-full rounded-xl border border-cream-300 bg-white overflow-hidden">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("search_ph")}
              className="flex-1 px-3.5 py-2 text-sm outline-none placeholder:text-ink-300"
            />
            <button type="submit" className="px-3.5 bg-olive-700 text-cream-50" aria-label={t("search_btn")}>
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-none stroke-current" strokeWidth="2.4" strokeLinecap="round">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}

export function MobileNav() {
  const { t, cartCount } = useStore();
  const path = usePathname();
  const items = [
    { href: "/", label: t("nav_home"), icon: <path d="M3 11l9-8 9 8v9a2 2 0 01-2 2h-4v-6h-6v6H5a2 2 0 01-2-2z" /> },
    { href: "/products", label: t("nav_shop"), icon: <><path d="M4 7h16l-1.3 9.5a2 2 0 01-2 1.5H7.3a2 2 0 01-2-1.6L4 7z" /><path d="M8.5 9.5V6a3.5 3.5 0 117 0v3.5" /></> },
    { href: "/cart", label: t("nav_cart"), icon: <><path d="M6 7h14l-1.5 8.5a2 2 0 01-2 1.5H9.4a2 2 0 01-2-1.6L5.2 4.5H2.5" /><circle cx="10" cy="21" r="1.2" /><circle cx="16.5" cy="21" r="1.2" /></> },
    { href: "/notifications", label: t("nav_notifs"), icon: <path d="M18 9a6 6 0 10-12 0c0 6-2.5 7-2.5 7h17S18 15 18 9zM10.3 20a2 2 0 003.4 0" /> },
    { href: "/account", label: t("nav_account"), icon: <><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5" /></> },
  ];
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 bg-cream-50/97 backdrop-blur border-t border-cream-200 pb-[env(safe-area-inset-bottom)]">
      <div className="grid grid-cols-5">
        {items.map((it) => {
          const active = it.href === "/" ? path === "/" : path.startsWith(it.href);
          return (
            <Link key={it.href} href={it.href} className={`flex flex-col items-center gap-0.5 py-2 ${active ? "text-olive-700" : "text-ink-400"}`}>
              <svg viewBox="0 0 24 24" className="w-5.5 h-5.5 fill-none stroke-current" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                {it.icon}
                {it.href === "/cart" && cartCount > 0 && (
                  <circle cx="18" cy="5" r="3" className="fill-olive-700 stroke-none" />
                )}
              </svg>
              <span className="text-[10px] font-bold">{it.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function Footer() {
  const { t, d } = useStore();
  return (
    <footer className="bg-olive-950 text-cream-100 mt-16">
      <div className="embroidery-strip" />
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <OliveLogo size={30} />
            <span className="font-display font-bold text-xl">Zeitoun <span className="text-olive-300">| زيتون</span></span>
          </div>
          <p className="text-sm text-cream-300 max-w-sm leading-relaxed">{t("footer_tagline")}</p>
          <p className="text-xs text-cream-300/60 mt-4">{t("tagline")}</p>
        </div>
        <div>
          <h4 className="font-bold text-sm mb-3 text-cream-50">{t("footer_shop")}</h4>
          <ul className="space-y-2 text-sm text-cream-300">
            <li><Link className="hover:text-white" href="/products">{t("nav_shop")}</Link></li>
            <li><Link className="hover:text-white" href="/products?sort=selling">{t("home_popular_title")}</Link></li>
            <li><Link className="hover:text-white" href="/products?category=olive">{t("home_featured_title")}</Link></li>
            <li><Link className="hover:text-white" href="/cart">{t("nav_cart")}</Link></li>
            <li><Link className="hover:text-white" href="/adopt">🌿 {t("ad_nav")}</Link></li>
            <li><Link className="hover:text-white" href="/farmers">{t("ad_nav_farmers")}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold text-sm mb-3 text-cream-50">{t("footer_info")}</h4>
          <ul className="space-y-2 text-sm text-cream-300">
            <li><Link className="hover:text-white" href="/about">{t("nav_about")}</Link></li>
            <li><Link className="hover:text-white" href="/how-it-works">{t("nav_how")}</Link></li>
            <li><Link className="hover:text-white" href="/apply-seller">{t("nav_sell")}</Link></li>
            <li><Link className="hover:text-white" href="/orders">{t("nav_orders")}</Link></li>
            <li><Link className="hover:text-white" href="/my-trees">{t("ad_my_trees")}</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-cream-300/70">
          <span>© {new Date().getFullYear()} {t("footer_rights")}</span>
          <span>{t("footer_made")}</span>
        </div>
      </div>
    </footer>
  );
}
