"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useStore } from "./store";
import { Btn, Field, Modal, Select, Stars, StatusBadge, TextArea, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";
import type { CountryView, ProductFull, ReviewView } from "@/lib/types";
import { fmtDate, timeAgo } from "@/lib/utils";

export function ProductView({ product: p, reviews }: { product: ProductFull; reviews: ReviewView[] }) {
  const { t, d, fmt, addToCart, toast, me, lang, dir } = useStore();
  const router = useRouter();
  const [img, setImg] = useState(0);
  const [qty, setQty] = useState(1);
  const [countries, setCountries] = useState<CountryView[]>([]);
  const [country, setCountry] = useState("US");
  const [quote, setQuote] = useState<number | null>(null);
  const [quoteDays, setQuoteDays] = useState<{ min: number; max: number } | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reviewOpen, setReviewOpen] = useState(false);

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.countries?.length) setCountries(data.countries);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!countries.length) return;
    const ctl = new AbortController();
    fetch("/api/shipping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ countryCode: country, weightGrams: p.weightGrams * qty, methodId: 1 }),
      signal: ctl.signal,
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((q) => {
        if (q) {
          setQuote(q.quoteCents);
          setQuoteDays({ min: q.daysMin, max: q.daysMax });
        } else {
          setQuote(null);
        }
      })
      .catch(() => {});
    return () => ctl.abort();
  }, [country, qty, p.weightGrams, countries.length]);

  const add = () => {
    if (p.stock <= 0) return;
    addToCart(p, qty);
    toast(t("t_added"));
  };
  const buyNow = () => {
    if (p.stock <= 0) return;
    addToCart(p, qty);
    if (!me) router.push("/auth/login?next=/checkout");
    else router.push("/checkout");
  };

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: d({ ar: p.nameAr, en: p.nameEn }), url });
      else {
        await navigator.clipboard.writeText(url);
        toast(t("copied"));
      }
    } catch {
      /* cancelled */
    }
  };

  const messageSeller = async () => {
    if (!me) {
      toast(t("login_required"), "err");
      return;
    }
    try {
      await api("/api/messages", { body: { sellerId: p.seller.id, productId: p.id } });
      router.push("/messages");
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const submitReport = async () => {
    if (!reportReason.trim()) return;
    try {
      await api("/api/reports", { body: { targetType: "user", targetId: p.seller.id, reason: reportReason } });
      setReportOpen(false);
      setReportReason("");
      toast(t("msg_reported"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const details: [string, string][] = useMemo(
    () =>
      [
        [t("p_weight"), `${p.weightGrams} g`],
        [t("p_dims"), p.dimensions ?? "—"],
        [t("p_origin"), [p.originRegion, t("p_country")].filter(Boolean).join("، ")],
        [t("p_season"), p.harvestSeason ?? "—"],
        [t("p_production"), d({ ar: p.productionMethodAr, en: p.productionMethodEn }) || "—"],
        [t("p_ingredients"), d({ ar: p.ingredientsAr, en: p.ingredientsEn }) || "—"],
        [t("p_usage"), d({ ar: p.usageAr, en: p.usageEn }) || "—"],
        [t("p_allergens"), d({ ar: p.allergensAr, en: p.allergensEn }) || "—"],
      ] as [string, string][],
    [p, t, d],
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      {/* breadcrumbs */}
      <div className="text-xs text-ink-400 mb-5 flex items-center gap-1.5 flex-wrap">
        <Link href="/" className="hover:text-olive-700">{t("nav_home")}</Link>
        <span>/</span>
        <Link href={`/products?category=${p.category.slug}`} className="hover:text-olive-700">{d({ ar: p.category.nameAr, en: p.category.nameEn })}</Link>
        <span>/</span>
        <span className="text-ink-700 truncate max-w-[200px]">{d({ ar: p.nameAr, en: p.nameEn })}</span>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
        {/* gallery */}
        <div>
          <div className="rounded-3xl overflow-hidden bg-cream-100 border border-cream-200 aspect-[4/3]">
            {p.images[img] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.images[img]} alt={d({ ar: p.nameAr, en: p.nameEn })} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-5xl">🫒</div>
            )}
          </div>
          {p.images.length > 1 && (
            <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
              {p.images.map((src, i) => (
                <button
                  key={i}
                  onClick={() => setImg(i)}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 ${i === img ? "border-olive-600" : "border-transparent opacity-70"}`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* buy box */}
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Link href={`/products?category=${p.category.slug}`} className="text-[11px] font-bold rounded-full bg-olive-100 text-olive-800 px-3 py-1 hover:bg-olive-200 transition">
              {d({ ar: p.category.nameAr, en: p.category.nameEn })}
            </Link>
            <span className="text-[11px] font-bold rounded-full bg-cream-100 text-ink-600 px-3 py-1">
              {p.originRegion ?? "Palestine"}
            </span>
            {p.status !== "active" && <StatusBadge status={p.status} />}
          </div>

          <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mt-3 leading-tight">{d({ ar: p.nameAr, en: p.nameEn })}</h1>

          <div className="flex items-center gap-2 mt-2.5">
            <Stars value={p.rating} />
            <span className="text-sm text-ink-400 font-semibold">
              {p.rating > 0 ? p.rating.toFixed(1) : "—"} ({p.reviewCount} {t("reviews_count")})
            </span>
            <span className="text-ink-300">·</span>
            <span className="text-sm text-ink-400 font-semibold">{p.salesCount} {t("sold")}</span>
          </div>

          <div className="font-display text-3xl md:text-4xl font-bold text-olive-800 mt-5">{fmt(p.priceCents)}</div>
          {p.stock > 0 && p.stock <= 5 ? (
            <p className="text-clay-600 text-sm font-bold mt-1">{p.stock} {t("stock_left")}</p>
          ) : (
            <p className={`text-sm font-bold mt-1 ${p.stock > 0 ? "text-olive-700" : "text-clay-600"}`}>
              {p.stock > 0 ? t("in_stock") : t("out_of_stock")}
            </p>
          )}

          {/* qty + actions */}
          <div className="flex items-center gap-3 mt-6">
            <div className="flex items-center rounded-xl border border-cream-300 bg-white overflow-hidden">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-10 h-11 text-lg font-bold text-ink-600 hover:bg-cream-100">−</button>
              <span className="w-10 text-center font-bold">{qty}</span>
              <button onClick={() => setQty(Math.min(p.stock || 1, qty + 1))} className="w-10 h-11 text-lg font-bold text-ink-600 hover:bg-cream-100">+</button>
            </div>
            <Btn onClick={add} disabled={p.stock <= 0} className="flex-1">{t("add_to_cart")}</Btn>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <Btn variant="clay" onClick={buyNow} disabled={p.stock <= 0} className="flex-1">{t("buy_now")}</Btn>
            <button onClick={share} className="w-11 h-11 rounded-xl border border-cream-300 bg-white flex items-center justify-center text-ink-600 hover:bg-cream-100 transition" aria-label={t("share")}>
              <svg viewBox="0 0 24 24" className="w-4.5 h-4.5 fill-none stroke-current" strokeWidth="1.8">
                <circle cx="6" cy="12" r="2.6" /><circle cx="18" cy="6" r="2.6" /><circle cx="18" cy="18" r="2.6" />
                <path d="M8.3 10.8l7.4-3.6M8.3 13.2l7.4 3.6" />
              </svg>
            </button>
          </div>

          {/* shipping estimate */}
          {p.shipsInternational && (
            <div className="mt-6 rounded-2xl border border-cream-200 bg-white p-4">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="text-sm font-bold text-ink-700 flex items-center gap-2">
                  <svg viewBox="0 0 24 24" className="w-4.5 h-4.5 fill-none stroke-olive-600" strokeWidth="1.8"><path d="M3 7h11v8H3zM14 10h4l3 3v2h-7z" /><circle cx="7" cy="17.5" r="1.7" /><circle cx="17.5" cy="17.5" r="1.7" /></svg>
                  {t("p_shipping_box")}
                </div>
                <Select value={country} onChange={(e) => setCountry(e.target.value)} className="!w-40 !py-1.5">
                  {countries.map((c) => (
                    <option key={c.code} value={c.code}>{d({ ar: c.nameAr, en: c.nameEn })}</option>
                  ))}
                </Select>
              </div>
              {quote !== null && quoteDays ? (
                <p className="text-sm text-ink-600 mt-2.5">
                  {t("p_est_cost")}: <b className="text-ink-900">{fmt(quote)}</b> · {quoteDays.min}–{quoteDays.max} {t("p_days")}
                </p>
              ) : (
                <p className="text-sm text-ink-400 mt-2.5">—</p>
              )}
            </div>
          )}

          {/* seller box */}
          <div className="mt-4 rounded-2xl border border-cream-200 bg-white p-4 flex items-center gap-4">
            <Link href={`/seller/${p.seller.slug}`} className="w-14 h-14 rounded-2xl overflow-hidden bg-olive-100 shrink-0 flex items-center justify-center text-xl">
              {p.seller.images[0] ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.seller.images[0]} alt="" className="w-full h-full object-cover" />
              ) : (
                "🫒"
              )}
            </Link>
            <div className="flex-1 min-w-0">
              <div className="text-[11px] text-ink-400 font-bold">{t("p_sold_by")}</div>
              <Link href={`/seller/${p.seller.slug}`} className="font-bold text-ink-900 hover:text-olive-700 truncate block">
                {p.seller.shopName}
              </Link>
              <div className="flex items-center gap-2 text-[11px] text-ink-400">
                <Stars value={p.seller.rating} />
                <span>{p.seller.city ?? p.seller.region ?? "Palestine"}</span>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Link href={`/seller/${p.seller.slug}`} className="text-xs font-bold rounded-lg border border-olive-300 text-olive-800 px-3 py-1.5 text-center hover:bg-olive-50">
                {t("p_visit_shop")}
              </Link>
              {p.seller.allowMessages && (
                <button onClick={messageSeller} className="text-xs font-bold rounded-lg bg-olive-700 text-cream-50 px-3 py-1.5 hover:bg-olive-800">
                  {t("p_contact_seller")}
                </button>
              )}
            </div>
          </div>
          <button onClick={() => setReportOpen(true)} className="mt-2 text-[11px] text-ink-400 hover:text-clay-600 underline underline-offset-2">
            {t("msg_report")}
          </button>
        </div>
      </div>

      {/* story */}
      {(p.storyAr || p.storyEn) && (
        <section className="mt-12 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-6 md:p-8">
          <h2 className="font-display text-xl md:text-2xl font-bold text-ink-900 flex items-center gap-2">
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-olive-600"><path d="M12 3C8 7 5 9 5 13a7 7 0 0014 0c0-4-3-6-7-10z" /></svg>
            {t("p_story")}
          </h2>
          <p className="text-ink-700 leading-relaxed mt-3 max-w-3xl">{d({ ar: p.storyAr, en: p.storyEn })}</p>
          {p.storyImages.length > 0 && (
            <div className="flex gap-3 mt-5 overflow-x-auto no-scrollbar">
              {p.storyImages.map((src, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={i} src={src} alt="" loading="lazy" className="w-40 h-28 rounded-2xl object-cover shrink-0" />
              ))}
            </div>
          )}
        </section>
      )}

      {/* description + details */}
      <div className="grid lg:grid-cols-3 gap-8 mt-10">
        <section className="lg:col-span-2">
          <h2 className="font-display text-xl font-bold text-ink-900 mb-3">{t("p_description")}</h2>
          <p className="text-ink-600 leading-relaxed whitespace-pre-line">{d({ ar: p.descriptionAr, en: p.descriptionEn }) || "—"}</p>

          {/* reviews */}
          <div className="mt-12">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-xl font-bold text-ink-900">{t("p_review_title")} ({reviews.length})</h2>
              {me ? (
                <Btn variant="outline" onClick={() => setReviewOpen(true)}>{t("p_write_review")}</Btn>
              ) : (
                <Link href="/auth/login" className="text-sm font-bold text-olive-700 hover:text-olive-900">{t("p_review_login")}</Link>
              )}
            </div>
            {reviews.length === 0 ? (
              <p className="text-sm text-ink-400">{t("p_no_reviews")}</p>
            ) : (
              <div className="space-y-4">
                {reviews.map((r) => (
                  <div key={r.id} className="rounded-2xl border border-cream-200 bg-white p-4">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div className="flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-olive-100 text-olive-800 font-bold text-sm flex items-center justify-center">
                          {r.userName.slice(0, 1)}
                        </span>
                        <div>
                          <div className="text-sm font-bold text-ink-900">{r.userName}</div>
                          <Stars value={r.rating} />
                        </div>
                      </div>
                      <span className="text-[11px] text-ink-400">{timeAgo(r.createdAt, lang)}</span>
                    </div>
                    {(r.commentAr || r.commentEn) && (
                      <p className="text-sm text-ink-600 mt-3 leading-relaxed">{d({ ar: r.commentAr ?? "", en: r.commentEn ?? "" })}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        <aside>
          <h2 className="font-display text-xl font-bold text-ink-900 mb-3">{t("p_details")}</h2>
          <div className="rounded-2xl border border-cream-200 bg-white divide-y divide-cream-100 overflow-hidden">
            {details.map(([k, v], i) => (
              <div key={i} className="px-4 py-3">
                <div className="text-[11px] font-bold text-ink-400">{k}</div>
                <div className="text-sm text-ink-800 mt-0.5">{v}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-2xl bg-olive-50 border border-olive-100 p-4 text-xs text-olive-800 leading-relaxed">
             {t("tagline")}
          </div>
        </aside>
      </div>

      {/* report modal */}
      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title={t("msg_report")}>
        <Field label={t("msg_report_reason")}>
          <TextArea value={reportReason} onChange={(e) => setReportReason(e.target.value)} />
        </Field>
        <Btn onClick={submitReport} className="w-full mt-4">{t("send")}</Btn>
      </Modal>

      {/* review modal */}
      <Modal open={reviewOpen} onClose={() => setReviewOpen(false)} title={t("p_write_review")}>
        <ReviewForm
          productId={p.id}
          onDone={() => setReviewOpen(false)}
          fields={[
            { key: "rating", label: t("p_overall") },
            { key: "qualityRating", label: t("p_quality") },
            { key: "packagingRating", label: t("p_packaging") },
            { key: "shippingRating", label: t("p_speed") },
          ]}
          commentAr={lang === "ar"}
        />
      </Modal>
    </div>
  );
}

export function ReviewForm({ productId, onDone, fields, commentAr }: { productId: number; onDone: () => void; fields: { key: string; label: string }[]; commentAr: boolean }) {
  const { toast, lang } = useStore();
  const [values, setValues] = useState<Record<string, number>>({ rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 5 });
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      const body: Record<string, unknown> = { productId };
      for (const f of fields) body[f.key] = values[f.key];
      if (commentAr) body.commentAr = comment;
      else body.commentEn = comment;
      await api("/api/reviews", { body });
      toast(commentAr ? "شكراً! تم نشر تقييمك" : "Thanks! Your review is live");
      onDone();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {fields.map((f) => (
        <div key={f.key}>
          <div className="text-sm font-semibold text-ink-700 mb-1.5">{f.label}</div>
          <div className="flex gap-1.5">
            {[1, 2, 3, 4, 5].map((i) => (
              <button
                key={i}
                type="button"
                onClick={() => setValues((v) => ({ ...v, [f.key]: i }))}
                className="text-2xl"
                aria-label={`${f.label} ${i}`}
              >
                <span className={i <= (values[f.key] ?? 5) ? "text-gold-400" : "text-cream-300"}>★</span>
              </button>
            ))}
          </div>
        </div>
      ))}
      <Field label={commentAr ? "تعليق (عربي)" : "Comment (English)"}>
        <TextArea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="..." />
      </Field>
      <Btn onClick={submit} disabled={busy} className="w-full">
        {commentAr ? "نشر التقييم" : "Publish review"}
      </Btn>
    </div>
  );
}
