"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useStore } from "./store";
import { Btn, EmptyState, Field, Modal, Select, Spinner, StatusBadge, TextArea, TextInput } from "./ui";
import { api, errMsg } from "@/lib/api";

interface SP {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string | null;
  descriptionEn: string | null;
  priceCents: number;
  stock: number;
  weightGrams: number;
  dimensions: string | null;
  originRegion: string | null;
  images: string[];
  storyAr: string | null;
  storyEn: string | null;
  productionMethodAr: string | null;
  productionMethodEn: string | null;
  ingredientsAr: string | null;
  ingredientsEn: string | null;
  usageAr: string | null;
  usageEn: string | null;
  allergensAr: string | null;
  allergensEn: string | null;
  harvestSeason: string | null;
  shipsInternational: boolean;
  status: string;
  isFeatured: boolean;
  salesCount: number;
  rating: number;
  reviewCount: number;
  categoryId: number;
}

const EMPTY: SP = {
  id: 0, slug: "", nameAr: "", nameEn: "", descriptionAr: "", descriptionEn: "",
  priceCents: 0, stock: 0, weightGrams: 500, dimensions: null, originRegion: null,
  images: [], storyAr: "", storyEn: "", productionMethodAr: "", productionMethodEn: "",
  ingredientsAr: "", ingredientsEn: "", usageAr: "", usageEn: "", allergensAr: "", allergensEn: "",
  harvestSeason: null, shipsInternational: true, status: "pending", isFeatured: false,
  salesCount: 0, rating: 0, reviewCount: 0, categoryId: 0,
};

export function SellerProducts() {
  const { t, d, fmt, lang, toast } = useStore();
  const [items, setItems] = useState<SP[] | null>(null);
  const [cats, setCats] = useState<{ id: number; slug: string; nameAr: string; nameEn: string; icon: string }[]>([]);
  const [editing, setEditing] = useState<SP | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    fetch("/api/seller/products", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => {
        if (x) {
          setItems(x.items);
          setCats(x.categories ?? []);
        }
      })
      .catch(() => setItems([]));
  };
  useEffect(load, []);

  const del = async (p: SP) => {
    try {
      await api(`/api/products/${p.slug}`, { method: "DELETE" });
      toast(t("t_deleted"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const body = {
        categoryId: Number(editing.categoryId),
        nameAr: editing.nameAr,
        nameEn: editing.nameEn,
        descriptionAr: editing.descriptionAr,
        descriptionEn: editing.descriptionEn,
        priceCents: Math.round(parseFloat((editing.priceCents / 100).toString() || "0") * 100),
        stock: Number(editing.stock),
        weightGrams: Number(editing.weightGrams),
        dimensions: editing.dimensions ?? undefined,
        originRegion: editing.originRegion ?? undefined,
        images: editing.images,
        storyAr: editing.storyAr,
        storyEn: editing.storyEn,
        productionMethodAr: editing.productionMethodAr,
        productionMethodEn: editing.productionMethodEn,
        ingredientsAr: editing.ingredientsAr,
        ingredientsEn: editing.ingredientsEn,
        usageAr: editing.usageAr,
        usageEn: editing.usageEn,
        allergensAr: editing.allergensAr,
        allergensEn: editing.allergensEn,
        harvestSeason: editing.harvestSeason ?? undefined,
        shipsInternational: editing.shipsInternational,
      };
      if (editing.id) await api(`/api/products/${editing.slug}`, { method: "PATCH", body });
      else await api("/api/products", { body });
      toast(t("t_saved"));
      setEditing(null);
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-bold text-ink-900">{t("sd_products")}</h2>
        <Btn onClick={() => setEditing({ ...EMPTY, categoryId: cats[0]?.id ?? 0 })}>{t("sd_add_product")}</Btn>
      </div>
      {!items ? (
        <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
      ) : items.length === 0 ? (
        <EmptyState icon={<span className="text-3xl">🫒</span>} title={t("sd_no_products")} />
      ) : (
        <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="text-start border-b border-cream-200 text-xs text-ink-400">
                <th className="text-start p-3 font-bold">—</th>
                <th className="text-start p-3 font-bold">{t("name")}</th>
                <th className="text-start p-3 font-bold">{t("price")}</th>
                <th className="text-start p-3 font-bold">{t("sd_stock")}</th>
                <th className="text-start p-3 font-bold">{t("status")}</th>
                <th className="text-start p-3 font-bold">{t("sales")}</th>
                <th className="p-3" />
              </tr>
            </thead>
            <tbody>
              {items.map((p) => (
                <tr key={p.id} className="border-b border-cream-100 last:border-0">
                  <td className="p-3">
                    <div className="w-12 h-12 rounded-xl bg-cream-100 overflow-hidden">
                      {p.images[0] ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.images[0]} alt="" className="w-full h-full object-cover" />
                      ) : null}
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="font-bold text-ink-900">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                    {p.status === "pending" && <div className="text-[11px] text-gold-500 font-bold mt-0.5">{t("pending")}</div>}
                  </td>
                  <td className="p-3 font-bold">{fmt(p.priceCents)}</td>
                  <td className="p-3">{p.stock}</td>
                  <td className="p-3"><StatusBadge status={p.status} /></td>
                  <td className="p-3">{p.salesCount}</td>
                  <td className="p-3">
                    <div className="flex gap-2 justify-end">
                      <Link href={p.status === "active" ? `/products/${p.slug}` : "#"} className="text-xs font-bold text-olive-700 hover:underline">
                        {p.status === "active" ? "View" : "—"}
                      </Link>
                      <button onClick={() => setEditing(p)} className="text-xs font-bold text-ink-600 hover:underline">{t("edit")}</button>
                      <button onClick={() => del(p)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={editing !== null} onClose={() => setEditing(null)} title={editing?.id ? t("sd_edit_product") : t("sd_add_product")}>
        {editing && (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("sd_name_ar")}>
                <TextInput value={editing.nameAr} onChange={(e) => setEditing({ ...editing, nameAr: e.target.value })} />
              </Field>
              <Field label={t("sd_name_en")}>
                <TextInput dir="ltr" value={editing.nameEn} onChange={(e) => setEditing({ ...editing, nameEn: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("f_category")}>
                <Select value={editing.categoryId} onChange={(e) => setEditing({ ...editing, categoryId: Number(e.target.value) })}>
                  {cats.map((c) => (
                    <option key={c.id} value={c.id}>{d({ ar: c.nameAr, en: c.nameEn })}</option>
                  ))}
                </Select>
              </Field>
              <Field label={t("sd_price")}>
                <TextInput dir="ltr" type="number" min={0} step="0.01" value={editing.priceCents ? (editing.priceCents / 100).toString() : ""}
                  onChange={(e) => setEditing({ ...editing, priceCents: Math.round(parseFloat(e.target.value || "0") * 100) })} />
              </Field>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label={t("sd_stock")}>
                <TextInput dir="ltr" type="number" min={0} value={editing.stock} onChange={(e) => setEditing({ ...editing, stock: Number(e.target.value) })} />
              </Field>
              <Field label={t("sd_weight")}>
                <TextInput dir="ltr" type="number" min={0} value={editing.weightGrams} onChange={(e) => setEditing({ ...editing, weightGrams: Number(e.target.value) })} />
              </Field>
              <Field label={t("sd_season")}>
                <TextInput value={editing.harvestSeason ?? ""} onChange={(e) => setEditing({ ...editing, harvestSeason: e.target.value || null })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("sd_region")}>
                <TextInput value={editing.originRegion ?? ""} onChange={(e) => setEditing({ ...editing, originRegion: e.target.value || null })} placeholder="Jenin" />
              </Field>
              <Field label={`${t("p_dims")} (${t("optional")})`}>
                <TextInput dir="ltr" value={editing.dimensions ?? ""} onChange={(e) => setEditing({ ...editing, dimensions: e.target.value || null })} placeholder="20x10x5" />
              </Field>
            </div>
            <div className="grid grid-cols-1 gap-3">
              <Field label={t("sd_desc_ar")}>
                <TextArea value={editing.descriptionAr ?? ""} onChange={(e) => setEditing({ ...editing, descriptionAr: e.target.value })} />
              </Field>
              <Field label={t("sd_desc_en")}>
                <TextArea dir="ltr" value={editing.descriptionEn ?? ""} onChange={(e) => setEditing({ ...editing, descriptionEn: e.target.value })} />
              </Field>
            </div>
            <Field label={t("sd_images")}>
              <TextArea dir="ltr" value={editing.images.join("\n")}
                onChange={(e) => setEditing({ ...editing, images: e.target.value.split("\n").map((x) => x.trim()).filter(Boolean) })}
                placeholder={"https://…/image-1.jpg\nhttps://…/image-2.jpg"} />
            </Field>
            <Field label={t("sd_story_ar")} hint="اكتب قصة المنتج — المزرعة، العائلة، طريقة الإنتاج">
              <TextArea value={editing.storyAr ?? ""} onChange={(e) => setEditing({ ...editing, storyAr: e.target.value })} />
            </Field>
            <Field label={t("sd_story_en")}>
              <TextArea dir="ltr" value={editing.storyEn ?? ""} onChange={(e) => setEditing({ ...editing, storyEn: e.target.value })} />
            </Field>
            <div className="grid grid-cols-1 gap-3">
              <Field label={`${t("sd_production")} (عربي)`}>
                <TextArea value={editing.productionMethodAr ?? ""} onChange={(e) => setEditing({ ...editing, productionMethodAr: e.target.value })} />
              </Field>
              <Field label={`${t("p_ingredients")} (عربي)`}>
                <TextArea value={editing.ingredientsAr ?? ""} onChange={(e) => setEditing({ ...editing, ingredientsAr: e.target.value })} />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-sm font-bold text-ink-700 cursor-pointer">
              <input type="checkbox" checked={editing.shipsInternational} onChange={(e) => setEditing({ ...editing, shipsInternational: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
              {t("sd_ships")}
            </label>
            <Btn onClick={save} disabled={busy} className="w-full">
              {editing.id ? t("sd_submit_edit") : t("sd_submit_review")}
            </Btn>
          </div>
        )}
      </Modal>
    </div>
  );
}
