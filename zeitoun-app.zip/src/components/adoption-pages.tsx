"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useStore } from "./store";
import { Btn, EmptyState, ProductCard, SectionHead, Select, Spinner, Stars, TextInput } from "./ui";
import {
  AdoptModal,
  FarmerCard,
  FaqSection,
  ImpactStats,
  PhaseTimeline,
  ProgramCard,
  TransparencyNote,
  TreeCard,
  UpdatesList,
} from "./adoption";
import type {
  FarmerFull,
  FarmerMini,
  ProgramView,
  TreeFull,
  TreeView,
  UpdateView,
} from "@/lib/adoption-types";
import { fmtDate, timeAgo } from "@/lib/utils";

interface FarmProduct {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  priceCents: number;
  images: string[];
  stock: number;
  weightGrams: number;
}

/* ============================== /adopt ============================== */

export function AdoptPageClient({
  trees,
  farmers,
  programs,
  regions,
}: {
  trees: TreeView[];
  farmers: FarmerMini[];
  programs: ProgramView[];
  regions: { region: string; count: number }[];
}) {
  const { t, d } = useStore();
  const [region, setRegion] = useState("");
  const [programId, setProgramId] = useState("");
  const [sort, setSort] = useState("newest");
  const [adoptTree, setAdoptTree] = useState<TreeView | null>(null);
  const [supportFarmer, setSupportFarmer] = useState<FarmerMini | null>(null);

  const shown = useMemo(() => {
    let list = trees;
    if (region) list = list.filter((x) => (x.region ?? "").toLowerCase().includes(region.toLowerCase()));
    if (sort === "age") list = [...list].sort((a, b) => b.approximateAge - a.approximateAge);
    return list;
  }, [trees, region, sort]);

  const programsForTree = adoptTree
    ? programs.filter((p) => (p.kind === "tree" || p.kind === "both"))
    : [];
  const farmerPrograms = supportFarmer
    ? programs.filter((p) => p.kind === "farmer" || p.kind === "both")
    : [];

  const steps = [
    { icon: "🌿", title: t("how_t1"), desc: t("ad_page_intro") },
    { icon: "🧑‍🌾", title: t("how_t2"), desc: t("ad_faq_a3") },
    { icon: "📜", title: t("ad_cert_title"), desc: t("ad_faq_a4") },
    { icon: "🫒", title: t("ad_phase_harvest"), desc: t("ad_faq_a6") },
  ];

  return (
    <div className="anim-fade-up">
      {/* hero */}
      <section className="relative overflow-hidden bg-olive-950 text-cream-50">
        <img
          src="https://images.pexels.com/photos/34803738/pexels-photo-34803738.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          alt="Olive grove in Palestine"
          className="absolute inset-0 w-full h-full object-cover opacity-45"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-olive-950 via-olive-950/75 to-olive-950/40" />
        <div className="relative max-w-5xl mx-auto px-4 py-20 md:py-28 text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-cream-50/10 border border-cream-50/25 px-4 py-1.5 text-[12px] font-bold backdrop-blur">
            🌿 {t("ad_home_kicker")}
          </span>
          <h1 className="font-display text-3xl md:text-5xl font-bold mt-5 leading-tight">{t("ad_hero_title")}</h1>
          <p className="mt-3 text-xl md:text-2xl text-olive-200 font-display">{t("ad_hero_sub")}</p>
          <p className="mt-5 text-cream-200 max-w-2xl mx-auto leading-relaxed">{t("ad_page_intro")}</p>
          <div className="mt-8 flex flex-wrap gap-3 justify-center">
            <a href="#trees" className="rounded-xl bg-cream-50 text-olive-900 font-bold px-6 py-3.5 hover:bg-white transition shadow-lg">
              {t("ad_home_btn1")}
            </a>
            <a href="#farmers" className="rounded-xl border-2 border-cream-50/60 text-cream-50 font-bold px-6 py-3.5 hover:bg-cream-50/10 transition">
              {t("ad_home_btn2")}
            </a>
          </div>
          <p className="mt-8 text-cream-300/90 text-sm italic">"{t("ad_slogan2")}"</p>
        </div>
      </section>
      <div className="embroidery-strip" />

      {/* impact */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <SectionHead title={t("ad_impact_title")} sub={t("ad_slogan1")} />
        <ImpactStats />
      </section>

      {/* programs */}
      <section className="max-w-6xl mx-auto px-4 pb-12">
        <SectionHead title={t("ad_programs")} sub={t("ad_transparency_short")} />
        <div className="grid md:grid-cols-3 gap-4">
          {programs.map((p) => (
            <ProgramCard key={p.id} program={p} />
          ))}
        </div>
        <div className="mt-5">
          <TransparencyNote />
        </div>
      </section>

      {/* trees */}
      <section id="trees" className="max-w-7xl mx-auto px-4 pb-14 scroll-mt-24">
        <SectionHead title={t("ad_trees_available")} />
        <div className="flex flex-wrap gap-2.5 mb-6">
          <Select value={region} onChange={(e) => setRegion(e.target.value)} className="!w-auto min-w-[160px]">
            <option value="">{t("ad_filter_region")}: {t("all")}</option>
            {regions.map((r) => (
              <option key={r.region} value={r.region}>
                {r.region} ({r.count})
              </option>
            ))}
          </Select>
          <Select value={sort} onChange={(e) => setSort(e.target.value)} className="!w-auto min-w-[160px]">
            <option value="newest">{t("ad_sort_newest")}</option>
            <option value="age">{t("ad_sort_age")}</option>
          </Select>
          <span className="text-sm text-ink-400 font-semibold self-center">{shown.length} {t("ad_trees_count")}</span>
        </div>
        {shown.length ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {shown.map((tr) => (
              <TreeCard key={tr.id} tree={tr} onAdopt={setAdoptTree} />
            ))}
          </div>
        ) : (
          <EmptyState icon={<span className="text-3xl">🌿</span>} title={t("ad_no_trees")} hint={t("no_results_hint")} />
        )}
      </section>

      {/* farmers */}
      <section id="farmers" className="leaf-bg bg-cream-100/60 py-14 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionHead title={t("ad_farmer_title")} sub={t("ad_farmer_sub")} />
          {farmers.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {farmers.map((f) => (
                <FarmerCard key={f.id} farmer={f} onSupport={setSupportFarmer} />
              ))}
            </div>
          ) : (
            <EmptyState icon={<span className="text-3xl">🧑‍🌾</span>} title={t("ad_no_farmers")} />
          )}
        </div>
      </section>

      {/* how it works */}
      <section className="max-w-6xl mx-auto px-4 py-14">
        <SectionHead title={t("ad_how_title")} />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((s, i) => (
            <div key={i} className="rounded-2xl border border-cream-200 bg-white p-5">
              <div className="text-3xl">{s.icon}</div>
              <div className="text-xs font-bold text-clay-600 mt-3">0{i + 1}</div>
              <h3 className="font-bold text-ink-900 mt-1">{s.title}</h3>
              <p className="text-xs text-ink-600 mt-2 leading-relaxed line-clamp-4">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-3xl mx-auto px-4 pb-16">
        <SectionHead title={t("ad_faq_title")} />
        <FaqSection />
        <p className="text-center text-sm text-ink-400 mt-8 italic">"{t("ad_slogan3")}"</p>
      </section>

      <AdoptModal open={!!adoptTree} onClose={() => setAdoptTree(null)} tree={adoptTree} farmer={adoptTree?.farmer ?? null} programs={programsForTree} />
      <AdoptModal open={!!supportFarmer} onClose={() => setSupportFarmer(null)} tree={null} farmer={supportFarmer} programs={farmerPrograms} />
    </div>
  );
}

/* ============================== /trees/[code] ============================== */

export function TreePageClient({
  tree,
  farmer,
  programs,
  updates,
  products,
  qrDataUrl,
}: {
  tree: TreeFull;
  farmer: FarmerFull;
  programs: ProgramView[];
  updates: UpdateView[];
  products: FarmProduct[];
  qrDataUrl: string;
}) {
  const { t, d, fmt, lang } = useStore();
  const [img, setImg] = useState(0);
  const [adopting, setAdopting] = useState(false);
  const available = tree.status === "available";
  const name = d({ ar: tree.nameAr, en: tree.nameEn }) || tree.treeCode;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <div className="text-xs text-ink-400 mb-5 flex items-center gap-1.5 flex-wrap">
        <Link href="/" className="hover:text-olive-700">{t("nav_home")}</Link>
        <span>/</span>
        <Link href="/adopt" className="hover:text-olive-700">{t("ad_nav")}</Link>
        <span>/</span>
        <span className="text-ink-700" dir="ltr">{tree.treeCode}</span>
      </div>

      <div className="grid lg:grid-cols-[1.15fr_1fr] gap-8 lg:gap-12">
        <div>
          <div className="rounded-3xl overflow-hidden bg-cream-100 border border-cream-200 aspect-[4/3] relative">
            {tree.images[img] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={tree.images[img]} alt={name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-6xl">🌿</div>
            )}
            {tree.verified && (
              <span className="absolute top-3 start-3 rounded-full bg-olive-700 text-cream-50 text-[11px] font-bold px-3 py-1.5 shadow">
                ✓ {t("ad_verified")}
              </span>
            )}
          </div>
          {tree.images.length > 1 && (
            <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
              {tree.images.map((src, i) => (
                <button key={i} onClick={() => setImg(i)} className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 ${i === img ? "border-olive-600" : "border-transparent opacity-70"}`}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {tree.farmImages.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-bold text-ink-700 mb-2.5">{t("ad_farm")}</h3>
              <div className="flex gap-2.5 overflow-x-auto no-scrollbar">
                {tree.farmImages.map((src, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={src} alt="" loading="lazy" className="w-36 h-24 rounded-2xl object-cover shrink-0" />
                ))}
              </div>
            </div>
          )}

          {/* story */}
          {(tree.storyAr || tree.storyEn) && (
            <section className="mt-8 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-5 md:p-7">
              <h2 className="font-display text-xl md:text-2xl font-bold text-ink-900">{t("ad_story_tree")}</h2>
              <p className="text-ink-700 leading-relaxed mt-3 whitespace-pre-line">{d({ ar: tree.storyAr, en: tree.storyEn })}</p>
            </section>
          )}

          {/* timeline */}
          <section className="mt-8 rounded-3xl border border-cream-200 bg-white p-5 md:p-7">
            <PhaseTimeline phase={tree.phase} progress={tree.progressPercent} />
          </section>

          {/* updates */}
          <section className="mt-8">
            <h2 className="font-display text-xl md:text-2xl font-bold text-ink-900 mb-4">{t("ad_updates")}</h2>
            <UpdatesList updates={updates} />
          </section>
        </div>

        {/* right column */}
        <div className="space-y-5">
          <div className="rounded-3xl border border-cream-200 bg-white p-5 md:p-6 lg:sticky lg:top-24">
            <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 leading-tight">{name}</h1>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <span className="rounded-full bg-cream-100 px-3 py-1 text-[11px] font-bold text-ink-700" dir="ltr">{t("ad_tree_code")}: {tree.treeCode}</span>
              <span className={`rounded-full px-3 py-1 text-[11px] font-bold ${available ? "bg-olive-100 text-olive-800" : "bg-cream-200 text-ink-600"}`}>
                {t(`ad_status_${tree.status}`)}
              </span>
            </div>

            <dl className="grid grid-cols-2 gap-3 mt-5">
              {[
                [t("ad_farmer"), d({ ar: farmer.nameAr, en: farmer.nameEn })],
                [t("ad_farm"), d({ ar: farmer.farmNameAr, en: farmer.farmNameEn }) || "—"],
                [t("ad_region"), `${tree.region ?? farmer.city ?? "Palestine"} · ${t("p_country")}`],
                [t("ad_age"), `${tree.approximateAge} ${t("ad_years")}`],
                [t("ad_variety"), tree.oliveVariety ?? "—"],
                [t("ad_season"), tree.season],
                tree.treeNumber ? [t("ad_tree_number"), `#${tree.treeNumber}`] : null,
                [t("ad_sponsors_max"), tree.maxSponsors > 1 ? `${tree.sponsorCount}/${tree.maxSponsors}` : "1"],
              ]
                .filter(Boolean)
                .map((row, i) => (
                  <div key={i} className="rounded-xl bg-cream-100/60 px-3 py-2.5">
                    <dt className="text-[10px] font-bold text-ink-400">{(row as string[])[0]}</dt>
                    <dd className="text-sm font-bold text-ink-900 mt-0.5 truncate">{(row as string[])[1]}</dd>
                  </div>
                ))}
            </dl>

            {programs.length > 0 && (
              <div className="mt-5">
                <div className="text-sm font-bold text-ink-700 mb-2">{t("ad_program")}</div>
                <div className="space-y-2.5 max-h-[300px] overflow-y-auto pe-1">
                  {programs.filter((p) => p.kind !== "farmer").map((p) => (
                    <ProgramCard key={p.id} program={p} />
                  ))}
                </div>
              </div>
            )}

            <div className="mt-5">
              {available ? (
                <Btn onClick={() => setAdopting(true)} className="w-full !py-3.5">{t("ad_adopt_btn")}</Btn>
              ) : (
                <div className="rounded-xl bg-cream-100 p-3.5 text-center text-sm font-bold text-ink-600">{t("ad_tree_adopted")}</div>
              )}
            </div>

            <div className="mt-4">
              <TransparencyNote compact />
            </div>

            <p className="text-[11px] text-ink-400 mt-3 leading-relaxed">{t("ad_privacy_note")}</p>
          </div>

          {/* farmer card */}
          <div className="rounded-3xl border border-cream-200 bg-white p-5">
            <div className="flex items-center gap-3">
              <Link href={`/farmers/${farmer.slug}`} className="w-14 h-14 rounded-2xl overflow-hidden bg-olive-100 shrink-0">
                {farmer.images[0] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={farmer.images[0]} alt="" className="w-full h-full object-cover" />
                ) : null}
              </Link>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-bold text-ink-400">{t("ad_farmer")}</div>
                <Link href={`/farmers/${farmer.slug}`} className="font-bold text-ink-900 hover:text-olive-700 block truncate">
                  {d({ ar: farmer.nameAr, en: farmer.nameEn })}
                </Link>
                <div className="flex items-center gap-2 text-[11px] text-ink-400">
                  <Stars value={farmer.rating} />
                  <span>{farmer.yearsFarming} {t("ad_years_farming")}</span>
                </div>
              </div>
            </div>
            {(farmer.storyAr || farmer.storyEn) && (
              <p className="text-sm text-ink-600 mt-3 leading-relaxed line-clamp-4">{d({ ar: farmer.storyAr, en: farmer.storyEn })}</p>
            )}
            <Link href={`/farmers/${farmer.slug}`} className="inline-block mt-3 text-sm font-bold text-olive-700 hover:underline">
              {t("ad_view_farmer")} →
            </Link>
          </div>

          {/* QR */}
          {qrDataUrl && (
            <div className="rounded-3xl border border-cream-200 bg-white p-5 flex items-center gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={qrDataUrl} alt="QR" className="w-24 h-24 rounded-xl border border-cream-200" />
              <div>
                <div className="font-bold text-sm text-ink-900">{t("ad_qr")}</div>
                <p className="text-xs text-ink-400 mt-1 leading-relaxed">{t("ad_cert_scan")}</p>
                <div className="text-[11px] font-bold text-olive-700 mt-1.5" dir="ltr">zeitoun/trees/{tree.treeCode}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* products from this farm */}
      {products.length > 0 && (
        <section className="mt-14">
          <SectionHead title={t("ad_from_farm")} sub={d({ ar: farmer.farmNameAr, en: farmer.farmNameEn }) || undefined} />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {products.slice(0, 8).map((p) => (
              <Link key={p.id} href={`/products/${p.slug}`} className="group rounded-2xl border border-cream-200 bg-white overflow-hidden hover:shadow-md transition">
                <div className="aspect-[4/3] bg-cream-100 overflow-hidden">
                  {p.images[0] ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.images[0]} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : null}
                </div>
                <div className="p-3">
                  <div className="text-sm font-bold text-ink-900 line-clamp-2">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                  <div className="font-display font-bold text-olive-800 mt-1">{fmt(p.priceCents)}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <AdoptModal
        open={adopting}
        onClose={() => setAdopting(false)}
        tree={tree}
        farmer={farmer}
        programs={programs}
        products={products}
      />
    </div>
  );
}

/* ============================== /farmers ============================== */

export function FarmersPageClient({ farmers, regions }: { farmers: FarmerMini[]; regions: string[] }) {
  const { t } = useStore();
  const [region, setRegion] = useState("");
  const [q, setQ] = useState("");
  const [support, setSupport] = useState<FarmerMini | null>(null);
  const [programs, setPrograms] = useState<ProgramView[] | null>(null);

  const shown = farmers.filter(
    (f) =>
      (!region || (f.region ?? f.city ?? "").toLowerCase().includes(region.toLowerCase())) &&
      (!q || `${f.nameEn} ${f.nameAr} ${f.farmNameEn ?? ""}`.toLowerCase().includes(q.toLowerCase())),
  );

  const openSupport = (f: FarmerMini) => {
    setSupport(f);
    if (!programs)
      fetch("/api/adoption/programs", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((x) => setPrograms(x?.items ?? []))
        .catch(() => setPrograms([]));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 md:py-12 anim-fade-up">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-clay-600 font-bold text-sm">Zeitoun farmers</span>
        <h1 className="font-display text-3xl md:text-5xl font-bold text-ink-900 mt-1">{t("ad_farmer_title")}</h1>
        <p className="text-ink-400 mt-3">{t("ad_farmer_sub")}</p>
      </div>

      <div className="flex flex-wrap gap-2.5 mb-8 justify-center">
        <TextInput placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} className="!w-auto min-w-[220px]" />
        <Select value={region} onChange={(e) => setRegion(e.target.value)} className="!w-auto min-w-[170px]">
          <option value="">{t("ad_filter_region")}: {t("all")}</option>
          {regions.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </Select>
      </div>

      {shown.length ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {shown.map((f) => (
            <FarmerCard key={f.id} farmer={f} onSupport={openSupport} />
          ))}
        </div>
      ) : (
        <EmptyState icon={<span className="text-3xl">🧑‍🌾</span>} title={t("ad_no_farmers")} hint={t("no_results_hint")} />
      )}

      <AdoptModal
        open={!!support}
        onClose={() => setSupport(null)}
        tree={null}
        farmer={support}
        programs={(programs ?? []).filter((p) => p.kind === "farmer" || p.kind === "both")}
      />
    </div>
  );
}

/* ============================== /farmers/[slug] ============================== */

export function FarmerPageClient({
  farmer,
  trees,
  programs,
  products,
  updates,
}: {
  farmer: FarmerFull;
  trees: TreeView[];
  programs: ProgramView[];
  products: FarmProduct[];
  updates: UpdateView[];
}) {
  const { t, d, fmt } = useStore();
  const [adoptTree, setAdoptTree] = useState<TreeView | null>(null);
  const [supporting, setSupporting] = useState(false);
  const availableTrees = trees.filter((x) => x.status === "available");

  return (
    <div className="anim-fade-up">
      <div className="h-48 md:h-72 bg-olive-900 relative overflow-hidden">
        {farmer.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={farmer.images[0]} alt="" className="w-full h-full object-cover opacity-60" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-olive-950/85 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="-mt-12 md:-mt-16 relative">
          <div className="rounded-3xl border border-cream-200 bg-white p-5 md:p-7 flex flex-col md:flex-row gap-5">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-3xl bg-olive-100 border-4 border-white shadow overflow-hidden shrink-0">
              {farmer.images[1] ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={farmer.images[1]} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-3xl">🧑‍🌾</div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">{d({ ar: farmer.nameAr, en: farmer.nameEn })}</h1>
              {d({ ar: farmer.farmNameAr, en: farmer.farmNameEn }) && (
                <div className="text-sm text-olive-700 font-bold mt-0.5">{d({ ar: farmer.farmNameAr, en: farmer.farmNameEn })}</div>
              )}
              <div className="flex items-center gap-3 mt-2 flex-wrap text-sm text-ink-400 font-semibold">
                <span className="flex items-center gap-1"><Stars value={farmer.rating} /> {farmer.rating > 0 ? farmer.rating.toFixed(1) : "—"}</span>
                <span>📍 {farmer.city ?? farmer.region ?? "Palestine"}</span>
                <span>🌳 {farmer.treeCount} {t("ad_trees_count")}</span>
                <span>🗓️ {farmer.yearsFarming} {t("ad_years_farming")}</span>
              </div>
              {d({ ar: farmer.aboutAr, en: farmer.aboutEn }) && (
                <p className="text-sm text-ink-600 mt-3 leading-relaxed max-w-2xl">{d({ ar: farmer.aboutAr, en: farmer.aboutEn })}</p>
              )}
              <div className="flex gap-2.5 mt-4 flex-wrap">
                <Btn onClick={() => setSupporting(true)}>{t("ad_support_btn")}</Btn>
                {availableTrees.length > 0 && (
                  <Btn variant="outline" onClick={() => setAdoptTree(availableTrees[0])}>
                    {t("ad_adopt_btn")} ({availableTrees.length})
                  </Btn>
                )}
              </div>
            </div>
          </div>
        </div>

        {(farmer.storyAr || farmer.storyEn) && (
          <section className="mt-8 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-6">
            <h2 className="font-display text-lg md:text-xl font-bold text-ink-900">{t("ad_story_farmer")}</h2>
            <p className="text-ink-700 mt-2 leading-relaxed max-w-3xl whitespace-pre-line">{d({ ar: farmer.storyAr, en: farmer.storyEn })}</p>
            {farmer.images.length > 1 && (
              <div className="flex gap-3 mt-5 overflow-x-auto no-scrollbar">
                {farmer.images.slice(1).map((src, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={src} alt="" loading="lazy" className="w-40 h-28 rounded-2xl object-cover shrink-0" />
                ))}
              </div>
            )}
            {farmer.videoUrl && <video src={farmer.videoUrl} controls className="mt-5 rounded-2xl w-full max-h-80" />}
          </section>
        )}

        {programs.length > 0 && (
          <section className="mt-10">
            <SectionHead title={t("ad_programs")} sub={t("ad_transparency_short")} />
            <div className="grid md:grid-cols-3 gap-4">
              {programs.map((p) => (
                <ProgramCard key={p.id} program={p} />
              ))}
            </div>
          </section>
        )}

        <section className="mt-10">
          <SectionHead title={t("ad_trees_of_farmer")} />
          {trees.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {trees.map((tr) => (
                <TreeCard key={tr.id} tree={tr} onAdopt={setAdoptTree} />
              ))}
            </div>
          ) : (
            <EmptyState icon={<span className="text-3xl">🌿</span>} title={t("ad_no_trees")} />
          )}
        </section>

        {products.length > 0 && (
          <section className="mt-10">
            <SectionHead title={t("products")} sub={t("ad_from_farm")} />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              {products.map((p) => (
                <Link key={p.id} href={`/products/${p.slug}`} className="group rounded-2xl border border-cream-200 bg-white overflow-hidden hover:shadow-md transition">
                  <div className="aspect-[4/3] bg-cream-100 overflow-hidden">
                    {p.images[0] ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.images[0]} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : null}
                  </div>
                  <div className="p-3">
                    <div className="text-sm font-bold text-ink-900 line-clamp-2">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                    <div className="font-display font-bold text-olive-800 mt-1">{fmt(p.priceCents)}</div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        <section className="mt-10 pb-14">
          <SectionHead title={t("ad_updates")} />
          <UpdatesList updates={updates} />
        </section>
      </div>

      <AdoptModal open={!!adoptTree} onClose={() => setAdoptTree(null)} tree={adoptTree} farmer={adoptTree?.farmer ?? farmer} programs={programs} products={products} />
      <AdoptModal open={supporting} onClose={() => setSupporting(false)} tree={null} farmer={farmer} programs={programs.filter((p) => p.kind !== "tree")} products={products} />
    </div>
  );
}

/* ============================== /certificate/[code] ============================== */

export interface CertificateData {
  code: string;
  qrDataUrl: string | null;
  sponsorName: string;
  treeName: string | null;
  treeCode: string | null;
  farmerName: string;
  farmName: string | null;
  region: string | null;
  season: string;
  startDate: string;
  issuedAt: string;
  treeUrl: string | null;
  isGift: boolean;
  giftFrom: string | null;
  giftMessage: string | null;
  giftOccasion: string | null;
}

export function CertificateClient({ cert }: { cert: CertificateData }) {
  const { t, lang } = useStore();
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-14 anim-fade-up">
      <div className="rounded-3xl border-2 border-olive-700/30 bg-cream-50 overflow-hidden shadow-xl">
        <div className="embroidery-strip" />
        <div className="p-6 md:p-10 text-center relative leaf-bg">
          <div className="flex justify-center mb-4">
            <svg width="46" height="46" viewBox="0 0 40 40" fill="none" aria-hidden>
              <path d="M8 34 C14 26 22 15 32 7" stroke="#465628" strokeWidth="2.4" strokeLinecap="round" />
              <path d="M20 18 C14 16 10 17 6.5 20 C10 24 16 24 20 18z" fill="#718a41" />
              <path d="M27 11 C23 5.5 18 4 13 5.5 C14 11 20 14 27 11z" fill="#576d2f" />
              <circle cx="12" cy="30" r="3.4" fill="#333d21" />
              <circle cx="18" cy="25.5" r="2.6" fill="#465628" />
            </svg>
          </div>
          <div className="font-display font-bold text-lg text-olive-800">Zeitoun <span className="text-ink-400">| زيتون</span></div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mt-4 leading-tight">
            {cert.treeCode ? t("ad_cert_title") : t("ad_cert_farmer_title")}
          </h1>

          {cert.isGift && cert.giftFrom && (
            <p className="text-sm text-clay-600 font-bold mt-3">
              🎁 {t("ad_cert_gift_line")} {cert.giftFrom}
            </p>
          )}

          <p className="text-sm text-ink-500 mt-5">{t("ad_cert_sponsor")}</p>
          <p className="font-display text-2xl md:text-3xl font-bold text-olive-800 mt-1">{cert.sponsorName}</p>

          {cert.treeCode && (
            <>
              <p className="text-sm text-ink-500 mt-5">{t("ad_cert_tree")}</p>
              <p className="font-display text-xl md:text-2xl font-bold text-ink-900 mt-1">{cert.treeName || cert.treeCode}</p>
              <p className="text-xs font-bold text-ink-400 mt-1" dir="ltr">{t("ad_tree_code")}: {cert.treeCode}</p>
            </>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-7">
            {[
              [t("ad_cert_farmer"), cert.farmerName],
              [t("ad_farm"), cert.farmName ?? "—"],
              [t("ad_region"), `${cert.region ?? "Palestine"} · ${t("p_country")}`],
              [t("ad_season"), cert.season],
            ].map(([k, v], i) => (
              <div key={i} className="rounded-xl bg-white/80 border border-cream-200 px-3 py-2.5">
                <div className="text-[10px] font-bold text-ink-400">{k}</div>
                <div className="text-sm font-bold text-ink-900 mt-0.5 truncate">{v}</div>
              </div>
            ))}
          </div>

          {cert.giftMessage && (
            <p className="mt-6 text-sm text-ink-600 italic leading-relaxed max-w-md mx-auto">"{cert.giftMessage}"</p>
          )}

          <div className="flex flex-col md:flex-row items-center justify-center gap-6 mt-8">
            {cert.qrDataUrl && (
              <div className="text-center">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={cert.qrDataUrl} alt="QR" className="w-28 h-28 rounded-xl border border-cream-300 bg-white p-1.5" />
                <div className="text-[10px] font-bold text-ink-400 mt-1.5 max-w-[120px]">{t("ad_cert_scan")}</div>
              </div>
            )}
            <div className="text-center md:text-start">
              <div className="text-[10px] font-bold text-ink-400">{t("ad_cert_number")}</div>
              <div className="font-display font-bold text-ink-900" dir="ltr">{cert.code}</div>
              <div className="text-[10px] font-bold text-ink-400 mt-3">{t("ad_start_date")}</div>
              <div className="text-sm font-bold text-ink-900">{fmtDate(cert.startDate, lang)}</div>
              <div className="text-[10px] font-bold text-ink-400 mt-3">{t("ad_cert_issued")}</div>
              <div className="text-sm font-bold text-ink-900">{fmtDate(cert.issuedAt, lang)}</div>
            </div>
          </div>

          <p className="text-[11px] text-ink-400 mt-8 leading-relaxed max-w-lg mx-auto">{t("ad_cert_disclaimer")}</p>
        </div>
        <div className="embroidery-strip" />
      </div>

      <div className="flex gap-3 mt-6 justify-center flex-wrap">
        <Btn onClick={() => window.print()}>{t("ad_cert_print")}</Btn>
        {cert.treeUrl && (
          <Link href={cert.treeUrl} className="rounded-xl border border-olive-300 text-olive-800 font-bold px-5 py-2.5 text-sm hover:bg-olive-50 transition">
            {t("ad_public_page")} →
          </Link>
        )}
        <Link href="/my-trees" className="rounded-xl bg-olive-700 text-cream-50 font-bold px-5 py-2.5 text-sm hover:bg-olive-800 transition">
          {t("ad_my_trees")}
        </Link>
      </div>
    </div>
  );
}

/* ============================== Home page adoption sections ============================== */

export function AdoptHomeSections({
  initialTrees,
  initialFarmers,
  initialPrograms,
}: {
  initialTrees?: TreeView[];
  initialFarmers?: FarmerMini[];
  initialPrograms?: ProgramView[];
} = {}) {
  const { t } = useStore();
  const [trees, setTrees] = useState<TreeView[] | null>(initialTrees ?? null);
  const [farmers, setFarmers] = useState<FarmerMini[] | null>(initialFarmers ?? null);
  const [programs, setPrograms] = useState<ProgramView[]>(initialPrograms ?? []);
  const [adoptTree, setAdoptTree] = useState<TreeView | null>(null);
  const [supportFarmer, setSupportFarmer] = useState<FarmerMini | null>(null);

  useEffect(() => {
    if (initialTrees && initialFarmers && initialPrograms?.length) return; // server-provided
    fetch("/api/trees", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setTrees((x?.items ?? []).slice(0, 4)))
      .catch(() => setTrees([]));
    fetch("/api/farmers", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setFarmers((x?.items ?? []).slice(0, 4)))
      .catch(() => setFarmers([]));
    fetch("/api/adoption/programs", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setPrograms(x?.items ?? []))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!trees?.length && !farmers?.length) return null;

  return (
    <>
      {/* Adopt a tree */}
      <section className="bg-olive-950 text-cream-50 py-14 md:py-20 relative overflow-hidden">
        <img
          src="https://images.pexels.com/photos/36005582/pexels-photo-36005582.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative max-w-7xl mx-auto px-4">
          <div className="max-w-2xl">
            <h2 className="font-display text-3xl md:text-4xl font-bold">{t("ad_home_kicker")}</h2>
            <p className="text-cream-200 mt-3 text-base md:text-lg leading-relaxed">{t("ad_home_sub")}</p>
            <p className="text-olive-300 mt-3 text-sm italic">"{t("ad_slogan2")}"</p>
            <div className="flex flex-wrap gap-3 mt-6">
              <Link href="/adopt" className="rounded-xl bg-cream-50 text-olive-900 font-bold px-6 py-3 hover:bg-white transition shadow-lg">
                {t("ad_home_btn1")}
              </Link>
              <Link href="/farmers" className="rounded-xl border-2 border-cream-50/60 text-cream-50 font-bold px-6 py-3 hover:bg-cream-50/10 transition">
                {t("ad_home_btn2")}
              </Link>
            </div>
          </div>

          {trees && trees.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
              {trees.map((tr) => (
                <div key={tr.id} className="rounded-2xl overflow-hidden bg-white/5 border border-white/10 backdrop-blur">
                  <Link href={`/trees/${tr.treeCode}`} className="block aspect-[4/3] bg-white/10 overflow-hidden">
                    {tr.images[0] ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={tr.images[0]} alt="" loading="lazy" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    ) : null}
                  </Link>
                  <div className="p-3.5">
                    <div className="font-bold text-sm truncate">{tr.nameEn || tr.treeCode}</div>
                    <div className="text-[11px] text-cream-300 mt-0.5" dir="ltr">{tr.treeCode} · {tr.region}</div>
                    <div className="text-[11px] text-olive-300 font-bold mt-1.5">{t(`ad_phase_${tr.phase}`)}</div>
                    <button
                      onClick={() => setAdoptTree(tr)}
                      className="mt-3 w-full rounded-xl bg-cream-50 text-olive-900 text-xs font-bold py-2 hover:bg-white transition"
                    >
                      {t("ad_adopt_btn")}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Support a farmer */}
      <section className="max-w-7xl mx-auto px-4 py-14 md:py-20">
        <SectionHead
          title={t("ad_home_farmer_title")}
          sub={t("ad_home_farmer_body")}
          action={
            <Link href="/farmers" className="text-sm font-bold text-olive-700 hover:text-olive-900 shrink-0">
              {t("view_all")} ←
            </Link>
          }
        />
        {farmers && farmers.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {farmers.map((f) => (
              <FarmerCard key={f.id} farmer={f} onSupport={setSupportFarmer} />
            ))}
          </div>
        )}
        <div className="mt-8 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-6 md:p-8 text-center">
          <p className="font-display text-xl md:text-2xl font-bold text-ink-900">"{t("ad_slogan1")}"</p>
          <Link href="/adopt" className="inline-block mt-5 rounded-xl bg-olive-700 text-cream-50 font-bold px-7 py-3.5 hover:bg-olive-800 transition">
            {t("ad_nav")}
          </Link>
        </div>
      </section>

      <AdoptModal
        open={!!adoptTree}
        onClose={() => setAdoptTree(null)}
        tree={adoptTree}
        farmer={adoptTree?.farmer ?? null}
        programs={programs.filter((p) => p.kind !== "farmer")}
      />
      <AdoptModal
        open={!!supportFarmer}
        onClose={() => setSupportFarmer(null)}
        tree={null}
        farmer={supportFarmer}
        programs={programs.filter((p) => p.kind !== "tree")}
      />
    </>
  );
}
