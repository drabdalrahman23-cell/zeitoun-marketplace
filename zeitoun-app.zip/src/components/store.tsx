"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { translate, T } from "@/lib/i18n";
import { d as dUtil, fmtMoney } from "@/lib/utils";
import type { Lang, Localized, ProductView } from "@/lib/types";

/* ---------------- Types ---------------- */

export interface CartItem {
  productId: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  priceCents: number;
  image: string;
  sellerId: number;
  sellerSlug: string;
  shopName: string;
  weightGrams: number;
  stock: number;
  currency: string;
  qty: number;
}

interface Me {
  id: number;
  name: string;
  email: string;
  role: "customer" | "seller" | "admin";
  createdAt?: string | null;
}

interface Currency {
  code: string;
  nameAr: string;
  nameEn: string;
  symbol: string;
  ratePerUsd: number;
}

interface Toast {
  id: number;
  msg: string;
  kind: "ok" | "err";
}

interface Store {
  lang: Lang;
  setLang: (l: Lang) => void;
  dir: "rtl" | "ltr";
  t: (key: string) => string;
  d: (v: Localized | string | null | undefined) => string;
  currency: string;
  setCurrency: (c: string) => void;
  currencies: Currency[];
  fmt: (cents: number) => string;
  rate: (code?: string) => number;
  cart: CartItem[];
  addToCart: (p: ProductView, qty?: number) => void;
  setQty: (productId: number, qty: number) => void;
  removeFromCart: (productId: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  cartWeight: number;
  toasts: Toast[];
  toast: (msg: string, kind?: "ok" | "err") => void;
  me: Me | null;
  refreshMe: () => Promise<void>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<Store | null>(null);

export function useStore(): Store {
  const s = useContext(Ctx);
  if (!s) throw new Error("useStore outside provider");
  return s;
}

/* ---------------- Provider ---------------- */

let toastId = 1;

export function StoreProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [lang, setLangState] = useState<Lang>("ar");
  const [ready, setReady] = useState(false);
  const [currency, setCurrencyState] = useState("USD");
  const [currencies, setCurrencies] = useState<Currency[]>([
    { code: "USD", nameAr: "دولار أمريكي", nameEn: "US Dollar", symbol: "$", ratePerUsd: 1 },
  ]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [me, setMe] = useState<Me | null>(null);

  /* init from localStorage (once) */
  useEffect(() => {
    try {
      const l = localStorage.getItem("zt_lang");
      if (l === "ar" || l === "en") setLangState(l);
      const c = localStorage.getItem("zt_currency");
      if (c) setCurrencyState(c);
      const raw = localStorage.getItem("zt_cart_v1");
      if (raw) setCart(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  const dir: "rtl" | "ltr" = lang === "ar" ? "rtl" : "ltr";
  useEffect(() => {
    if (!ready) return;
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir, ready]);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try {
      localStorage.setItem("zt_lang", l);
    } catch {}
  }, []);

  /* meta: currencies (admin-managed, extensible) */
  useEffect(() => {
    fetch("/api/meta")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.currencies?.length) setCurrencies(data.currencies);
      })
      .catch(() => {});
  }, []);

  const setCurrency = useCallback((c: string) => {
    setCurrencyState(c);
    try {
      localStorage.setItem("zt_currency", c);
    } catch {}
  }, []);

  const rate = useCallback(
    (code?: string) => currencies.find((c) => c.code === (code ?? currency))?.ratePerUsd ?? 1,
    [currencies, currency],
  );

  const fmt = useCallback(
    (cents: number) => {
      const cur = currencies.find((c) => c.code === currency);
      return fmtMoney(cents, cur?.ratePerUsd ?? 1, cur?.symbol ?? "$");
    },
    [currencies, currency],
  );

  const t = useCallback((key: string) => translate(key, lang), [lang]);
  const d = useCallback((v: Localized | string | null | undefined) => dUtil(v, lang), [lang]);

  /* cart persistence */
  useEffect(() => {
    try {
      localStorage.setItem("zt_cart_v1", JSON.stringify(cart));
    } catch {}
  }, [cart]);

  const toast = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    const id = toastId++;
    setToasts((ts) => [...ts, { id, msg, kind }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 2800);
  }, []);

  const addToCart = useCallback(
    (p: ProductView, qty = 1) => {
      setCart((c) => {
        const ex = c.find((i) => i.productId === p.id);
        if (ex) return c.map((i) => (i.productId === p.id ? { ...i, qty: Math.min(i.qty + qty, p.stock) } : i));
        return [
          ...c,
          {
            productId: p.id,
            slug: p.slug,
            nameAr: p.nameAr,
            nameEn: p.nameEn,
            priceCents: p.priceCents,
            image: p.images[0] ?? "",
            sellerId: p.seller.id,
            sellerSlug: p.seller.slug,
            shopName: p.seller.shopName,
            weightGrams: p.weightGrams,
            stock: p.stock,
            currency: p.currency,
            qty,
          },
        ];
      });
    },
    [],
  );

  const setQty = useCallback((productId: number, qty: number) => {
    setCart((c) => (qty <= 0 ? c.filter((i) => i.productId !== productId) : c.map((i) => (i.productId === productId ? { ...i, qty } : i))));
  }, []);

  const removeFromCart = useCallback((productId: number) => {
    setCart((c) => c.filter((i) => i.productId !== productId));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const refreshMe = useCallback(async () => {
    try {
      const r = await fetch("/api/auth/me", { cache: "no-store" });
      if (r.ok) {
        const data = await r.json();
        setMe({ id: data.id, name: data.name, email: data.email, role: data.role, createdAt: data.createdAt ?? null });
      } else setMe(null);
    } catch {
      setMe(null);
    }
  }, []);

  const signOut = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    setMe(null);
    router.push("/");
  }, [router]);

  const cartCount = cart.reduce((n, i) => n + i.qty, 0);
  const cartSubtotal = cart.reduce((n, i) => n + i.priceCents * i.qty, 0);
  const cartWeight = cart.reduce((n, i) => n + i.weightGrams * i.qty, 0);

  const value = useMemo<Store>(
    () => ({
      lang,
      setLang,
      dir,
      t,
      d,
      currency,
      setCurrency,
      currencies,
      fmt,
      rate,
      cart,
      addToCart,
      setQty,
      removeFromCart,
      clearCart,
      cartCount,
      cartSubtotal,
      cartWeight,
      toasts,
      toast,
      me,
      refreshMe,
      signOut,
    }),
    [lang, setLang, dir, t, d, currency, setCurrency, currencies, fmt, rate, cart, addToCart, setQty, removeFromCart, clearCart, cartCount, cartSubtotal, cartWeight, toasts, toast, me, refreshMe, signOut],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <Toaster toasts={toasts} />
    </Ctx.Provider>
  );
}

function Toaster({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="fixed bottom-20 md:bottom-6 start-1/2 translate-x-[-50%] rtl:translate-x-[50%] z-[100] flex flex-col gap-2 items-center pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`anim-pop px-4 py-2.5 rounded-full shadow-lg text-sm font-semibold ${
            t.kind === "err" ? "bg-clay-600 text-white" : "bg-ink-900 text-cream-50"
          }`}
        >
          {t.msg}
        </div>
      ))}
    </div>
  );
}

export { T };
