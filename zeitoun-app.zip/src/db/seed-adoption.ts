/* Adoption seed — run AFTER src/db/seed.ts:  npx tsx src/db/seed-adoption.ts */
import { config } from "dotenv";
config();

import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { eq, sql } from "drizzle-orm";
import QRCode from "qrcode";
import * as s from "./schema";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;
const daysAgo = (n: number) => new Date(Date.now() - n * 86400000);
const daysAhead = (n: number) => new Date(Date.now() + n * 86400000);
const SEASON = String(new Date().getFullYear());

async function main() {
  console.log("🌱 Seeding adoption data...");
  await db.execute(
    sql`TRUNCATE adoption_certificates, adoption_gifts, adoption_orders, adoption_updates, adoptions, tree_seasons, olive_trees, tree_images, farmer_support_programs, adoption_programs, farmers, gift_occasions RESTART IDENTITY CASCADE`,
  );

  const existingSellers = await db.select({ id: s.sellers.id, userId: s.sellers.userId }).from(s.sellers);
  const sellerOf = (userId: number) => existingSellers.find((x) => x.userId === userId)?.id ?? null;

  /* ---------- farmers (public profiles linked to seller accounts) ---------- */
  const farmers = await db
    .insert(s.farmers)
    .values([
      {
        id: 1, sellerId: sellerOf(3), slug: "abu-ahmad", nameAr: "أبو أحمد", nameEn: "Abu Ahmad",
        farmNameAr: "مزرعة الزيتون القديم", farmNameEn: "Old Olive Farm",
        region: "North West Bank", city: "Jenin", yearsFarming: 34,
        aboutAr: "مزارع زيتون من جنين، يعتني بأشجار عائلته منذ 34 عامًا.",
        aboutEn: "An olive farmer from Jenin caring for his family's trees for 34 years.",
        storyAr: "ورث أبو أحمد 400 شجرة زيتون عن جده عام 1996. كل نوفمبر تصعد العائلة كلها — بما فيهم الأطفال — إلى التلال للقطاف. يُعصر الزيت خلال 24 ساعة في معصرة القرية التعاونية التي ما زالت تعمل بنفس حجر الرحى منذ السبعينيات.",
        storyEn: "Abu Ahmad inherited 400 olive trees from his grandfather in 1996. Every November the whole family — children included — climbs the hills to harvest. The oil is pressed within 24 hours at the village cooperative press, still running on the same stone mill since the 1970s.",
        images: [px(34803738), px(36005582), px(31105190)], rating: "4.8", treeCount: 6, sponsorCount: 2,
      },
      {
        id: 2, sellerId: sellerOf(4), slug: "nadia-khoury", nameAr: "ناديا خوري", nameEn: "Nadia Khoury",
        farmNameAr: "حقول طوباس", farmNameEn: "Tubas Fields",
        region: "Tubas Governorate", city: "Tubas", yearsFarming: 18,
        aboutAr: "مزارعة ونحّالة من طوباس، تدير 60 خلية نحل وحقول الزعتر البري.",
        aboutEn: "A farmer and beekeeper from Tubas running 60 hives and wild za'atar fields.",
        storyAr: "نشأت ناديا بين خلايا النحل التي كان والدها يربيها على مصاطب الجبل فوق طوباس. اليوم تدير 60 خلية بنفسها، وما زالت تقطف الزعتر البري يدويًا كل ربيع كما علّمتها أمها.",
        storyEn: "Nadia grew up among the beehives her father kept on the mountain terraces above Tubas. Today she runs 60 hives herself and still harvests wild za'atar by hand every spring, the way her mother taught her.",
        images: [px(37675551), px(18767549)], rating: "4.9", treeCount: 3, sponsorCount: 1,
      },
      {
        id: 3, sellerId: sellerOf(5), slug: "omar-nassar", nameAr: "عمر نصار", nameEn: "Omar Nassar",
        farmNameAr: "بيت نور للحرف", farmNameEn: "Nour's Craft House",
        region: "Nablus", city: "Nablus", yearsFarming: 12,
        aboutAr: "حرفي من نابلس، يحوّل خشب أشجار الزيتون المهذّبة إلى قطع مطبخ.",
        aboutEn: "A Nablus craftsman turning pruned olive wood into kitchen pieces.",
        storyAr: "يعمل عمر في ورشة نابلس القديمة منذ 2013. لا يقطع شجرة واحدة — يستخدم فقط الأغصان المهذّبة من بساتين الزيتون المحيطة بالمدينة.",
        storyEn: "Omar has worked in the old Nablus workshop since 2013. He never cuts a tree — he uses only pruned branches from the olive groves around the city.",
        images: [px(28271468), px(33703946)], rating: "4.7", treeCount: 2, sponsorCount: 0,
      },
      {
        id: 4, sellerId: sellerOf(6), slug: "sara-yousef", nameAr: "سارة يوسف", nameEn: "Sara Yousef",
        farmNameAr: "ورشة رام الله", farmNameEn: "Ramallah Makers",
        region: "Ramallah", city: "Ramallah", yearsFarming: 9,
        aboutAr: "حرفية تطريز تدير ورشة مع 12 امرأة حول رام الله، وتملك بستان زيتون عائلي.",
        aboutEn: "An embroidery artisan running a workshop with 12 women around Ramallah, with a family olive grove.",
        storyAr: "تعلّمت سارة التطريز من جدتها. بستان عائلتها صغير — 45 شجرة — لكنه يموّل جزءًا من عمل الورشة.",
        storyEn: "Sara learned embroidery from her grandmother. Her family grove is small — 45 trees — but it funds part of the workshop's work.",
        images: [px(10566051), px(10548607)], rating: "4.8", treeCount: 3, sponsorCount: 0,
      },
    ])
    .returning();

  /* ---------- adoption programs ---------- */
  const programs = await db
    .insert(s.adoptionPrograms)
    .values([
      {
        id: 1, nameAr: "تبنٍّ موسمي", nameEn: "Seasonal Sponsorship", slug: "seasonal-sponsorship",
        descriptionAr: "ادعم شجرة زيتون لمدة موسم كامل، وتابع مراحلها حتى الحصاد.",
        descriptionEn: "Support an olive tree for a full season and follow its stages through to harvest.",
        kind: "tree", priceCents: 12000, renewalPriceCents: 10000, durationDays: 365,
        benefits: [
          { ar: "رعاية شجرة لمدة موسم كامل", en: "Tree sponsorship for one full season" },
          { ar: "شهادة رعاية رقمية برمز QR", en: "Digital sponsorship certificate with QR code" },
          { ar: "تحديثات وصور دورية من المزرعة", en: "Regular updates and photos from the farm" },
          { ar: "معلومات عن المزرعة والمزارع", en: "Farm and farmer information" },
          { ar: "500مل زيت زيتون من إنتاج المزرعة عند الحصاد", en: "500ml olive oil from the farm at harvest" },
        ],
        includedProducts: [{ labelAr: "زيت زيتون 500مل", labelEn: "Olive oil 500ml", qty: 1 }],
        shippingIncluded: false, maxSponsorsPerTree: 1, giftEnabled: true, sortOrder: 1,
      },
      {
        id: 2, nameAr: "تبنٍّ مميز", nameEn: "Premium Tree Adoption", slug: "premium-tree-adoption",
        descriptionAr: "شجرة محددة باسمك، مع منتجات المزرعة وفيديوهات الموسم.",
        descriptionEn: "A specific tree in your name, with farm products and season videos.",
        kind: "tree", priceCents: 24000, renewalPriceCents: 21000, durationDays: 365,
        benefits: [
          { ar: "شجرة محددة برقم وهوية خاصة", en: "A specific tree with its own ID" },
          { ar: "شهادة تبنٍّ رقمية برمز QR", en: "Digital adoption certificate with QR code" },
          { ar: "تحديثات دورية + صور وفيديوهات", en: "Regular updates plus photos and videos" },
          { ar: "قصة المزارع كاملة", en: "The farmer's full story" },
          { ar: "1 لتر زيت زيتون من موسم الحصاد", en: "1L olive oil from the harvest season" },
          { ar: "250غ زعتر بري من المزرعة", en: "250g wild za'atar from the farm" },
          { ar: "الشحن الدولي مشمول", en: "International shipping included" },
        ],
        includedProducts: [
          { labelAr: "زيت زيتون 1 لتر", labelEn: "Olive oil 1L", qty: 1 },
          { labelAr: "زعتر بري 250غ", labelEn: "Wild za'atar 250g", qty: 1 },
        ],
        shippingIncluded: true, maxSponsorsPerTree: 1, giftEnabled: true, sortOrder: 2,
      },
      {
        id: 3, nameAr: "رعاية جماعية للشجرة", nameEn: "Shared Tree Care", slug: "shared-tree-care",
        descriptionAr: "حتى 3 رعاة يشاركون في رعاية شجرة واحدة — مناسب للهدايا الجماعية.",
        descriptionEn: "Up to 3 sponsors share the care of one tree — great for group gifts.",
        kind: "tree", priceCents: 6500, renewalPriceCents: 5500, durationDays: 365,
        benefits: [
          { ar: "حصة في رعاية شجرة (حتى 3 رعاة)", en: "A share in one tree's care (up to 3 sponsors)" },
          { ar: "شهادة رقمية", en: "Digital certificate" },
          { ar: "تحديثات موسمية", en: "Seasonal updates" },
        ],
        includedProducts: [], shippingIncluded: false, maxSponsorsPerTree: 3, giftEnabled: true, sortOrder: 3,
      },
      {
        id: 4, nameAr: "ادعم مزارعًا", nameEn: "Support a Farmer", slug: "support-a-farmer",
        descriptionAr: "بدون شجرة محددة — دعمك يذهب مباشرة للمزارع وموسمه.",
        descriptionEn: "No specific tree — your support goes directly to the farmer and his season.",
        kind: "farmer", priceCents: 7500, renewalPriceCents: 6500, durationDays: 365,
        benefits: [
          { ar: "دعم مالي محدد لمزارع فلسطيني", en: "Direct financial support to a Palestinian farmer" },
          { ar: "ملف المزارع وقصته وصور مزرعته", en: "The farmer's profile, story and farm photos" },
          { ar: "تحديثات موسمية", en: "Seasonal updates" },
          { ar: "شهادة دعم رقمية", en: "Digital support certificate" },
          { ar: "منتجات من إنتاجه حسب الموسم", en: "Products from his farm, according to the season" },
        ],
        includedProducts: [{ labelAr: "منتج موسمي من المزرعة", labelEn: "Seasonal farm product", qty: 1 }],
        shippingIncluded: false, maxSponsorsPerTree: 25, giftEnabled: true, sortOrder: 4,
      },
    ])
    .returning();

  /* ---------- farmer participation in programs ---------- */
  await db.insert(s.farmerSupportPrograms).values([
    { farmerId: 1, programId: 1, allowed: true, allowPriceOverride: false, slots: 40 },
    { farmerId: 1, programId: 2, allowed: true, allowPriceOverride: true, customPriceCents: 26000, slots: 20 },
    { farmerId: 1, programId: 3, allowed: true, allowPriceOverride: false, slots: 30 },
    { farmerId: 1, programId: 4, allowed: true, allowPriceOverride: false, slots: 50 },
    { farmerId: 2, programId: 1, allowed: true, allowPriceOverride: false, slots: 20 },
    { farmerId: 2, programId: 2, allowed: true, allowPriceOverride: false, slots: 15 },
    { farmerId: 2, programId: 4, allowed: true, allowPriceOverride: false, slots: 40 },
    { farmerId: 3, programId: 3, allowed: true, allowPriceOverride: false, slots: 12 },
    { farmerId: 3, programId: 4, allowed: true, allowPriceOverride: false, slots: 30 },
    { farmerId: 4, programId: 1, allowed: true, allowPriceOverride: false, slots: 18 },
    { farmerId: 4, programId: 2, allowed: true, allowPriceOverride: false, slots: 10 },
    { farmerId: 4, programId: 4, allowed: true, allowPriceOverride: false, slots: 25 },
  ]);

  /* ---------- olive trees ---------- */
  interface TreeSeed {
    id: number;
    farmerId: number;
    treeCode: string;
    nameAr: string;
    nameEn: string;
    approximateAge: number;
    oliveVariety: string;
    region: string;
    phase: string;
    images: string[];
    storyAr: string;
    storyEn: string;
    maxSponsors: number;
  }

  const treeSeeds: TreeSeed[] = [
    { id: 1, farmerId: 1, treeCode: "ZT-TREE-000001", nameAr: "شجرة النور", nameEn: "Noor Tree", approximateAge: 120, oliveVariety: "Nabali", region: "Jenin", phase: "season_start", images: [px(34803738), px(36005582)], storyAr: "هذه الشجرة جزء من بستان عائلتنا منذ عام 1948، ونعتني بها أنا وأبنائي كل موسم. جذعها يحمل آثار ثلاثة أجيال.", storyEn: "This tree has been part of our family grove since 1948; my sons and I tend it every season. Its trunk carries the marks of three generations.", maxSponsors: 1 },
    { id: 2, farmerId: 1, treeCode: "ZT-TREE-000002", nameAr: "شجرة الجد", nameEn: "Grandfather's Tree", approximateAge: 180, oliveVariety: "Nabali", region: "Jenin", phase: "growth", images: [px(36005582), px(13786211)], storyAr: "أكبر شجرة في البستان. يقول جدي إنها كانت مثمرة قبل أن يولد.", storyEn: "The largest tree in the grove. My grandfather said it was already bearing fruit before he was born.", maxSponsors: 1 },
    { id: 3, farmerId: 1, treeCode: "ZT-TREE-000003", nameAr: "شجرة الوادي", nameEn: "Valley Tree", approximateAge: 65, oliveVariety: "Suri", region: "Jenin", phase: "flowering", images: [px(13786211), px(34803738)], storyAr: "تقع على حافة الوادي حيث تتجمع مياه المطر، لذلك زيتها أخف وأنعم.", storyEn: "It sits at the edge of the valley where rainwater gathers, so its oil is lighter and milder.", maxSponsors: 3 },
    { id: 4, farmerId: 1, treeCode: "ZT-TREE-000004", nameAr: "شجرة التلة", nameEn: "Hilltop Tree", approximateAge: 90, oliveVariety: "Nabali", region: "Jenin", phase: "season_start", images: [px(31105190), px(34803738)], storyAr: "أعلى نقطة في أرضنا — الرياح تجعل ثمرها أصغر لكن نكهته أقوى.", storyEn: "The highest point of our land — the wind makes its fruit smaller but its flavor stronger.", maxSponsors: 1 },
    { id: 5, farmerId: 1, treeCode: "ZT-TREE-000005", nameAr: "شجرة الصبر", nameEn: "Patience Tree", approximateAge: 45, oliveVariety: "Suri", region: "Jenin", phase: "growth", images: [px(34803738)], storyAr: "زرعها والدي عام 1980 وقال: لن أرى ثمرها، لكنك ستراه.", storyEn: "My father planted it in 1980 and said: I won't see its fruit, but you will.", maxSponsors: 1 },
    { id: 6, farmerId: 1, treeCode: "ZT-TREE-000006", nameAr: "شجرة العين", nameEn: "Spring Tree", approximateAge: 200, oliveVariety: "Nabali", region: "Jenin", phase: "ripening", images: [px(36005582), px(34803738)], storyAr: "قرب عين الماء القديمة في القرية، وكانت ملتقى الفلاحين وقت الحصاد.", storyEn: "Beside the village's old water spring — a meeting point for farmers at harvest time.", maxSponsors: 1 },
    { id: 7, farmerId: 2, treeCode: "ZT-TREE-000007", nameAr: "شجرة طوباس", nameEn: "Tubas Tree", approximateAge: 75, oliveVariety: "Nabali", region: "Tubas", phase: "fruiting", images: [px(37675551), px(18767549)], storyAr: "بين خلايا النحل تمامًا — الزيتون والزعتر والعسل في بقعة واحدة.", storyEn: "Right among the beehives — olives, za'atar and honey in one spot.", maxSponsors: 1 },
    { id: 8, farmerId: 2, treeCode: "ZT-TREE-000008", nameAr: "شجرة الزعتر", nameEn: "Za'atar Tree", approximateAge: 55, oliveVariety: "Suri", region: "Tubas", phase: "flowering", images: [px(18767549), px(37675551)], storyAr: "حولها ينمو الزعتر البري الذي نقطفه كل ربيع.", storyEn: "Wild za'atar grows around it, which we pick every spring.", maxSponsors: 2 },
    { id: 9, farmerId: 2, treeCode: "ZT-TREE-000009", nameAr: "شجرة المصطبة", nameEn: "Terrace Tree", approximateAge: 110, oliveVariety: "Nabali", region: "Tubas", phase: "growth", images: [px(37675551)], storyAr: "على مصطبة حجرية بناها جدي بيده لتحمي التربة من الانجراف.", storyEn: "On a stone terrace my grandfather built by hand to protect the soil from erosion.", maxSponsors: 1 },
    { id: 10, farmerId: 3, treeCode: "ZT-TREE-000010", nameAr: "شجرة الورشة", nameEn: "Workshop Tree", approximateAge: 85, oliveVariety: "Suri", region: "Nablus", phase: "season_start", images: [px(28271468), px(33703946)], storyAr: "من أغصانها المهذّبة نصنع ألواح التقطيع والملاعق الخشبية.", storyEn: "From its pruned branches we make cutting boards and wooden spoons.", maxSponsors: 3 },
    { id: 11, farmerId: 3, treeCode: "ZT-TREE-000011", nameAr: "شجرة نابلس", nameEn: "Nablus Tree", approximateAge: 130, oliveVariety: "Nabali", region: "Nablus", phase: "growth", images: [px(33703946)], storyAr: "زيتونها يُستخدم في صابون نابلس التقليدي منذ عقود.", storyEn: "Its olives have been used in traditional Nablus soap for decades.", maxSponsors: 2 },
    { id: 12, farmerId: 4, treeCode: "ZT-TREE-000012", nameAr: "شجرة رام الله", nameEn: "Ramallah Tree", approximateAge: 60, oliveVariety: "Nabali", region: "Ramallah", phase: "flowering", images: [px(10548607), px(10566051)], storyAr: "في بستان عائلتنا الصغير، ونساء الورشة يقطفن ثمرها كل موسم.", storyEn: "In our small family grove, picked each season by the women of the workshop.", maxSponsors: 1 },
    { id: 13, farmerId: 4, treeCode: "ZT-TREE-000013", nameAr: "شجرة التطريز", nameEn: "Tatreez Tree", approximateAge: 95, oliveVariety: "Suri", region: "Ramallah", phase: "season_start", images: [px(10566051)], storyAr: "سمّتها جدتي باسم نمط التطريز الذي كانت تعمل تحته في ظلها.", storyEn: "My grandmother named it after the embroidery pattern she worked under its shade.", maxSponsors: 2 },
    { id: 14, farmerId: 4, treeCode: "ZT-TREE-000014", nameAr: "شجرة التين", nameEn: "Fig-Neighbor Tree", approximateAge: 70, oliveVariety: "Nabali", region: "Ramallah", phase: "growth", images: [px(10548607)], storyAr: "بجانب شجرة تين قديمة — ظل الشجرتين مكان استراحتنا وقت القطاف.", storyEn: "Next to an old fig tree — the shade of both is our resting spot during picking.", maxSponsors: 1 },
  ];

  await db
    .insert(s.oliveTrees)
    .values(
      treeSeeds.map((t) => ({
        id: t.id,
        farmerId: t.farmerId,
        treeCode: t.treeCode,
        nameAr: t.nameAr,
        nameEn: t.nameEn,
        treeNumber: t.id,
        approximateAge: t.approximateAge,
        oliveVariety: t.oliveVariety,
        region: t.region,
        storyAr: t.storyAr,
        storyEn: t.storyEn,
        images: t.images,
        farmImages: [px(34803738)],
        status: "available" as const,
        verified: true,
        verifiedAt: daysAgo(20),
        season: SEASON,
        phase: t.phase,
        progressPercent: 10,
        maxSponsors: t.maxSponsors,
        sponsorCount: 0,
        createdAt: daysAgo(30),
      })),
    )
    .returning();

  /* a couple of extra gallery rows */
  await db.insert(s.treeImages).values([
    { treeId: 1, url: px(34803738), captionAr: "البستان في الصباح", captionEn: "The grove in the morning", sortOrder: 1 },
    { treeId: 1, url: px(36005582), captionAr: "شجرة النور", captionEn: "Noor tree", sortOrder: 2 },
  ]);

  /* one sponsored tree + one pending-verification tree (moderation demo) */
  await db
    .insert(s.oliveTrees)
    .values([
      {
        id: 15, farmerId: 1, treeCode: "ZT-TREE-000015", nameAr: "شجرة العائلة", nameEn: "Family Tree",
        treeNumber: 15, approximateAge: 150, oliveVariety: "Nabali", region: "Jenin",
        storyAr: "شجرة العائلة الكبيرة — تحت ظلها تُروى قصص المواسم.", storyEn: "The big family tree — season stories are told under its shade.",
        images: [px(34803738), px(36005582)], farmImages: [px(36005582)],
        status: "adopted", verified: true, verifiedAt: daysAgo(40), season: SEASON,
        phase: "harvest", progressPercent: 67, maxSponsors: 1, sponsorCount: 1, createdAt: daysAgo(60),
      },
      {
        id: 16, farmerId: 4, treeCode: "ZT-TREE-000016", nameAr: "شجرة جديدة (قيد التحقق)", nameEn: "New tree (pending verification)",
        treeNumber: 16, approximateAge: 30, oliveVariety: "Suri", region: "Ramallah",
        storyAr: "أضافتها سارة مؤخرًا وتنتظر تحقق فريق زيتون.", storyEn: "Recently added by Sara, awaiting Zeitoun verification.",
        images: [px(10548607)], farmImages: [],
        status: "under_review", verified: false, season: SEASON,
        phase: "season_start", progressPercent: 11, maxSponsors: 1, sponsorCount: 0, createdAt: daysAgo(1),
      },
    ])
    .returning();

  /* ---------- tree seasons ---------- */
  const seasons = await db
    .insert(s.treeSeasons)
    .values([
      { treeId: 1, season: SEASON, phase: "harvest", progressPercent: 67, startedAt: daysAgo(200), notesAr: "موسم جيد، الثمار وفيرة.", notesEn: "A good season with abundant fruit." },
      { treeId: 2, season: SEASON, phase: "ripening", progressPercent: 56, startedAt: daysAgo(190) },
      { treeId: 15, season: SEASON, phase: "harvest", progressPercent: 67, startedAt: daysAgo(210) },
      { treeId: 7, season: SEASON, phase: "fruiting", progressPercent: 44, startedAt: daysAgo(170) },
    ])
    .returning();
  const seasonOf = (treeId: number) => seasons.find((x) => x.treeId === treeId)?.id ?? null;

  /* sync phase/progress on trees that have a season row */
  for (const sn of seasons) {
    await db.update(s.oliveTrees).set({ phase: sn.phase, progressPercent: sn.progressPercent }).where(eq(s.oliveTrees.id, sn.treeId));
  }

  /* ---------- gift occasions ---------- */
  await db.insert(s.giftOccasions).values([
    { key: "birthday", nameAr: "عيد ميلاد", nameEn: "Birthday", sortOrder: 1 },
    { key: "wedding", nameAr: "زفاف", nameEn: "Wedding", sortOrder: 2 },
    { key: "anniversary", nameAr: "ذكرى سنوية", nameEn: "Anniversary", sortOrder: 3 },
    { key: "ramadan", nameAr: "رمضان", nameEn: "Ramadan", sortOrder: 4 },
    { key: "eid", nameAr: "عيد", nameEn: "Eid", sortOrder: 5 },
    { key: "mothers_day", nameAr: "عيد الأم", nameEn: "Mother's Day", sortOrder: 6 },
    { key: "fathers_day", nameAr: "عيد الأب", nameEn: "Father's Day", sortOrder: 7 },
    { key: "graduation", nameAr: "تخرج", nameEn: "Graduation", sortOrder: 8 },
    { key: "general", nameAr: "هدية عامة", nameEn: "General gift", sortOrder: 9 },
  ]);

  /* ---------- existing adoptions (demo customer) ---------- */
  const year = new Date().getFullYear();
  const ordCount = (await db.select({ c: sql<number>`count(*)` }).from(s.orders))[0].c;

  const mkOrder = async (seq: number, userId: number, sellerId: number, total: number, status: string, type: string) => {
    const [o] = await db
      .insert(s.orders)
      .values({
        orderNumber: `ZT-${year}-${String(ordCount + seq).padStart(6, "0")}`,
        checkoutId: `ZA-DEMO${seq}`,
        orderType: type as never,
        userId,
        sellerId,
        subtotalCents: total,
        shippingCents: 0,
        totalCents: total,
        currency: "USD",
        status: status as never,
        address: { note: "digital adoption" },
      })
      .returning();
    await db.insert(s.payments).values({ orderId: o.id, provider: "mock_card", status: "succeeded", amountCents: total, last4: "4242" });
    return o;
  };

  /* 1) active sponsorship of Noor Tree (customer) */
  const oA = await mkOrder(1, 2, sellerOf(3)!, 24000, "confirmed", "ADOPTION_ORDER");
  const adA = (
    await db
      .insert(s.adoptions)
      .values({
        userId: 2, treeId: 1, farmerId: 1, programId: 2, seasonId: seasonOf(1),
        orderNumber: oA.orderNumber, displayName: "شجرتي نور", status: "active",
        startDate: daysAgo(45), endDate: daysAhead(320), priceCents: 24000,
      })
      .returning()
  )[0];
  await db.insert(s.adoptionOrders).values({ orderId: oA.id, adoptionId: adA.id, programId: 2, treeId: 1, amountCents: 24000 });
  await db.update(s.oliveTrees).set({ status: "reserved", sponsorCount: 1 }).where(eq(s.oliveTrees.id, 1));

  /* 2) gift sponsorship (Layla Dabbas → for her mother) */
  const oB = await mkOrder(2, 7, sellerOf(4)!, 12000, "confirmed", "ADOPTION_ORDER");
  const adB = (
    await db
      .insert(s.adoptions)
      .values({
        userId: 7, treeId: 2, farmerId: 1, programId: 1, seasonId: seasonOf(2),
        orderNumber: oB.orderNumber, displayName: "شجرة أمي", status: "active",
        isGift: true, giftRecipientName: "Hana Dabbas", giftMessage: "كل عام وأنتِ بخير يا أمي — شجرة زيتون باسمك من فلسطين.",
        giftOccasion: "mothers_day", giftSendAt: daysAhead(10),
        startDate: daysAgo(20), endDate: daysAhead(345), priceCents: 12000,
      })
      .returning()
  )[0];
  await db.insert(s.adoptionOrders).values({ orderId: oB.id, adoptionId: adB.id, programId: 1, treeId: 2, amountCents: 12000 });
  await db.insert(s.adoptionGifts).values({
    adoptionId: adB.id, recipientName: "Hana Dabbas",
    message: "كل عام وأنتِ بخير يا أمي — شجرة زيتون باسمك من فلسطين.",
    occasion: "mothers_day", sendAt: daysAhead(10),
  });
  await db.update(s.oliveTrees).set({ status: "reserved", sponsorCount: 1 }).where(eq(s.oliveTrees.id, 2));

  /* 3) farmer support (no tree) */
  const oC = await mkOrder(3, 8, sellerOf(4)!, 7500, "confirmed", "ADOPTION_ORDER");
  const adC = (
    await db
      .insert(s.adoptions)
      .values({
        userId: 8, treeId: null, farmerId: 2, programId: 4, orderNumber: oC.orderNumber,
        status: "active", startDate: daysAgo(10), endDate: daysAhead(355), priceCents: 7500,
      })
      .returning()
  )[0];
  await db.insert(s.adoptionOrders).values({ orderId: oC.id, adoptionId: adC.id, programId: 4, amountCents: 7500 });

  /* 4) expiring soon (renewal demo) + 5) completed/renewed */
  const oD = await mkOrder(4, 2, sellerOf(3)!, 12000, "delivered", "ADOPTION_ORDER");
  const adD = (
    await db
      .insert(s.adoptions)
      .values({
        userId: 2, treeId: 15, farmerId: 1, programId: 1, seasonId: seasonOf(15),
        orderNumber: oD.orderNumber, displayName: "Olive Tree #15", status: "active",
        startDate: daysAgo(350), endDate: daysAhead(12), priceCents: 12000,
      })
      .returning()
  )[0];
  await db.insert(s.adoptionOrders).values({ orderId: oD.id, adoptionId: adD.id, programId: 1, treeId: 15, amountCents: 12000 });

  /* ---------- certificates with QR ---------- */
  const base = process.env.NEXT_PUBLIC_SITE_URL || "";
  const mkCert = async (adoptionId: number, code: string, target: string, data: any) => {
    const qr = await QRCode.toDataURL(`${base}${target}`, { margin: 1, width: 320, color: { dark: "#333d21", light: "#faf8f2" } });
    await db.insert(s.adoptionCertificates).values({ adoptionId, code, qrDataUrl: qr, ...data });
    await db.update(s.adoptions).set({ certificateCode: code }).where(eq(s.adoptions.id, adoptionId));
  };

  await mkCert(adA.id, "ZT-CERT-000001", "/trees/ZT-TREE-000001", {
    sponsorName: "Layla Haddad", treeName: "شجرتي نور", treeCode: "ZT-TREE-000001",
    farmerName: "Abu Ahmad", farmName: "Old Olive Farm", region: "Jenin", season: SEASON, startDate: daysAgo(45),
  });
  await mkCert(adB.id, "ZT-CERT-000002", "/trees/ZT-TREE-000002", {
    sponsorName: "Hana Dabbas", treeName: "شجرة أمي", treeCode: "ZT-TREE-000002",
    farmerName: "Abu Ahmad", farmName: "Old Olive Farm", region: "Jenin", season: SEASON, startDate: daysAgo(20),
  });
  await mkCert(adC.id, "ZT-CERT-000003", "/farmers/tubas-fields", {
    sponsorName: "Omar Darwish", treeName: null, treeCode: null,
    farmerName: "Nadia Khoury", farmName: "Tubas Fields", region: "Tubas", season: SEASON, startDate: daysAgo(10),
  });
  await mkCert(adD.id, "ZT-CERT-000004", "/trees/ZT-TREE-000015", {
    sponsorName: "Layla Haddad", treeName: "Olive Tree #15", treeCode: "ZT-TREE-000015",
    farmerName: "Abu Ahmad", farmName: "Old Olive Farm", region: "Jenin", season: SEASON, startDate: daysAgo(350),
  });

  /* ---------- farmer updates ---------- */
  await db.insert(s.adoptionUpdates).values([
    {
      farmerId: 1, treeId: 1, titleAr: "بدأنا الاستعداد للحصاد", titleEn: "We started preparing for harvest",
      bodyAr: "الثمار اكتمل نضجها تقريبًا. سنبدأ القطاف اليدوي خلال أسبوعين، وسأرسل لكم صورًا من التلة.",
      bodyEn: "The fruit is nearly fully ripe. Hand-picking starts in two weeks — I'll send you photos from the hill.",
      image: px(36005582), phase: "harvest", createdAt: daysAgo(3),
    },
    {
      farmerId: 1, treeId: 1, titleAr: "مرحلة الإزهار هذا الأسبوع", titleEn: "Flowering began this week",
      bodyAr: "الأشجار تبدو بحالة ممتازة، والزهر غطى الأغصان. موسم مبشّر إن شاء الله.",
      bodyEn: "The trees look excellent and the blossoms cover the branches. A promising season.",
      image: px(34803738), phase: "flowering", createdAt: daysAgo(40),
    },
    {
      farmerId: 1, treeId: 15, titleAr: "تم عصر زيت موسم شجرتك", titleEn: "Your tree's season oil has been pressed",
      bodyAr: "عصرنا الزيتون في معصرة القرية خلال 24 ساعة من القطاف. الزيت جاهز للتعبئة.",
      bodyEn: "We pressed the olives at the village mill within 24 hours of picking. The oil is ready for packing.",
      image: px(31105190), phase: "pressing", createdAt: daysAgo(12),
    },
    {
      farmerId: 2, treeId: 7, titleAr: "ثمار الزيتون بدأت تتكوّن", titleEn: "The olives have started to set",
      bodyAr: "بين خلايا النحل، الثمار الصغيرة ظهرت على الأغصان.",
      bodyEn: "Among the beehives, the small fruits have appeared on the branches.",
      image: px(37675551), phase: "fruiting", createdAt: daysAgo(8),
    },
    {
      farmerId: 2, treeId: null, titleAr: "قطفنا الزعتر البري هذا الربيع", titleEn: "We picked wild za'atar this spring",
      bodyAr: "موسم الزعتر انتهى والتجفيف تم في الظل للحفاظ على العطر.",
      bodyEn: "The za'atar season is over; drying was done in the shade to preserve the aroma.",
      image: px(18767549), phase: null, createdAt: daysAgo(30),
    },
    {
      farmerId: 4, treeId: 12, titleAr: "شجرتك في مرحلة الإزهار", titleEn: "Your tree is flowering",
      bodyAr: "نساء الورشة مررن بالبستان هذا الصباح والزهر مفتوح.",
      bodyEn: "The workshop women passed the grove this morning — the blossoms are open.",
      image: px(10548607), phase: "flowering", createdAt: daysAgo(5),
    },
  ]);

  /* ---------- notifications for sponsors ---------- */
  await db.insert(s.notifications).values([
    {
      userId: 2, type: "adoption_update", titleAr: "🫒 بدأ موسم الحصاد", titleEn: "🫒 Harvest season has begun",
      bodyAr: "أبو أحمد: الثمار اكتمل نضجها تقريبًا، والقطاف خلال أسبوعين.",
      bodyEn: "Abu Ahmad: the fruit is nearly ripe, picking starts in two weeks.",
      link: "/my-trees", createdAt: daysAgo(3),
    },
    {
      userId: 2, type: "adoption_cert", titleAr: "📜 شهادة الرعاية جاهزة", titleEn: "📜 Your sponsorship certificate is ready",
      bodyAr: "شجرتك نور — ZT-TREE-000001", bodyEn: "Your tree Noor — ZT-TREE-000001",
      link: "/certificate/ZT-CERT-000001", createdAt: daysAgo(45), readAt: daysAgo(44),
    },
    {
      userId: 2, type: "adoption_renew", titleAr: "⏳ ستنتهي رعاية شجرتك قريبًا", titleEn: "⏳ Your tree's sponsorship ends soon",
      bodyAr: "Olive Tree #15 — يمكنك تجديد الرعاية الآن.", bodyEn: "Olive Tree #15 — you can renew now.",
      link: "/my-trees", createdAt: daysAgo(2),
    },
    {
      userId: 7, type: "adoption_cert", titleAr: "🎁 هدية الرعاية جاهزة", titleEn: "🎁 Your sponsorship gift is ready",
      bodyAr: "شجرة أمي — ZT-TREE-000002", bodyEn: "Mama's tree — ZT-TREE-000002",
      link: "/certificate/ZT-CERT-000002", createdAt: daysAgo(20),
    },
    {
      userId: 8, type: "adoption_update", titleAr: "🌿 تحديث من مزرعة ناديا", titleEn: "🌿 Update from Nadia's farm",
      bodyAr: "قطفنا الزعتر البري هذا الربيع.", bodyEn: "We picked wild za'atar this spring.",
      link: "/my-trees", createdAt: daysAgo(30), readAt: daysAgo(29),
    },
    {
      userId: 3, type: "new_sponsor", titleAr: "🌿 داعم جديد لبرنامج التبني", titleEn: "🌿 New adoption sponsor",
      bodyAr: "شجرة ZT-TREE-000001 — رعاية مميزة", bodyEn: "Tree ZT-TREE-000001 — Premium adoption",
      link: "/dashboard/seller?tab=trees", createdAt: daysAgo(45), readAt: daysAgo(44),
    },
  ]);

  /* ---------- farmer counters ---------- */
  await db.execute(sql`UPDATE farmers SET tree_count = (SELECT count(*) FROM olive_trees WHERE farmer_id = farmers.id)`);

  /* ---------- sequence sync ---------- */
  for (const t of ["farmers", "olive_trees", "tree_seasons", "adoption_programs", "farmer_support_programs", "adoptions", "adoption_updates", "adoption_certificates", "adoption_gifts", "adoption_orders", "gift_occasions", "tree_images"]) {
    await pool.query(`SELECT setval(pg_get_serial_sequence('${t}', 'id'), COALESCE((SELECT max(id) FROM ${t}), 0) + 1, false)`);
  }

  console.log("✅ Adoption seed complete.");
  console.log("   trees: 16 (14 verified available, 1 sponsored, 1 pending verification)");
  console.log("   programs: 4 · adoptions: 4 · certificates: ZT-CERT-000001..4");
  await pool.end();
}

main().catch(async (e) => {
  console.error("❌ Adoption seed failed:", e?.message ?? e);
  process.exit(1);
});
