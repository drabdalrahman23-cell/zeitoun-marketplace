/* Zeitoun seed script — run with: npx tsx src/db/seed.ts */
import { config } from "dotenv";
config();

import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import * as s from "./schema";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;
const daysAgo = (n: number) => new Date(Date.now() - n * 86400000);

async function main() {
  console.log("🌱 Seeding Zeitoun...");
  await db.execute(
    sql`TRUNCATE users, sellers, seller_applications, products, orders, order_items, payments, shipments, reviews, favorites, messages, conversations, notifications, reports, password_resets, shipping_addresses, offers, countries, currencies, shipping_methods, categories, site_content RESTART IDENTITY CASCADE`,
  );

  /* ---------- users ---------- */
  const pw = await bcrypt.hash("demo123", 10);
  const pwAdmin = await bcrypt.hash("admin123", 10);
  const users = await db
    .insert(s.users)
    .values([
      { id: 1, name: "Zeitoun Admin", email: "admin@zeitoun.app", passwordHash: pwAdmin, role: "admin" },
      { id: 2, name: "Layla Haddad", email: "customer@zeitoun.app", passwordHash: pw, role: "customer", phone: "+1 202 555 0117" },
      { id: 3, name: "Abu Ahmad", email: "seller@zeitoun.app", passwordHash: pw, role: "seller", phone: "+970 59 900 1122" },
      { id: 4, name: "Nadia Khoury", email: "nadia@zeitoun.app", passwordHash: pw, role: "seller", phone: "+970 59 900 3344" },
      { id: 5, name: "Omar Nassar", email: "omar@zeitoun.app", passwordHash: pw, role: "seller", phone: "+970 59 900 5566" },
      { id: 6, name: "Sara Yousef", email: "sara@zeitoun.app", passwordHash: pw, role: "seller", phone: "+970 59 900 7788" },
      { id: 7, name: "Layla Dabbas", email: "layla.demo@gmail.com", passwordHash: pw, role: "customer" },
      { id: 8, name: "Omar Darwish", email: "omar.demo@gmail.com", passwordHash: pw, role: "customer" },
    ])
    .returning();
  const user = (id: number) => users.find((u) => u.id === id)!;

  /* ---------- categories ---------- */
  const catRows = await db
    .insert(s.categories)
    .values([
      { id: 1, nameAr: "زيت الزيتون والزيتون", nameEn: "Olive Oil & Olives", slug: "olive", icon: "🫒", sortOrder: 1 },
      { id: 2, nameAr: "المنتجات الزراعية", nameEn: "Agricultural", slug: "agricultural", icon: "🌿", sortOrder: 2 },
      { id: 3, nameAr: "العسل والأغذية الطبيعية", nameEn: "Honey & Natural Foods", slug: "honey", icon: "🍯", sortOrder: 3 },
      { id: 4, nameAr: "الأعشاب والتوابل", nameEn: "Herbs & Spices", slug: "herbs", icon: "🌱", sortOrder: 4 },
      { id: 5, nameAr: "التطريز والمنسوجات", nameEn: "Embroidery & Textiles", slug: "embroidery", icon: "🧵", sortOrder: 5 },
      { id: 6, nameAr: "الحرف اليدوية", nameEn: "Handicrafts", slug: "crafts", icon: "🏺", sortOrder: 6 },
      { id: 7, nameAr: "المنتجات التراثية", nameEn: "Heritage Items", slug: "heritage", icon: "🏛️", sortOrder: 7 },
      { id: 8, nameAr: "الهدايا الفلسطينية", nameEn: "Palestinian Gifts", slug: "gifts", icon: "🎁", sortOrder: 8 },
      { id: 9, nameAr: "المنتجات الخشبية", nameEn: "Wood Products", slug: "wood", icon: "🪵", sortOrder: 9 },
      { id: 10, nameAr: "المنتجات الغذائية", nameEn: "Food Products", slug: "food", icon: "🍽️", sortOrder: 10 },
      { id: 11, nameAr: "الفن والمنتجات الفنية", nameEn: "Art & Artisan", slug: "art", icon: "🎨", sortOrder: 11 },
    ])
    .returning();
  const cat = (i: number) => catRows[i - 1].id;

  /* ---------- sellers ---------- */
  const sellers = await db
    .insert(s.sellers)
    .values([
      {
        id: 1, userId: 3, shopName: "Old Olive Farm | مزرعة الزيتون القديم", slug: "old-olive-farm",
        region: "North West Bank", city: "Jenin",
        about: "A family olive farm in the hills of Jenin. Our trees are between 80 and 300 years old, tended by three generations of the same family.",
        story: "Abu Ahmad inherited 400 olive trees from his grandfather in 1996. Every November the whole family — kids included — climbs the hills to harvest. The oil is pressed within 24 hours at the village cooperative press, still working with the same stone mill built in the 1970s.",
        images: [px(34803738), px(36005582), px(31105190)],
        rating: "4.8", orderCount: 1, joinedAt: daysAgo(700),
      },
      {
        id: 2, userId: 4, shopName: "Tubas Fields | حقول طوباس", slug: "tubas-fields",
        region: "Tubas Governorate", city: "Tubas",
        about: "Farm products from the green fields of Tubas — honey from mountain beehives, wild za'atar gathered from the slopes, and dates from our own orchard.",
        story: "Nadia grew up between the beehives her father kept on the mountain terraces above Tubas. Today she runs 60 hives herself and still harvests the za'atar by hand every spring, the way her mother taught her.",
        images: [px(37675551), px(18767549)],
        rating: "4.9", orderCount: 1, joinedAt: daysAgo(540),
      },
      {
        id: 3, userId: 5, shopName: "Nour's Craft House | بيت نور للحرف", slug: "nours-craft-house",
        region: "Nablus", city: "Nablus",
        about: "Traditional Nablus handicrafts: olive oil soap cured for 45 days, pottery from the old kilns, and baskets woven from palm leaves.",
        story: "The Nour workshop in the heart of Nablus has been making olive soap since 1962. The recipe never changed: pure olive oil, olive lye and 45 days of natural curing under the Judean hills.",
        images: [px(28271468), px(33703946)],
        rating: "4.7", orderCount: 1, joinedAt: daysAgo(420),
      },
      {
        id: 4, userId: 6, shopName: "Ramallah Makers | ورشة رام الله", slug: "ramallah-makers",
        region: "Ramallah", city: "Ramallah",
        about: "Handmade woodwork from olive wood, authentic Palestinian embroidery (Tatreez) and curated gift boxes — made slowly, in small batches.",
        story: "Sara learned Tatreez from her grandmother in Ayn Karim. Her workshop now works with twelve women from around Ramallah, keeping patterns alive that date back over a hundred years.",
        images: [px(10566051), px(10548607)],
        rating: "4.8", orderCount: 0, joinedAt: daysAgo(300),
      },
    ])
    .returning();

  /* ---------- products ---------- */
  const P = (
    id: number, sellerId: number, categoryId: number, nameAr: string, nameEn: string, slug: string,
    priceCents: number, stock: number, weightGrams: number, originRegion: string, images: string[],
    dAr: string, dEn: string, sAr: string, sEn: string,
    extra: Record<string, unknown> = {},
  ) => ({
    id, sellerId, categoryId, nameAr, nameEn, slug,
    descriptionAr: dAr, descriptionEn: dEn,
    priceCents, stock, weightGrams, originRegion, images,
    storyAr: sAr, storyEn: sEn,
    rating: "0", reviewCount: 0, salesCount: 0,
    isFeatured: false, shipsInternational: true, status: "active" as const,
    createdAt: daysAgo(60 + id),
    ...extra,
  });

  const products = await db
    .insert(s.products)
    .values([
      P(1, 1, cat(1), "زيت زيتون بكر ممتاز — 500مل", "Extra Virgin Olive Oil 500ml", "palestinian-extra-virgin-olive-oil", 3200, 24, 900, "Jenin",
        [px(21911357), px(31105190), px(5737246)],
        "زيت زيتون بكر ممتاز معصور على البارد خلال 24 ساعة من القطف. نكهة قوية بالفليفحة وخاتمة حارة مميزة، من أشجار يزيد عمرها عن 100 عام في تلال جنين.",
        "Cold-pressed extra virgin olive oil, pressed within 24 hours of harvest. A robust pepperiness and a spicy finish, from trees over 100 years old in the hills of Jenin.",
        "عائلة أبو أحمد تحصد الزيتون كل نوفمبر منذ جيل ثالث. الزيتون يُعصر في معصرة القرية خلال يوم واحد من القطف، ليحتفظ بكل خصائصه.",
        "The Abu Ahmad family harvests by hand every November — three generations now. The olives are pressed at the village mill within 24 hours to keep every nutrient and flavor.",
        { isFeatured: true, salesCount: 14, rating: "4.7", reviewCount: 3, harvestSeason: "October – November", ingredientsAr: "زيت زيتون بكر ممتاز 100%", ingredientsEn: "100% extra virgin olive oil", productionMethodAr: "عصر بارد خلال 24 ساعة", productionMethodEn: "Cold-pressed within 24h", storyImages: [px(34803738)] }),
      P(2, 1, cat(1), "زيت زيتون معصور على البارد — 1 لتر", "Cold-Pressed Olive Oil 1L", "cold-pressed-olive-oil-1l", 2600, 30, 1500, "Jenin",
        [px(11692924), px(21911357)],
        "زيت زيتون يومية من موسم 2026، مثالي للطبخ والسلطات والمقبلات.",
        "Everyday cold-pressed olive oil from the 2026 season. Perfect for cooking, salads and dips.",
        "شحنة عائلية أكبر بسعر أوفر، من نفس الأشجار ونفس المعصرة.",
        "A bigger family-size pour from the same trees and the same village press.",
        { salesCount: 9, harvestSeason: "October – November", ingredientsEn: "100% extra virgin olive oil" }),
      P(3, 1, cat(1), "زيتون أسود مخلل — 750غ", "Marinated Black Olives 750g", "marinated-black-olives", 1400, 40, 750, "Jenin",
        [px(4660206), px(1611560)],
        "زيتون أسود محشو بالثوم والزعتر، مخلل على الطريقة التقليدية.",
        "Black olives marinated with garlic and thyme the traditional way.",
        "نختر نواة الزيتون الناضج فقط ونحشوه يدوياً.",
        "We pick only fully ripe olives and stuff them by hand.",
        { salesCount: 6, ingredientsAr: "زيتون، ثوم، زعتر، زيت زيتون، ملح", ingredientsEn: "Olives, garlic, thyme, olive oil, salt" }),
      P(4, 1, cat(1), "زيتون أخضر بحشوة الليمون — 750غ", "Lemon-Stuffed Green Olives 750g", "lemon-stuffed-green-olives", 1600, 25, 750, "Jenin",
        [px(29060270), px(4660206)],
        "زيتون أخضر طري بحشوة شرائح الليمون — ليمونة منعشة مع كل قضمة.",
        "Tender green olives stuffed with lemon slices — a bright burst of citrus in every bite.",
        "من أشجار الزيتون الأخضر في الجهة الشمالية من المزرعة.",
        "From the green-olive grove on the north side of the farm.",
        { salesCount: 4, ingredientsAr: "زيتون، ليمون، زيت زيتون، ملح", ingredientsEn: "Olives, lemon, olive oil, salt" }),
      P(5, 2, cat(4), "زعتر بري مطحون مع سمسم — 250غ", "Wild Za'atar Blend with Sesame 250g", "wild-zaatar-blend", 1200, 50, 250, "Tubas",
        [px(4871138), px(4871133), px(18767549)],
        "زعتر بري يُقطف يدوياً من سفوح جبال طوباس، يُطحن مع السمسم المحمص ويطويه الملح الناعم. مع خبز سخن وزيت زيتون، هذا هو فلسطين.",
        "Wild thyme hand-gathered from the slopes of Tubas, ground with toasted sesame and fine salt. With warm bread and olive oil — this is Palestine.",
        "نقطف الزعتر كل ربيع قبل أن يزهر، ونجففه في الظل لنحافظ على عطره.",
        "We pick the thyme every spring before it flowers and dry it in the shade to keep its perfume.",
        { isFeatured: true, salesCount: 11, rating: "5.0", reviewCount: 2, harvestSeason: "March – May", ingredientsAr: "زعتر بري، سمسم محمص، ملح", ingredientsEn: "Wild thyme, toasted sesame, salt" }),
      P(6, 2, cat(3), "عسل جبلي نقي — 500غ", "Pure Mountain Honey 500g", "pure-mountain-honey", 2800, 35, 500, "Tubas",
        [px(7990484), px(8540941)],
        "عسل طبيعي 100% من 60 خلية على تلال طوباس، متعدد الأزهار ولم يُعبر من حرارة.",
        "100% raw honey from 60 hives on the Tubas hills. Multi-floral, never heated.",
        "خلايا نادية تقع فوق terraces الجبلية حيث تزهر الحماضيات وأشجار الأوكالبتوس.",
        "Nadia's hives sit on mountain terraces among citrus and eucalyptus blooms.",
        { isFeatured: true, salesCount: 8, rating: "4.5", reviewCount: 2, harvestSeason: "Summer", ingredientsAr: "عسل طبيعي", ingredientsEn: "Raw honey" }),
      P(7, 2, cat(3), "عسل زهور البرية — 500غ", "Wildflower Honey 500g", "wildflower-honey", 3200, 20, 500, "Tubas",
        [px(8540941), px(30969035)],
        "دفع محدود من عسل زهور البرية — نكهات عطرية متغيرة حسب موسم الأزهار.",
        "A limited run of wildflower honey — aromatic notes that shift with each blossom season.",
        "يُجمع فقط عندما تكون الأزهار البرية في ذروتها.",
        "Only gathered when wildflowers are at their peak.",
        { salesCount: 5, harvestSeason: "Spring" }),
      P(8, 2, cat(10), "تمر الخلاص الفاخر — 1كغ", "Premium Medjool Dates 1kg", "premium-medjool-dates", 1800, 30, 1000, "Tubas",
        [px(15913423), px(17302469), px(15913411)],
        "تمر خلاص كبير الحبة، طري وعسلية المذاق، من بساتين المنطقة.",
        "Large, tender, honey-sweet Medjool dates from local orchards.",
        "نقطف في ذروة النضج ثم نعبئه يدوياً.",
        "Picked at peak ripeness and packed by hand.",
        { salesCount: 7, harvestSeason: "September – October" }),
      P(9, 2, cat(4), "سماق مطحون — 200غ", "Ground Sumac 200g", "ground-sumac", 1100, 45, 200, "Tubas",
        [px(18767549), px(4871133)],
        "سماق أحمر بلون عنابي عميق، حمضيته المثالية مع المشاوي والحمص.",
        "Deep garnet sumac with the perfect tang for grills and hummus.",
        "", "",
        { salesCount: 3, ingredientsEn: "Dried ground sumac berries" }),
      P(10, 2, cat(2), "برغل ناعم من قمح فلسطيني — 1كغ", "Palestinian Fine Bulgur 1kg", "palestinian-fine-bulgur", 1300, 40, 1000, "Tubas",
        [px(18767549), px(15347180)],
        "قمح يُزرع محلياً ويُطحن ناعماً — أساس التبولة والفريكة.",
        "Locally grown wheat, finely milled — the base of tabbouleh and frekeh.",
        "من حقول القمح المحيطة بطوباس، تُطحن عند الطلب.",
        "From wheat fields around Tubas, milled on order.",
        { salesCount: 4, harvestSeason: "June – July", ingredientsAr: "قمح كامل مطهو ومجفف", ingredientsEn: "Parboiled & dried whole wheat" }),
      P(11, 3, cat(6), "صابون زيتون نابلسي — 200غ", "Nablus Olive Oil Soap 200g", "nablus-olive-soap", 900, 100, 200, "Nablus",
        [px(10155373), px(6690863), px(7500299)],
        "صابون زيتون أصيل من نابلس، يُصنع بالليفي المصنوع من زيت الزيتون ويُعتق 45 يوماً. لطيف على البشرة، بتركيبة لم تتغير منذ عقود.",
        "Authentic Nablus olive soap made with olive lye and cured for 45 days. Gentle on skin, with a recipe unchanged for decades.",
        "ورشة نور تصنع الصابون منذ 1962 بالوصفة نفسها: زيت، ليفي، و45 يوماً من الاعتق الطبيعي.",
        "The Nour workshop has made this soap since 1962 with the same recipe: olive oil, lye and 45 days of natural curing.",
        { isFeatured: true, salesCount: 12, rating: "4.7", reviewCount: 3, productionMethodAr: "اعتق طبيعي 45 يوماً", productionMethodEn: "45-day natural cure", ingredientsAr: "زيت زيتون، ليفي", ingredientsEn: "Olive oil, lye" }),
      P(12, 3, cat(6), "طقم فؤرات فخارية — 3 قطع", "Ceramic Bowl Set (3 pcs)", "ceramic-bowl-set", 4500, 15, 2000, "Nablus",
        [px(33703946), px(28271468), px(34004102)],
        "ثلاثة أصحان فخارية بأحجام مختلفة، مبرومة يدوياً ومطعّمة بطلاء آمن غذائياً. كل قطعة مختلفة قليلاً — لأن يد الإنسان تصنعها.",
        "Three hand-thrown stoneware bowls in different sizes with food-safe glaze. Each one is slightly unique — made by human hands.",
        "يُشوى الفخار في أفران تعمل بالغاز حسب الطريقة التقليدية.",
        "Fired in traditional-style gas kilns.",
        { salesCount: 4, productionMethodEn: "Hand-thrown stoneware" }),
      P(13, 3, cat(7), "سلة خوص مصنوعة يدوياً", "Handwoven Palm Basket", "handwoven-palm-basket", 3800, 18, 1200, "Nablus",
        [px(29681893), px(9695849), px(19687408)],
        "سلة من أوراق النخيل المجففة، محبوكة يدوياً بأنماط تقليدية. مثالية للخضار، الثمار أو كقطعة ديكور.",
        "Woven from dried palm leaves with traditional patterns. Perfect for produce, fruit or as a decorative piece.",
        "نحبك السلال كما كانت تُصنع في قريتنا قبل جيل.",
        "We weave the same way our village did a generation ago.",
        { salesCount: 3 }),
      P(14, 4, cat(9), "لوح تقطيع من خشب الزيتون", "Olive Wood Cutting Board", "olive-wood-cutting-board", 3600, 22, 1200, "Ramallah",
        [px(10548607), px(38540167)],
        "لوح تقطيع من خشب أشجار الزيتون المهضبة، يُصقل يدوياً بزيت طبيعي. عروق الخشب تجعل كل لوح قطعة فريدة.",
        "A cutting board from pruned olive tree wood, hand-finished with natural oil. The grain makes every board one of a kind.",
        "نعتمد على أخشاب الأشجار المهضبة فقط — لا نقطع شجرة واحدة.",
        "We only use pruned branches — we never cut a tree.",
        { isFeatured: true, salesCount: 5, rating: "5.0", reviewCount: 1, productionMethodAr: "تشطيب يدوي بزيت طبيعي", productionMethodEn: "Hand-finished with natural oil" }),
      P(15, 4, cat(9), "طقم ملاعق خشب الزيتون — 4", "Olive Wood Spoon Set (4)", "olive-wood-spoon-set", 2400, 28, 600, "Ramallah",
        [px(38540167), px(3847514)],
        "أربع ملاعق خشب زيتون بأحجام للطبخ والحلويات، مصقولة يدوياً.",
        "Four hand-polished olive wood spoons for cooking and desserts.",
        "", "",
        { salesCount: 3 }),
      P(16, 4, cat(5), "وشاح مطرز باليد — تطريز فلسطيني", "Hand-Embroidered Scarf — Palestinian Tatreez", "hand-embroidered-scarf", 5500, 10, 150, "Ramallah",
        [px(10566051), px(3563554), px(39081592)],
        "وشاح كتان بعرض التطريز التقليدي (التطريز)، نفذته يدوياً إحدى نساء ورشة رام الله بنمط «العوسج» التراثي. ساعات من الشغل على كل وشاح.",
        "A linen scarf with traditional Tatreez embroidery, stitched by hand by a woman of the Ramallah workshop using the heritage 'Aousij' pattern. Hours of work in every scarf.",
        "النقش «العوسج» يرمز لشجاعة شجرة العوسج البرية التي تنمو صلبة على صخور الضفة.",
        "The 'Aousij' motif stands for the wild thorny oak that grows hard on the rocks of the hills.",
        { salesCount: 2, productionMethodAr: "تطريز يدوي بخيوط قطنية", productionMethodEn: "Hand-stitched with cotton thread" }),
      P(17, 4, cat(5), "منشفة شاي مطرزة", "Embroidered Tea Towel", "embroidered-tea-towel", 1900, 26, 200, "Ramallah",
        [px(3563554), px(12972006)],
        "منشفة شاي قطنية بحافة مطرزة يدوياً بنمط نجمي بسيط.",
        "A cotton tea towel with a hand-embroidered star-patterned border.",
        "", "",
        { salesCount: 4 }),
      P(18, 4, cat(8), "صندوق هدايا فلسطيني", "Palestinian Gift Box", "palestinian-gift-box", 6800, 12, 2500, "Ramallah",
        [px(1718198), px(5467162), px(15913423)],
        "تشكيلة مختارة من فلسطين: زيت زيتون بكر ممتاز، عسل جبلي، تمر خلاص، صابون زيتون نابلسي، وزعتر بري — في صندوق هدايا أنيق مع رسالة من البائع.",
        "A curated taste of Palestine: extra virgin olive oil, mountain honey, Medjool dates, Nablus olive soap and wild za'atar — in an elegant gift box with a note from the makers.",
        "كل صندوق يُجهز يدوياً بمنتجات من أربعة بائعين فلسطينيين، مع رسالة خطية.",
        "Every box is prepared by hand with products from four Palestinian makers, plus a handwritten note.",
        { isFeatured: true, salesCount: 3, rating: "4.5", reviewCount: 2, ingredientsAr: "زيت زيتون، عسل، تمر، صابون زيتون، زعتر", ingredientsEn: "Olive oil, honey, dates, olive soap, za'atar" }),
    ])
    .returning();

  /* ---------- currencies / countries / methods ---------- */
  await db.insert(s.currencies).values([
    { code: "USD", nameAr: "دولار أمريكي", nameEn: "US Dollar", symbol: "$", ratePerUsd: "1.0000" },
    { code: "EUR", nameAr: "يورو", nameEn: "Euro", symbol: "€", ratePerUsd: "0.9200" },
    { code: "GBP", nameAr: "جنيه إسترليني", nameEn: "British Pound", symbol: "£", ratePerUsd: "0.7900" },
    { code: "JOD", nameAr: "دينار أردني", nameEn: "Jordanian Dinar", symbol: "JD", ratePerUsd: "0.7090" },
    { code: "ILS", nameAr: "شيكل", nameEn: "Israeli Shekel", symbol: "₪", ratePerUsd: "3.7000" },
    { code: "AED", nameAr: "درهم إماراتي", nameEn: "UAE Dirham", symbol: "AED", ratePerUsd: "3.6700" },
    { code: "SAR", nameAr: "ريال سعودي", nameEn: "Saudi Riyal", symbol: "SAR", ratePerUsd: "3.7500" },
  ]);

  await db.insert(s.countries).values([
    { code: "US", nameAr: "الولايات المتحدة", nameEn: "United States", region: "americas", surchargeCents: 0 },
    { code: "CA", nameAr: "كندا", nameEn: "Canada", region: "americas", surchargeCents: 300 },
    { code: "GB", nameAr: "المملكة المتحدة", nameEn: "United Kingdom", region: "europe", surchargeCents: 300 },
    { code: "FR", nameAr: "فرنسا", nameEn: "France", region: "europe", surchargeCents: 300 },
    { code: "DE", nameAr: "ألمانيا", nameEn: "Germany", region: "europe", surchargeCents: 300 },
    { code: "NL", nameAr: "هولندا", nameEn: "Netherlands", region: "europe", surchargeCents: 300 },
    { code: "IT", nameAr: "إيطاليا", nameEn: "Italy", region: "europe", surchargeCents: 400 },
    { code: "ES", nameAr: "إسبانيا", nameEn: "Spain", region: "europe", surchargeCents: 400 },
    { code: "AE", nameAr: "الإمارات", nameEn: "United Arab Emirates", region: "gulf", surchargeCents: 0 },
    { code: "SA", nameAr: "السعودية", nameEn: "Saudi Arabia", region: "gulf", surchargeCents: 0 },
    { code: "QA", nameAr: "قطر", nameEn: "Qatar", region: "gulf", surchargeCents: 200 },
    { code: "KW", nameAr: "الكويت", nameEn: "Kuwait", region: "gulf", surchargeCents: 200 },
    { code: "AU", nameAr: "أستراليا", nameEn: "Australia", region: "oceania", surchargeCents: 600 },
    { code: "NZ", nameAr: "نيوزيلندا", nameEn: "New Zealand", region: "oceania", surchargeCents: 700 },
    { code: "JO", nameAr: "الأردن", nameEn: "Jordan", region: "gulf", surchargeCents: 0 },
    { code: "EG", nameAr: "مصر", nameEn: "Egypt", region: "africa", surchargeCents: 200 },
  ]);

  await db.insert(s.shippingMethods).values([
    { nameAr: "شحن قياسي", nameEn: "Standard", daysMin: 7, daysMax: 14, baseCents: 900, perKgCents: 400 },
    { nameAr: "شحن سريع", nameEn: "Express", daysMin: 3, daysMax: 5, baseCents: 1900, perKgCents: 700 },
  ]);

  await db.insert(s.offers).values([
    { code: "WELCOME10", type: "percent", value: 10, minSubtotalCents: 2500 },
    { code: "ZAIT20", type: "fixed", value: 2000, minSubtotalCents: 4000 },
  ]);

  /* ---------- site content ---------- */
  await db.insert(s.siteContent).values([
    { key: "hero", value: { ar: { title: "من أرض فلسطين إلى بيتك مباشرة", subtitle: "زيت، عسل، زعتر، تطريز ومنتجات يدوية — مباشرة من المزارع والورش الفلسطينية إلى باب منزلك في أي مكان في العالم." }, en: { title: "From the land of Palestine, to your door", subtitle: "Olive oil, honey, za'atar, tatreez and handmade goods — straight from Palestinian farms and workshops to your door, anywhere in the world." } } },
    { key: "announcement", value: { ar: "🫒 موسم حصاد 2026 وصل — زيت جديد من مزارع جنين", en: "🫒 The 2026 harvest is here — fresh oil from the farms of Jenin" } },
  ]);

  /* ---------- orders (customer demo) ---------- */
  const year = new Date().getFullYear();
  const o1 = await db.insert(s.orders).values({
    orderNumber: `ZT-${year}-000001`, checkoutId: "ZC-DEMO1", userId: 2, sellerId: 1,
    subtotalCents: 3200, discountCents: 0, shippingCents: 1110, totalCents: 4310, currency: "USD",
    status: "delivered",
    address: { fullName: "Layla Haddad", phone: "+1 202 555 0117", country: "United States", countryCode: "US", state: "DC", city: "Washington", addressLine: "1600 Pennsylvania Ave NW", postalCode: "20500" },
    createdAt: daysAgo(25), updatedAt: daysAgo(12),
  }).returning();
  await db.insert(s.orderItems).values({ orderId: o1[0].id, productId: 1, productNameAr: "زيت زيتون بكر ممتاز — 500مل", productNameEn: "Extra Virgin Olive Oil 500ml", priceCents: 3200, quantity: 1, weightGrams: 900, image: px(21911357) });
  await db.insert(s.payments).values({ orderId: o1[0].id, provider: "mock_card", status: "succeeded", amountCents: 4310, last4: "4242" });
  await db.insert(s.shipments).values({
    orderId: o1[0].id, carrier: "Aramex Express", trackingNumber: "ZT-5829140037", status: "delivered", eta: "Oct 28 – Nov 15",
    events: [
      { status: "pending", at: daysAgo(25).toISOString(), noteAr: "تم استلام الطلب", noteEn: "Order received" },
      { status: "confirmed", at: daysAgo(24).toISOString(), noteAr: "تم تأكيد الطلب", noteEn: "Order confirmed" },
      { status: "preparing", at: daysAgo(23).toISOString(), noteAr: "جارٍ تجهيز المنتج", noteEn: "Being prepared" },
      { status: "ready", at: daysAgo(21).toISOString(), noteAr: "جاهز للشحن", noteEn: "Ready for shipping" },
      { status: "shipped", at: daysAgo(19).toISOString(), noteAr: "تم الشحن", noteEn: "Shipped" },
      { status: "in_transit", at: daysAgo(16).toISOString(), noteAr: "في الطريق إليك", noteEn: "In transit" },
      { status: "delivered", at: daysAgo(12).toISOString(), noteAr: "تم التسليم", noteEn: "Delivered" },
    ],
  });

  const o2 = await db.insert(s.orders).values({
    orderNumber: `ZT-${year}-000002`, checkoutId: "ZC-DEMO2", userId: 2, sellerId: 2,
    subtotalCents: 4000, discountCents: 0, shippingCents: 1050, totalCents: 5050, currency: "USD",
    status: "in_transit",
    address: { fullName: "Layla Haddad", phone: "+1 202 555 0117", country: "United States", countryCode: "US", state: "DC", city: "Washington", addressLine: "1600 Pennsylvania Ave NW", postalCode: "20500" },
    createdAt: daysAgo(3), updatedAt: daysAgo(1),
  }).returning();
  await db.insert(s.orderItems).values([
    { orderId: o2[0].id, productId: 5, productNameAr: "زعتر بري مطحون مع سمسم — 250غ", productNameEn: "Wild Za'atar Blend with Sesame 250g", priceCents: 1200, quantity: 1, weightGrams: 250, image: px(4871138) },
    { orderId: o2[0].id, productId: 6, productNameAr: "عسل جبلي نقي — 500غ", productNameEn: "Pure Mountain Honey 500g", priceCents: 2800, quantity: 1, weightGrams: 500, image: px(7990484) },
  ]);
  await db.insert(s.payments).values({ orderId: o2[0].id, provider: "mock_card", status: "succeeded", amountCents: 5050, last4: "4242" });
  await db.insert(s.shipments).values({
    orderId: o2[0].id, carrier: "DHL (mock)", trackingNumber: "ZT-7712093456", status: "in_transit", eta: "Nov 20 – Nov 27",
    events: [
      { status: "pending", at: daysAgo(3).toISOString(), noteAr: "تم استلام الطلب", noteEn: "Order received" },
      { status: "confirmed", at: daysAgo(3).toISOString(), noteAr: "تم تأكيد الطلب", noteEn: "Order confirmed" },
      { status: "preparing", at: daysAgo(2).toISOString(), noteAr: "جارٍ تجهيز المنتج", noteEn: "Being prepared" },
      { status: "ready", at: daysAgo(2).toISOString(), noteAr: "جاهز للشحن", noteEn: "Ready for shipping" },
      { status: "shipped", at: daysAgo(1).toISOString(), noteAr: "تم الشحن", noteEn: "Shipped" },
      { status: "in_transit", at: new Date().toISOString(), noteAr: "في الطريق إليك", noteEn: "In transit" },
    ],
  });

  const o3 = await db.insert(s.orders).values({
    orderNumber: `ZT-${year}-000003`, checkoutId: "ZC-DEMO3", userId: 2, sellerId: 3,
    subtotalCents: 1800, discountCents: 0, shippingCents: 980, totalCents: 2780, currency: "USD",
    status: "pending",
    address: { fullName: "Layla Haddad", phone: "+971 50 123 4567", country: "United Arab Emirates", countryCode: "AE", state: "", city: "Dubai", addressLine: "Sheikh Zayed Road 14", postalCode: "0000" },
    createdAt: daysAgo(1), updatedAt: daysAgo(1),
  }).returning();
  await db.insert(s.orderItems).values({ orderId: o3[0].id, productId: 11, productNameAr: "صابون زيتون نابلسي — 200غ", productNameEn: "Nablus Olive Oil Soap 200g", priceCents: 900, quantity: 2, weightGrams: 400, image: px(10155373) });
  await db.insert(s.payments).values({ orderId: o3[0].id, provider: "mock_card", status: "succeeded", amountCents: 2780, last4: "4242" });
  await db.insert(s.shipments).values({
    orderId: o3[0].id, carrier: null, trackingNumber: null, status: "pending", eta: "Nov 24 – Dec 9",
    events: [{ status: "pending", at: daysAgo(1).toISOString(), noteAr: "تم استلام الطلب", noteEn: "Order received" }],
  });

  /* ---------- reviews ---------- */
  const reviews = [
    { productId: 1, userId: 2, orderId: o1[0].id, rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 4, commentAr: "زيت رائع، حار خفيف في الخاتمة وريحة قوية. وصل التغليف ممتاز.", commentEn: "Superb oil — light heat at the finish, strong aroma. Packaging arrived perfect." },
    { productId: 1, userId: 4, rating: 5, qualityRating: 5, packagingRating: 4, shippingRating: 5, commentAr: null, commentEn: "Better than most EU extra virgin oils I've tried. You can taste the freshness." },
    { productId: 1, userId: 6, rating: 4, qualityRating: 5, packagingRating: 4, shippingRating: 4, commentAr: null, commentEn: "Wonderful oil, takes a week or so to arrive. Would buy again." },
    { productId: 5, userId: 2, orderId: o2[0].id, rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 5, commentAr: "ريحة الزعتر قوية جداً ومع الخبز والزيت لا يوصف!", commentEn: "The thyme scent is intense — unbeatable with bread and olive oil!" },
    { productId: 5, userId: 8, rating: 5, qualityRating: 5, packagingRating: 4, shippingRating: 5, commentAr: null, commentEn: "Tastes like my grandmother's. Authentic." },
    { productId: 6, userId: 2, orderId: o2[0].id, rating: 5, qualityRating: 5, packagingRating: 4, shippingRating: 4, commentAr: "عسل صافي وطعمه نضيف.", commentEn: "Clear honey with a clean taste." },
    { productId: 6, userId: 7, rating: 4, qualityRating: 5, packagingRating: 4, shippingRating: 3, commentAr: null, commentEn: "Delicious honey. Shipping could be faster." },
    { productId: 11, userId: 2, orderId: o3[0].id, rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 5, commentAr: "الصابون الأصلي! فوامة نظيفة وريحة خفيفة.", commentEn: "The real Nablus soap! Clean lather, light scent." },
    { productId: 11, userId: 5, rating: 5, qualityRating: 5, packagingRating: 4, shippingRating: 5, commentAr: null, commentEn: "My skin has never been softer. Buying more for gifts." },
    { productId: 11, userId: 6, rating: 4, qualityRating: 5, packagingRating: 4, shippingRating: 4, commentAr: null, commentEn: "Classic. Smells like old Nablus." },
    { productId: 14, userId: 7, rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 4, commentAr: null, commentEn: "Beautiful grain, heavy and solid. Heirloom quality." },
    { productId: 18, userId: 7, rating: 5, qualityRating: 5, packagingRating: 5, shippingRating: 4, commentAr: "أهديته لصديقي وعجب جداً.", commentEn: "Gave it to a friend — she loved every item inside." },
    { productId: 18, userId: 8, rating: 4, qualityRating: 4, packagingRating: 5, shippingRating: 4, commentAr: null, commentEn: "A beautiful introduction to Palestinian products." },
  ];
  await db.insert(s.reviews).values(reviews);

  /* recalc product ratings from active reviews */
  const agg = await db
    .select({
      productId: s.reviews.productId,
      avg: sql<number>`avg(rating)`,
      c: sql<number>`count(*)`,
    })
    .from(s.reviews)
    .where(sql`${s.reviews.status} = 'active'`)
    .groupBy(s.reviews.productId);
  for (const a of agg) {
    await db
      .update(s.products)
      .set({ rating: Number(a.avg).toFixed(1), reviewCount: Number(a.c) })
      .where(sql`${s.products.id} = ${a.productId}`);
  }

  /* ---------- favorites ---------- */
  await db.insert(s.favorites).values([
    { userId: 2, productId: 1 },
    { userId: 2, productId: 6 },
    { userId: 2, productId: 16 },
  ]);

  /* ---------- conversation + messages ---------- */
  const conv = await db.insert(s.conversations).values({ buyerId: 2, sellerId: 1 }).returning();
  await db.insert(s.messages).values([
    { conversationId: conv[0].id, senderId: 2, body: "Hi Abu Ahmad! Will the new 2026 harvest oil be available soon?" },
    { conversationId: conv[0].id, senderId: 3, body: "Ahla Layla! Yes — pressing starts the first week of November. I'll keep you posted. 💚" },
    { conversationId: conv[0].id, senderId: 2, body: "Amazing, thank you! Does the new oil ship to the US in time for holidays?" },
    { conversationId: conv[0].id, senderId: 3, body: "Yes, standard shipping to the US takes 7–14 days. I can pack it with bubble wrap like last time." },
  ]);

  /* ---------- applications ---------- */
  await db.insert(s.sellerApplications).values([
    { userId: 3, shopName: "Old Olive Farm | مزرعة الزيتون القديم", city: "Jenin", region: "North West Bank", about: "Family olive farm", productTypes: ["Olive oil & olives"], status: "approved", reviewedAt: daysAgo(700) },
    { userId: 7, shopName: "Dabbas Family Jam | مربى عائلة الدباس", city: "Hebron", region: "Hebron", about: "Homemade fig and date jams in small batches", productTypes: ["Food", "Honey & natural foods"], status: "pending", createdAt: daysAgo(2) },
    { userId: 8, shopName: "Darwish Pottery", city: "Bethlehem", region: "Bethlehem", about: "Handmade pottery", productTypes: ["Handicrafts"], status: "rejected", note: "Please submit product samples first.", reviewedAt: daysAgo(20) },
  ]);

  /* ---------- notifications ---------- */
  await db.insert(s.notifications).values([
    { userId: 2, type: "order_status", titleAr: "طلبك ZT-000002: في الطريق إليك", titleEn: "Order ZT-000002: in transit", bodyAr: "شحنتك غادرت فلسطين وتتجه إليك.", bodyEn: "Your parcel has left Palestine and is on its way.", link: "/orders", createdAt: daysAgo(1), readAt: null },
    { userId: 2, type: "order_status", titleAr: "طلبك ZT-000003: تم استلام الطلب", titleEn: "Order ZT-000003: received", bodyAr: "سيتواصل معك بيت نور للحرف لتجهيزه.", bodyEn: "Nour's Craft House will prepare your order shortly.", link: "/orders", createdAt: daysAgo(1), readAt: null },
    { userId: 3, type: "new_order", titleAr: "طلب جديد ZT-000001", titleEn: "New order ZT-000001", bodyAr: "زيت زيتون بكر ممتاز ×1 — الولايات المتحدة", bodyEn: "Extra Virgin Olive Oil ×1 — United States", link: "/dashboard/seller?tab=orders", createdAt: daysAgo(25), readAt: daysAgo(24) },
    { userId: 5, type: "new_order", titleAr: "طلب جديد ZT-000003", titleEn: "New order ZT-000003", bodyAr: "صابون زيتون نابلسي ×2 — الإمارات", bodyEn: "Nablus Olive Soap ×2 — United Arab Emirates", link: "/dashboard/seller?tab=orders", createdAt: daysAgo(1), readAt: null },
    { userId: 1, type: "application", titleAr: "طلب بيع جديد: مربى عائلة الدباس", titleEn: "New seller application: Dabbas Family Jam", bodyAr: "Layla Dabbas (layla.demo@gmail.com) تقدّمت للبيع.", bodyEn: "Layla Dabbas (layla.demo@gmail.com) applied to sell.", link: "/dashboard/admin?tab=sellers", createdAt: daysAgo(2), readAt: null },
    { userId: 3, type: "review", titleAr: "تقييم جديد (5★) على زيت زيتون بكر ممتاز", titleEn: "New 5-star review on Extra Virgin Olive Oil", bodyAr: "زيت رائع، حار خفيف في الخاتمة...", bodyEn: "Superb oil — light heat at the finish...", link: "/dashboard/seller?tab=products", createdAt: daysAgo(10), readAt: daysAgo(9) },
  ]);

  /* ---------- reports ---------- */
  await db.insert(s.reports).values([
    { targetType: "user", targetId: 8, reporterId: 2, reason: "Demo report: account suspected of spam messages.", status: "open", createdAt: daysAgo(4) },
  ]);

  /* ---------- shipping address for demo customer ---------- */
  await db.insert(s.shippingAddresses).values({
    userId: 2, label: "Home", fullName: "Layla Haddad", phone: "+1 202 555 0117",
    country: "United States", countryCode: "US", state: "DC", city: "Washington",
    addressLine: "1600 Pennsylvania Ave NW", postalCode: "20500", isDefault: true,
  });

  /* keep serial sequences in sync after explicit-id inserts */
  const seqTables = [
    "users", "sellers", "seller_applications", "categories", "products", "orders",
    "order_items", "payments", "shipments", "reviews", "favorites", "conversations",
    "messages", "notifications", "reports", "password_resets", "shipping_addresses",
    "offers", "countries", "currencies", "shipping_methods", "site_content",
  ];
  for (const t of seqTables) {
    await pool.query(`SELECT setval(pg_get_serial_sequence('${t}', 'id'), COALESCE((SELECT max(id) FROM ${t}), 0) + 1, false)`);
  }

  console.log("✅ Seed complete.");
  console.log("   admin    → admin@zeitoun.app / admin123");
  console.log("   customer → customer@zeitoun.app / demo123");
  console.log("   seller   → seller@zeitoun.app / demo123");
  console.log("   (demo)   → nadia/omar/sara@zeitoun.app / demo123");
  await pool.end();
}

main().catch(async (e) => {
  console.error("❌ Seed failed:", e);
  process.exit(1);
});
