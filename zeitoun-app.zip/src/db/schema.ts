import {
  pgTable,
  pgEnum,
  serial,
  varchar,
  text,
  boolean,
  integer,
  numeric,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ---------------- Enums ---------------- */

export const userRoleEnum = pgEnum("user_role", ["customer", "seller", "admin"]);
export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "shipped",
  "in_transit",
  "delivered",
  "cancelled",
  "refunded",
]);
export const applicationStatusEnum = pgEnum("application_status", ["pending", "approved", "rejected"]);
export const sellerStatusEnum = pgEnum("seller_status", ["active", "suspended"]);
export const productStatusEnum = pgEnum("product_status", ["pending", "active", "rejected", "archived"]);
export const reviewStatusEnum = pgEnum("review_status", ["active", "removed"]);
export const reportStatusEnum = pgEnum("report_status", ["open", "resolved", "dismissed"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "succeeded", "failed"]);
export const offerTypeEnum = pgEnum("offer_type", ["percent", "fixed"]);

/* ---------------- Users & Auth ---------------- */

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 160 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 200 }).notNull(),
  role: userRoleEnum("role").notNull().default("customer"),
  phone: varchar("phone", { length: 40 }),
  emailVerified: boolean("email_verified").notNull().default(true),
  suspended: boolean("suspended").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  code: varchar("code", { length: 10 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
});

/* ---------------- Sellers ---------------- */

export const sellers = pgTable("sellers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique().references(() => users.id),
  shopName: varchar("shop_name", { length: 140 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  region: varchar("region", { length: 120 }),
  city: varchar("city", { length: 120 }),
  about: text("about"),
  story: text("story"),
  images: text("images").array().notNull().default([]),
  allowMessages: boolean("allow_messages").notNull().default(true),
  rating: numeric("rating", { precision: 3, scale: 1 }).notNull().default("0"),
  orderCount: integer("order_count").notNull().default(0),
  status: sellerStatusEnum("status").notNull().default("active"),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const sellerApplications = pgTable("seller_applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  shopName: varchar("shop_name", { length: 140 }).notNull(),
  city: varchar("city", { length: 120 }),
  region: varchar("region", { length: 120 }),
  about: text("about"),
  productTypes: text("product_types").array().notNull().default([]),
  status: applicationStatusEnum("status").notNull().default("pending"),
  note: text("note"),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------------- Catalog ---------------- */

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  nameAr: varchar("name_ar", { length: 120 }).notNull(),
  nameEn: varchar("name_en", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  icon: varchar("icon", { length: 10 }).notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    sellerId: integer("seller_id").notNull().references(() => sellers.id),
    categoryId: integer("category_id").notNull().references(() => categories.id),
    nameAr: varchar("name_ar", { length: 200 }).notNull(),
    nameEn: varchar("name_en", { length: 200 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    descriptionAr: text("description_ar"),
    descriptionEn: text("description_en"),
    priceCents: integer("price_cents").notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("USD"),
    stock: integer("stock").notNull().default(0),
    weightGrams: integer("weight_grams").notNull().default(500),
    dimensions: varchar("dimensions", { length: 80 }),
    originRegion: varchar("origin_region", { length: 120 }),
    images: text("images").array().notNull().default([]),
    videoUrl: text("video_url"),
    productionMethodAr: text("production_method_ar"),
    productionMethodEn: text("production_method_en"),
    ingredientsAr: text("ingredients_ar"),
    ingredientsEn: text("ingredients_en"),
    usageAr: text("usage_ar"),
    usageEn: text("usage_en"),
    allergensAr: text("allergens_ar"),
    allergensEn: text("allergens_en"),
    storyAr: text("story_ar"),
    storyEn: text("story_en"),
    storyImages: text("story_images").array().notNull().default([]),
    harvestSeason: varchar("harvest_season", { length: 80 }),
    rating: numeric("rating", { precision: 3, scale: 1 }).notNull().default("0"),
    reviewCount: integer("review_count").notNull().default(0),
    salesCount: integer("sales_count").notNull().default(0),
    isFeatured: boolean("is_featured").notNull().default(false),
    shipsInternational: boolean("ships_international").notNull().default(true),
    status: productStatusEnum("status").notNull().default("pending"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("products_seller_idx").on(t.sellerId),
    index("products_category_idx").on(t.categoryId),
    index("products_status_idx").on(t.status),
    uniqueIndex("products_slug_idx").on(t.slug),
  ],
);

/* ---------------- Commerce ---------------- */

export const shippingAddresses = pgTable(
  "shipping_addresses",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id),
    label: varchar("label", { length: 60 }).notNull().default("Home"),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 40 }).notNull(),
    country: varchar("country", { length: 80 }).notNull(),
    countryCode: varchar("country_code", { length: 8 }).notNull(),
    state: varchar("state", { length: 80 }),
    city: varchar("city", { length: 80 }).notNull(),
    addressLine: varchar("address_line", { length: 200 }).notNull(),
    postalCode: varchar("postal_code", { length: 20 }).notNull(),
    isDefault: boolean("is_default").notNull().default(false),
  },
  (t) => [index("addresses_user_idx").on(t.userId)],
);

export const orderTypeEnum = pgEnum("order_type", [
  "PRODUCT_ORDER",
  "ADOPTION_ORDER",
  "ADOPTION_AND_PRODUCT_ORDER",
]);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: varchar("order_number", { length: 30 }).notNull().unique(),
    checkoutId: varchar("checkout_id", { length: 40 }),
    orderType: orderTypeEnum("order_type").notNull().default("PRODUCT_ORDER"),
    userId: integer("user_id").notNull().references(() => users.id),
    sellerId: integer("seller_id").notNull().references(() => sellers.id),
    subtotalCents: integer("subtotal_cents").notNull(),
    discountCents: integer("discount_cents").notNull().default(0),
    shippingCents: integer("shipping_cents").notNull().default(0),
    totalCents: integer("total_cents").notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("USD"),
    status: orderStatusEnum("status").notNull().default("pending"),
    address: jsonb("address").notNull(),
    note: text("note"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("orders_user_idx").on(t.userId),
    index("orders_seller_idx").on(t.sellerId),
    index("orders_status_idx").on(t.status),
  ],
);

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  productId: integer("product_id").notNull().references(() => products.id),
  productNameAr: varchar("product_name_ar", { length: 200 }).notNull(),
  productNameEn: varchar("product_name_en", { length: 200 }).notNull(),
  priceCents: integer("price_cents").notNull(),
  quantity: integer("quantity").notNull(),
  weightGrams: integer("weight_grams").notNull().default(0),
  image: text("image"),
});

export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().unique().references(() => orders.id),
  carrier: varchar("carrier", { length: 60 }),
  trackingNumber: varchar("tracking_number", { length: 60 }),
  status: varchar("status", { length: 30 }).notNull().default("pending"),
  eta: varchar("eta", { length: 60 }),
  events: jsonb("events").notNull().default([]),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().unique().references(() => orders.id),
  provider: varchar("provider", { length: 40 }).notNull().default("mock"),
  status: paymentStatusEnum("status").notNull().default("pending"),
  amountCents: integer("amount_cents").notNull(),
  last4: varchar("last4", { length: 4 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull().references(() => products.id),
    userId: integer("user_id").notNull().references(() => users.id),
    orderId: integer("order_id"),
    rating: integer("rating").notNull(),
    qualityRating: integer("quality_rating").notNull().default(5),
    packagingRating: integer("packaging_rating").notNull().default(5),
    shippingRating: integer("shipping_rating").notNull().default(5),
    commentAr: text("comment_ar"),
    commentEn: text("comment_en"),
    status: reviewStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("reviews_product_idx").on(t.productId), index("reviews_user_idx").on(t.userId)],
);

export const favorites = pgTable(
  "favorites",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id),
    productId: integer("product_id").notNull().references(() => products.id),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("favorites_user_product_idx").on(t.userId, t.productId)],
);

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  type: offerTypeEnum("type").notNull().default("percent"),
  value: integer("value").notNull(),
  minSubtotalCents: integer("min_subtotal_cents").notNull().default(0),
  active: boolean("active").notNull().default(true),
  expiresAt: timestamp("expires_at"),
  usageCount: integer("usage_count").notNull().default(0),
});

/* ---------------- Platform ---------------- */

export const countries = pgTable("countries", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  nameAr: varchar("name_ar", { length: 120 }).notNull(),
  nameEn: varchar("name_en", { length: 120 }).notNull(),
  region: varchar("region", { length: 40 }).notNull().default("global"),
  surchargeCents: integer("surcharge_cents").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const currencies = pgTable("currencies", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  nameAr: varchar("name_ar", { length: 120 }).notNull(),
  nameEn: varchar("name_en", { length: 120 }).notNull(),
  symbol: varchar("symbol", { length: 6 }).notNull().default("$"),
  ratePerUsd: numeric("rate_per_usd", { precision: 12, scale: 4 }).notNull().default("1"),
  active: boolean("active").notNull().default(true),
});

export const shippingMethods = pgTable("shipping_methods", {
  id: serial("id").primaryKey(),
  nameAr: varchar("name_ar", { length: 120 }).notNull(),
  nameEn: varchar("name_en", { length: 120 }).notNull(),
  daysMin: integer("days_min").notNull().default(7),
  daysMax: integer("days_max").notNull().default(14),
  baseCents: integer("base_cents").notNull().default(900),
  perKgCents: integer("per_kg_cents").notNull().default(400),
  active: boolean("active").notNull().default(true),
});

export const conversations = pgTable(
  "conversations",
  {
    id: serial("id").primaryKey(),
    buyerId: integer("buyer_id").notNull().references(() => users.id),
    sellerId: integer("seller_id").notNull().references(() => sellers.id),
    productId: integer("product_id"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("conv_buyer_idx").on(t.buyerId), index("conv_seller_idx").on(t.sellerId)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id").notNull().references(() => conversations.id),
    senderId: integer("sender_id").notNull().references(() => users.id),
    body: text("body").notNull(),
    readAt: timestamp("read_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("messages_conv_idx").on(t.conversationId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id),
    type: varchar("type", { length: 40 }).notNull().default("info"),
    titleAr: varchar("title_ar", { length: 200 }).notNull(),
    titleEn: varchar("title_en", { length: 200 }).notNull(),
    bodyAr: text("body_ar"),
    bodyEn: text("body_en"),
    link: text("link"),
    readAt: timestamp("read_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("notif_user_idx").on(t.userId)],
);

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  targetType: varchar("target_type", { length: 20 }).notNull(),
  targetId: integer("target_id").notNull(),
  reporterId: integer("reporter_id").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  status: reportStatusEnum("status").notNull().default("open"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const siteContent = pgTable("site_content", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 60 }).notNull().unique(),
  value: jsonb("value").notNull(),
});

/* ================= Adopt a Tree / Adopt a Farmer ================= */

/** Public tree lifecycle status. */
export const treeStatusEnum = pgEnum("tree_status", [
  "available",
  "reserved",
  "adopted",
  "inactive",
  "under_review",
]);

/** Adoption (sponsorship) lifecycle status. */
export const adoptionStatusEnum = pgEnum("adoption_status", [
  "pending",
  "active",
  "paused",
  "completed",
  "expired",
  "renewed",
  "cancelled",
]);

/** What a program sponsors: a specific tree, a farmer, or both. */
export const programKindEnum = pgEnum("program_kind", ["tree", "farmer", "both"]);

/* ---------- Farmers (public-facing profile, linked to a seller account) ---------- */

export const farmers = pgTable(
  "farmers",
  {
    id: serial("id").primaryKey(),
    sellerId: integer("seller_id").unique().references(() => sellers.id),
    nameAr: varchar("name_ar", { length: 140 }).notNull(),
    nameEn: varchar("name_en", { length: 140 }).notNull(),
    slug: varchar("slug", { length: 160 }).notNull().unique(),
    farmNameAr: varchar("farm_name_ar", { length: 160 }),
    farmNameEn: varchar("farm_name_en", { length: 160 }),
    /** Only region/village is public — never exact GPS or home address. */
    region: varchar("region", { length: 120 }),
    city: varchar("city", { length: 120 }),
    yearsFarming: integer("years_farming").notNull().default(0),
    storyAr: text("story_ar"),
    storyEn: text("story_en"),
    aboutAr: text("about_ar"),
    aboutEn: text("about_en"),
    images: text("images").array().notNull().default([]),
    videoUrl: text("video_url"),
    rating: numeric("rating", { precision: 3, scale: 1 }).notNull().default("0"),
    treeCount: integer("tree_count").notNull().default(0),
    sponsorCount: integer("sponsor_count").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("farmers_seller_idx").on(t.sellerId)],
);

/* ---------- Olive trees ---------- */

export const oliveTrees = pgTable(
  "olive_trees",
  {
    id: serial("id").primaryKey(),
    farmerId: integer("farmer_id").notNull().references(() => farmers.id),
    /** Public unique identifier, e.g. ZT-TREE-000127 */
    treeCode: varchar("tree_code", { length: 30 }).notNull().unique(),
    nameAr: varchar("name_ar", { length: 140 }),
    nameEn: varchar("name_en", { length: 140 }),
    treeNumber: integer("tree_number"),
    approximateAge: integer("approximate_age").notNull().default(0),
    oliveVariety: varchar("olive_variety", { length: 80 }),
    /** General region/village only — privacy by design. */
    region: varchar("region", { length: 120 }),
    storyAr: text("story_ar"),
    storyEn: text("story_en"),
    images: text("images").array().notNull().default([]),
    farmImages: text("farm_images").array().notNull().default([]),
    status: treeStatusEnum("status").notNull().default("under_review"),
    /** "Zeitoun Verified Tree" badge — only after admin verification. */
    verified: boolean("verified").notNull().default(false),
    verifiedAt: timestamp("verified_at"),
    season: varchar("season", { length: 20 }).notNull().default("2026"),
    /** Current agricultural phase key (see ADOPTION_PHASES). */
    phase: varchar("phase", { length: 30 }).notNull().default("season_start"),
    progressPercent: integer("progress_percent").notNull().default(0),
    maxSponsors: integer("max_sponsors").notNull().default(1),
    sponsorCount: integer("sponsor_count").notNull().default(0),
    programStartsAt: timestamp("program_starts_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("trees_farmer_idx").on(t.farmerId), index("trees_status_idx").on(t.status)],
);

export const treeImages = pgTable("tree_images", {
  id: serial("id").primaryKey(),
  treeId: integer("tree_id").notNull().references(() => oliveTrees.id),
  url: text("url").notNull(),
  captionAr: varchar("caption_ar", { length: 160 }),
  captionEn: varchar("caption_en", { length: 160 }),
  sortOrder: integer("sort_order").notNull().default(0),
});

/* ---------- Seasons per tree ---------- */

export const treeSeasons = pgTable(
  "tree_seasons",
  {
    id: serial("id").primaryKey(),
    treeId: integer("tree_id").notNull().references(() => oliveTrees.id),
    season: varchar("season", { length: 20 }).notNull(),
    phase: varchar("phase", { length: 30 }).notNull().default("season_start"),
    progressPercent: integer("progress_percent").notNull().default(0),
    startedAt: timestamp("started_at").notNull().defaultNow(),
    endedAt: timestamp("ended_at"),
    notesAr: text("notes_ar"),
    notesEn: text("notes_en"),
  },
  (t) => [index("seasons_tree_idx").on(t.treeId)],
);

/* ---------- Adoption programs (admin-managed commercial offers) ---------- */

export const adoptionPrograms = pgTable("adoption_programs", {
  id: serial("id").primaryKey(),
  nameAr: varchar("name_ar", { length: 160 }).notNull(),
  nameEn: varchar("name_en", { length: 160 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  kind: programKindEnum("kind").notNull().default("tree"),
  priceCents: integer("price_cents").notNull().default(12000),
  renewalPriceCents: integer("renewal_price_cents").notNull().default(10000),
  durationDays: integer("duration_days").notNull().default(365),
  /** [{ ar, en }] list of what the sponsor receives. */
  benefits: jsonb("benefits").notNull().default([]),
  /** [{ labelAr, labelEn, qty, productId? }] included products at harvest. */
  includedProducts: jsonb("included_products").notNull().default([]),
  shippingIncluded: boolean("shipping_included").notNull().default(false),
  maxSponsorsPerTree: integer("max_sponsors_per_tree").notNull().default(1),
  giftEnabled: boolean("gift_enabled").notNull().default(true),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

/* ---------- Which programs a farmer may participate in ---------- */

export const farmerSupportPrograms = pgTable(
  "farmer_support_programs",
  {
    id: serial("id").primaryKey(),
    farmerId: integer("farmer_id").notNull().references(() => farmers.id),
    programId: integer("program_id").notNull().references(() => adoptionPrograms.id),
    allowed: boolean("allowed").notNull().default(true),
    /** Admin decides whether the farmer may override the program price. */
    allowPriceOverride: boolean("allow_price_override").notNull().default(false),
    customPriceCents: integer("custom_price_cents"),
    slots: integer("slots").notNull().default(10),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("fsp_farmer_idx").on(t.farmerId)],
);

/* ---------- Adoptions (sponsorships) ---------- */

export const adoptions = pgTable(
  "adoptions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id),
    /** null when sponsoring a farmer without a specific tree */
    treeId: integer("tree_id").references(() => oliveTrees.id),
    farmerId: integer("farmer_id").notNull().references(() => farmers.id),
    programId: integer("program_id").notNull().references(() => adoptionPrograms.id),
    seasonId: integer("season_id").references(() => treeSeasons.id),
    orderNumber: varchar("order_number", { length: 30 }),
    certificateCode: varchar("certificate_code", { length: 40 }),
    /** Sponsor-chosen display name for the tree ("شجرتي نور"). */
    displayName: varchar("display_name", { length: 120 }),
    renameCount: integer("rename_count").notNull().default(0),
    status: adoptionStatusEnum("status").notNull().default("pending"),
    isGift: boolean("is_gift").notNull().default(false),
    giftRecipientName: varchar("gift_recipient_name", { length: 120 }),
    giftMessage: text("gift_message"),
    giftOccasion: varchar("gift_occasion", { length: 40 }),
    giftSendAt: timestamp("gift_send_at"),
    startDate: timestamp("start_date").notNull().defaultNow(),
    endDate: timestamp("end_date"),
    renewedFromId: integer("renewed_from_id"),
    priceCents: integer("price_cents").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("adoptions_user_idx").on(t.userId),
    index("adoptions_tree_idx").on(t.treeId),
    index("adoptions_status_idx").on(t.status),
  ],
);

/* ---------- Farmer / admin updates to sponsors ---------- */

export const adoptionUpdates = pgTable(
  "adoption_updates",
  {
    id: serial("id").primaryKey(),
    farmerId: integer("farmer_id").notNull().references(() => farmers.id),
    treeId: integer("tree_id").references(() => oliveTrees.id),
    titleAr: varchar("title_ar", { length: 200 }).notNull(),
    titleEn: varchar("title_en", { length: 200 }).notNull(),
    bodyAr: text("body_ar"),
    bodyEn: text("body_en"),
    image: text("image"),
    video: text("video"),
    phase: varchar("phase", { length: 30 }),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("updates_farmer_idx").on(t.farmerId), index("updates_tree_idx").on(t.treeId)],
);

/* ---------- Digital certificates ---------- */

export const adoptionCertificates = pgTable("adoption_certificates", {
  id: serial("id").primaryKey(),
  adoptionId: integer("adoption_id").notNull().references(() => adoptions.id),
  code: varchar("code", { length: 40 }).notNull().unique(),
  qrDataUrl: text("qr_data_url"),
  sponsorName: varchar("sponsor_name", { length: 140 }).notNull(),
  treeName: varchar("tree_name", { length: 140 }),
  treeCode: varchar("tree_code", { length: 30 }),
  farmerName: varchar("farmer_name", { length: 140 }).notNull(),
  farmName: varchar("farm_name", { length: 160 }),
  region: varchar("region", { length: 120 }),
  season: varchar("season", { length: 20 }),
  startDate: timestamp("start_date").notNull(),
  issuedAt: timestamp("issued_at").notNull().defaultNow(),
});

/* ---------- Gift options ---------- */

export const adoptionGifts = pgTable("adoption_gifts", {
  id: serial("id").primaryKey(),
  adoptionId: integer("adoption_id").notNull().references(() => adoptions.id),
  recipientName: varchar("recipient_name", { length: 120 }).notNull(),
  message: text("message"),
  occasion: varchar("occasion", { length: 40 }),
  sendAt: timestamp("send_at"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------- Adoption orders (link to the existing order system) ---------- */

export const adoptionOrders = pgTable("adoption_orders", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().unique().references(() => orders.id),
  adoptionId: integer("adoption_id").notNull().references(() => adoptions.id),
  programId: integer("program_id").notNull().references(() => adoptionPrograms.id),
  treeId: integer("tree_id").references(() => oliveTrees.id),
  amountCents: integer("amount_cents").notNull(),
  isRenewal: boolean("is_renewal").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------- Admin-managed gift occasions ---------- */

export const giftOccasions = pgTable("gift_occasions", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 40 }).notNull().unique(),
  nameAr: varchar("name_ar", { length: 80 }).notNull(),
  nameEn: varchar("name_en", { length: 80 }).notNull(),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});
