import type { Lang, Localized } from "./types";

/** Pick a localized string, falling back to the other language. */
export function d(v: Localized | string | null | undefined, lang: Lang): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  const v2 = lang === "ar" ? v.ar : v.en;
  return v2 || (lang === "ar" ? v.en : v.ar) || "";
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 100) || "item";
}

export function fmtMoney(cents: number, rate: number, symbol: string): string {
  const v = (cents / 100) * rate;
  return `${symbol}${v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtNum(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

export function timeAgo(iso: string, lang: Lang): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  const ar =
    min < 1
      ? "الآن"
      : min < 60
        ? `منذ ${min} دقيقة`
        : min < 1440
          ? `منذ ${Math.floor(min / 60)} ساعة`
          : `منذ ${Math.floor(min / 1440)} يوم`;
  const en =
    min < 1
      ? "just now"
      : min < 60
        ? `${min}m ago`
        : min < 1440
          ? `${Math.floor(min / 60)}h ago`
          : `${Math.floor(min / 1440)}d ago`;
  return lang === "ar" ? ar : en;
}

export function fmtDate(iso: string, lang: Lang): string {
  return new Date(iso).toLocaleDateString(lang === "ar" ? "ar" : "en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/* ---------- Validation helpers ---------- */

export function vStr(v: unknown, max: number): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}
export function vInt(v: unknown, min = 0, max = 1_000_000_000): number {
  const n = typeof v === "number" ? Math.floor(v) : parseInt(String(v ?? ""), 10);
  if (Number.isNaN(n)) return min;
  return Math.min(max, Math.max(min, n));
}
export function vEmail(v: unknown): string | null {
  const s = vStr(v, 160).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s) ? s : null;
}
export function vUrls(v: unknown, max = 12): string[] {
  if (!Array.isArray(v)) return [];
  return v
    .filter((x) => typeof x === "string" && /^https?:\/\/[^\s]+\.(jpe?g|png|webp|gif|mp4|mov|heic)/i.test(x))
    .slice(0, max);
}
export function vUrlsAny(v: unknown, max = 12): string[] {
  if (!Array.isArray(v)) return [];
  return v.filter((x) => typeof x === "string" && /^https?:\/\//i.test(x)).slice(0, max);
}

/* ---------- Lightweight in-memory rate limiter ---------- */

const buckets = new Map<string, { count: number; reset: number }>();

export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || now > b.reset) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  b.count += 1;
  return b.count <= limit;
}

/* ---------- Shipping quote (mock provider, DB-driven rates) ---------- */

export interface ShippingQuoteInput {
  baseCents: number;
  perKgCents: number;
  surchargeCents: number;
  weightGrams: number;
  daysMin: number;
  daysMax: number;
}

export function quoteShipping(q: ShippingQuoteInput): number {
  const kg = Math.max(0.5, q.weightGrams / 1000);
  return Math.round(q.baseCents + q.perKgCents * kg + q.surchargeCents);
}

export function etaRange(daysMin: number, daysMax: number, lang: Lang): string {
  const f = (d: number) =>
    new Date(Date.now() + d * 86400000).toLocaleDateString(lang === "ar" ? "ar" : "en-US", {
      month: "short",
      day: "numeric",
    });
  return `${f(daysMin)} – ${f(daysMax)}`;
}

/* ---------- Mock providers (replace with real integrations) ---------- */

/**
 * Exchange rate provider stub.
 * To enable live rates, implement this to call an external FX API
 * (e.g. exchangerate-api) and persist into the `currencies` table.
 */
export async function fetchExternalRates(): Promise<Record<string, number> | null> {
  // const url = `https://api.example.com/rates?key=${process.env.FX_API_KEY}`;
  // const r = await fetch(url); return r.ok ? await r.json() : null;
  return null;
}

/**
 * Carrier provider stub.
 * Structure ready to be swapped for DHL / Aramex / FedEx / UPS APIs.
 */
export function mockTrackingNumber(): string {
  let n = "";
  for (let i = 0; i < 10; i++) n += Math.floor(Math.random() * 10);
  return `ZT-${n}`;
}

export function mockCarrier(): string {
  const carriers = ["Aramex Express", "DHL (mock)", "FedEx (mock)"];
  return carriers[Math.floor(Math.random() * carriers.length)];
}
