import { SignJWT, jwtVerify } from "jose";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const SECRET = new TextEncoder().encode(process.env.AUTH_SECRET || "zeitoun-dev-secret");
const COOKIE = "zt_session";

export interface SessionUser {
  id: number;
  name: string;
  email: string;
  role: "customer" | "seller" | "admin";
}

export class ApiError extends Error {
  status: number;
  ar: string;
  en: string;
  constructor(status: number, ar: string, en: string) {
    super(en);
    this.status = status;
    this.ar = ar;
    this.en = en;
  }
}

export function errRes(e: unknown) {
  if (e instanceof ApiError) {
    return NextResponse.json({ error: { ar: e.ar, en: e.en } }, { status: e.status });
  }
  console.error(e);
  return NextResponse.json(
    { error: { ar: "حدث خطأ مؤقت. حاول مرة أخرى.", en: "Something went wrong. Please try again." } },
    { status: 500 },
  );
}

export async function signSession(u: SessionUser): Promise<string> {
  return new SignJWT({ name: u.name, email: u.email, role: u.role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(u.id))
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(SECRET);
}

export function setSessionCookie(res: NextResponse, token: string) {
  res.cookies.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export function clearSessionCookie(res: NextResponse) {
  res.cookies.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/** Reads the session from the raw request cookies (works in route handlers). */
export async function getSessionFromCookie(cookieHeader: string | null): Promise<SessionUser | null> {
  if (!cookieHeader) return null;
  const m = cookieHeader.match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  if (!m) return null;
  try {
    const { payload } = await jwtVerify(m[1], SECRET);
    return {
      id: Number(payload.sub),
      name: String(payload.name ?? ""),
      email: String(payload.email ?? ""),
      role: (payload.role as SessionUser["role"]) ?? "customer",
    };
  } catch {
    return null;
  }
}

/** Fresh user row (role/suspended may have changed). Throws 401 if invalid. */
export async function requireUser(req: Request): Promise<SessionUser> {
  const s = await getSessionFromCookie(req.headers.get("cookie"));
  if (!s) throw new ApiError(401, "يجب تسجيل الدخول أولاً", "Please sign in first");
  const rows = await db.select().from(users).where(eq(users.id, s.id));
  const u = rows[0];
  if (!u) throw new ApiError(401, "حساب غير صالح", "Invalid session");
  if (u.suspended) throw new ApiError(403, "هذا الحساب موقوف", "This account is suspended");
  return { id: u.id, name: u.name, email: u.email, role: u.role };
}

export function requireRole(user: SessionUser, roles: SessionUser["role"][]): void {
  if (!roles.includes(user.role)) {
    throw new ApiError(403, "لا تملك صلاحية لهذا الإجراء", "You don't have permission for this action");
  }
}

export function clientIp(req: Request): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
}
