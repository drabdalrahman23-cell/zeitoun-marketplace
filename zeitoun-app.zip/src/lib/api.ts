import type { Lang } from "./types";

export class ApiClientError extends Error {
  ar: string;
  en: string;
  status: number;
  constructor(ar: string, en: string, status = 400) {
    super(en);
    this.ar = ar;
    this.en = en;
    this.status = status;
  }
}

export function errMsg(e: unknown, lang: Lang): string {
  if (e instanceof ApiClientError) return lang === "ar" ? e.ar : e.en;
  if (e instanceof Error) return e.message;
  return "Error";
}

export async function api<T = any>(
  path: string,
  opts: { method?: string; body?: unknown; headers?: Record<string, string> } = {},
): Promise<T> {
  const res = await fetch(path, {
    method: opts.method ?? (opts.body !== undefined ? "POST" : "GET"),
    headers: { "Content-Type": "application/json", ...(opts.headers ?? {}) },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    cache: "no-store",
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = (data?.error ?? {}) as { ar?: string; en?: string };
    throw new ApiClientError(
      err.ar ?? err.en ?? "Something went wrong",
      err.en ?? err.ar ?? "Something went wrong",
      res.status,
    );
  }
  return data as T;
}
