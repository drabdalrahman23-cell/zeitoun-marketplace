export type Lang = "ar" | "en";
export type Localized = { ar: string | null; en: string | null };

export interface CategoryView {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  sortOrder: number;
}

export interface SellerView {
  id: number;
  slug: string;
  shopName: string;
  region: string | null;
  city: string | null;
  about: string | null;
  story: string | null;
  images: string[];
  allowMessages: boolean;
  rating: number;
  orderCount: number;
  joinedAt: string;
}

export interface ProductView {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  priceCents: number;
  currency: string;
  images: string[];
  rating: number;
  reviewCount: number;
  salesCount: number;
  stock: number;
  weightGrams: number;
  originRegion: string | null;
  category: CategoryView;
  seller: SellerView;
  isFeatured: boolean;
  shipsInternational: boolean;
  status: string;
  createdAt: string;
}

export interface ProductFull extends ProductView {
  descriptionAr: string | null;
  descriptionEn: string | null;
  dimensions: string | null;
  videoUrl: string | null;
  productionMethodAr: string | null;
  productionMethodEn: string | null;
  ingredientsAr: string | null;
  ingredientsEn: string | null;
  usageAr: string | null;
  usageEn: string | null;
  allergensAr: string | null;
  allergensEn: string | null;
  storyAr: string | null;
  storyEn: string | null;
  storyImages: string[];
  harvestSeason: string | null;
}

export interface ReviewView {
  id: number;
  userName: string;
  rating: number;
  qualityRating: number;
  packagingRating: number;
  shippingRating: number;
  commentAr: string | null;
  commentEn: string | null;
  createdAt: string;
}

export interface OrderView {
  id: number;
  orderNumber: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  subtotalCents: number;
  discountCents: number;
  shippingCents: number;
  totalCents: number;
  currency: string;
  itemCount: number;
  firstItemNameAr: string | null;
  firstItemNameEn: string | null;
  seller: SellerView | null;
  address: Record<string, string>;
  note: string | null;
}

export interface OrderItemView {
  id: number;
  productId: number;
  productSlug: string | null;
  productNameAr: string;
  productNameEn: string;
  priceCents: number;
  quantity: number;
  image: string | null;
}

export interface ShipmentView {
  carrier: string | null;
  trackingNumber: string | null;
  status: string;
  eta: string | null;
  events: { status: string; at: string; noteAr?: string; noteEn?: string }[];
}

export interface ConversationView {
  id: number;
  sellerId: number;
  shopName: string;
  buyerName: string;
  lastBody: string | null;
  lastAt: string | null;
  unread: number;
  productId: number | null;
}

export interface MessageView {
  id: number;
  conversationId: number;
  senderId: number;
  body: string;
  createdAt: string;
}

export interface NotificationView {
  id: number;
  type: string;
  titleAr: string;
  titleEn: string;
  bodyAr: string | null;
  bodyEn: string | null;
  link: string | null;
  createdAt: string;
  readAt: string | null;
}

export interface CurrencyView {
  code: string;
  nameAr: string;
  nameEn: string;
  symbol: string;
  ratePerUsd: number;
}

export interface CountryView {
  code: string;
  nameAr: string;
  nameEn: string;
  region: string;
  surchargeCents: number;
  active: boolean;
}

export const ORDER_FLOW = [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "shipped",
  "in_transit",
  "delivered",
] as const;

export const SELLER_ALLOWED_NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["ready"],
  ready: ["shipped"],
  shipped: ["in_transit"],
  in_transit: ["delivered"],
  delivered: ["refunded"],
  cancelled: [],
  refunded: [],
};
