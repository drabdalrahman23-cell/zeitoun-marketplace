/**
 * Client-safe adoption domain types + phase helpers.
 * (No DB imports here — safe to use inside "use client" components.)
 */

/** Ordered agricultural phases of an olive season. */
export const ADOPTION_PHASES = [
  "season_start",
  "growth",
  "flowering",
  "fruiting",
  "ripening",
  "harvest",
  "pressing",
  "packing",
  "delivered",
] as const;

export type AdoptionPhase = (typeof ADOPTION_PHASES)[number];

export function phaseIndex(phase: string): number {
  const i = ADOPTION_PHASES.indexOf(phase as AdoptionPhase);
  return i < 0 ? 0 : i;
}

/** Deterministic progress % for a phase (used when no explicit value is set). */
export function phaseProgress(phase: string): number {
  return Math.round(((phaseIndex(phase) + 1) / ADOPTION_PHASES.length) * 100);
}

export interface FarmerMini {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  farmNameAr: string | null;
  farmNameEn: string | null;
  region: string | null;
  city: string | null;
  yearsFarming: number;
  rating: number;
  treeCount: number;
  sponsorCount: number;
  images: string[];
  availableTrees?: number;
}

export interface FarmerFull extends FarmerMini {
  storyAr: string | null;
  storyEn: string | null;
  aboutAr: string | null;
  aboutEn: string | null;
  videoUrl: string | null;
  sellerId: number | null;
  active: boolean;
}

export interface TreeView {
  id: number;
  treeCode: string;
  nameAr: string | null;
  nameEn: string | null;
  treeNumber: number | null;
  approximateAge: number;
  oliveVariety: string | null;
  region: string | null;
  images: string[];
  status: string;
  verified: boolean;
  season: string;
  phase: string;
  progressPercent: number;
  maxSponsors: number;
  sponsorCount: number;
  farmer: FarmerMini;
}

export interface TreeFull extends TreeView {
  storyAr: string | null;
  storyEn: string | null;
  farmImages: string[];
  programStartsAt: string | null;
  createdAt: string;
}

export interface ProgramBenefit {
  ar: string;
  en: string;
}

export interface ProgramProduct {
  labelAr: string;
  labelEn: string;
  qty: number;
  productId?: number | null;
}

export interface ProgramView {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string | null;
  descriptionEn: string | null;
  kind: string;
  priceCents: number;
  renewalPriceCents: number;
  durationDays: number;
  benefits: ProgramBenefit[];
  includedProducts: ProgramProduct[];
  shippingIncluded: boolean;
  maxSponsorsPerTree: number;
  giftEnabled: boolean;
  active: boolean;
  /** farmer-specific override, when the admin allowed it */
  allowPriceOverride?: boolean;
  customPriceCents?: number | null;
  slots?: number;
  allowed?: boolean;
  fspId?: number;
}

export interface UpdateView {
  id: number;
  treeId: number | null;
  treeCode: string | null;
  farmerId: number;
  titleAr: string;
  titleEn: string;
  bodyAr: string | null;
  bodyEn: string | null;
  image: string | null;
  video: string | null;
  phase: string | null;
  createdAt: string;
  farmerNameAr?: string;
  farmerNameEn?: string;
  treeNameAr?: string | null;
  treeNameEn?: string | null;
}

export interface AdoptionView {
  id: number;
  status: string;
  displayName: string | null;
  renameCount: number;
  orderNumber: string | null;
  certificateCode: string | null;
  startDate: string;
  endDate: string | null;
  priceCents: number;
  isGift: boolean;
  giftRecipientName: string | null;
  giftMessage: string | null;
  giftOccasion: string | null;
  renewedFromId: number | null;
  program: ProgramView | null;
  tree: TreeView | null;
  farmer: FarmerMini;
  lastUpdate: UpdateView | null;
  phase: string;
  progressPercent: number;
  season: string;
}

export interface AdoptionStats {
  trees: number;
  treesSponsored: number;
  farmers: number;
  sponsors: number;
  regions: number;
  countries: number;
  valueCents: number;
  renewals: number;
}
