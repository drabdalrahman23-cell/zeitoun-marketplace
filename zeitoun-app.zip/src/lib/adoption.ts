import QRCode from "qrcode";
import { db } from "@/db";
import {
  adoptionCertificates,
  adoptionPrograms,
  adoptionUpdates,
  adoptions,
  farmers,
  giftOccasions,
  notifications,
  oliveTrees,
  treeSeasons,
  users,
} from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { slugify, vInt, vStr, vUrls } from "./utils";

import {
  ADOPTION_PHASES,
  phaseIndex,
  phaseProgress,
  type AdoptionPhase,
  type TreeView,
  type TreeFull,
  type FarmerMini,
  type FarmerFull,
  type ProgramView,
  type UpdateView,
  type AdoptionView,
} from "./adoption-types";

export {
  ADOPTION_PHASES,
  phaseIndex,
  phaseProgress,
  type AdoptionPhase,
  type TreeView,
  type TreeFull,
  type FarmerMini,
  type FarmerFull,
  type ProgramView,
  type UpdateView,
  type AdoptionView,
};

/* ---------------- mappers ---------------- */

export function toFarmerMini(r: Record<string, any>): FarmerMini {
  return {
    id: r.id,
    slug: r.slug,
    nameAr: r.nameAr,
    nameEn: r.nameEn,
    farmNameAr: r.farmNameAr ?? null,
    farmNameEn: r.farmNameEn ?? null,
    region: r.region ?? null,
    city: r.city ?? null,
    yearsFarming: r.yearsFarming ?? 0,
    rating: Number(r.rating ?? 0),
    treeCount: r.treeCount ?? 0,
    sponsorCount: r.sponsorCount ?? 0,
    images: (r.images ?? []) as string[],
  };
}

export function toFarmerFull(r: Record<string, any>): FarmerFull {
  return {
    ...toFarmerMini(r),
    storyAr: r.storyAr ?? null,
    storyEn: r.storyEn ?? null,
    aboutAr: r.aboutAr ?? null,
    aboutEn: r.aboutEn ?? null,
    videoUrl: r.videoUrl ?? null,
    sellerId: r.sellerId ?? null,
    active: !!r.active,
  };
}

export function toTreeView(r: Record<string, any>): TreeView {
  return {
    id: r.id,
    treeCode: r.treeCode,
    nameAr: r.nameAr ?? null,
    nameEn: r.nameEn ?? null,
    treeNumber: r.treeNumber ?? null,
    approximateAge: r.approximateAge ?? 0,
    oliveVariety: r.oliveVariety ?? null,
    region: r.region ?? null,
    images: (r.images ?? []) as string[],
    status: r.status,
    verified: !!r.verified,
    season: r.season,
    phase: r.phase,
    progressPercent: r.progressPercent ?? phaseProgress(r.phase ?? "season_start"),
    maxSponsors: r.maxSponsors ?? 1,
    sponsorCount: r.sponsorCount ?? 0,
    farmer: toFarmerMini(r),
  };
}

export function toTreeFull(r: Record<string, any>): TreeFull {
  return {
    ...toTreeView(r),
    storyAr: r.storyAr ?? null,
    storyEn: r.storyEn ?? null,
    farmImages: (r.farmImages ?? []) as string[],
    programStartsAt: r.programStartsAt ? new Date(r.programStartsAt).toISOString() : null,
    createdAt: new Date(r.createdAt).toISOString(),
  };
}

export function toProgramView(r: Record<string, any>): ProgramView {
  return {
    id: r.id,
    slug: r.slug,
    nameAr: r.nameAr,
    nameEn: r.nameEn,
    descriptionAr: r.descriptionAr ?? null,
    descriptionEn: r.descriptionEn ?? null,
    kind: r.kind,
    priceCents: r.priceCents,
    renewalPriceCents: r.renewalPriceCents,
    durationDays: r.durationDays,
    benefits: (r.benefits ?? []) as { ar: string; en: string }[],
    includedProducts: (r.includedProducts ?? []) as ProgramView["includedProducts"],
    shippingIncluded: !!r.shippingIncluded,
    maxSponsorsPerTree: r.maxSponsorsPerTree ?? 1,
    giftEnabled: !!r.giftEnabled,
    active: !!r.active,
  };
}

export function toUpdateView(r: Record<string, any>): UpdateView {
  return {
    id: r.id,
    treeId: r.treeId ?? null,
    treeCode: r.treeCode ?? null,
    farmerId: r.farmerId,
    titleAr: r.titleAr,
    titleEn: r.titleEn,
    bodyAr: r.bodyAr ?? null,
    bodyEn: r.bodyEn ?? null,
    image: r.image ?? null,
    video: r.video ?? null,
    phase: r.phase ?? null,
    createdAt: new Date(r.createdAt).toISOString(),
  };
}

export function toAdoptionView(r: Record<string, any>): AdoptionView {
  const phase = r.tree?.phase ?? "season_start";
  return {
    id: r.id,
    status: r.status,
    displayName: r.displayName ?? null,
    renameCount: r.renameCount ?? 0,
    orderNumber: r.orderNumber ?? null,
    certificateCode: r.certificateCode ?? null,
    startDate: new Date(r.startDate).toISOString(),
    endDate: r.endDate ? new Date(r.endDate).toISOString() : null,
    priceCents: r.priceCents ?? 0,
    isGift: !!r.isGift,
    giftRecipientName: r.giftRecipientName ?? null,
    giftMessage: r.giftMessage ?? null,
    giftOccasion: r.giftOccasion ?? null,
    renewedFromId: r.renewedFromId ?? null,
    program: r.program ? toProgramView(r.program) : null,
    tree: r.tree ? toTreeView({ ...r.tree, ...r.farmerRow }) : null,
    farmer: toFarmerMini(r.farmerRow ?? r.farmer ?? {}),
    lastUpdate: r.lastUpdate ? toUpdateView(r.lastUpdate) : null,
    phase,
    progressPercent: r.tree?.progressPercent ?? phaseProgress(phase),
    season: r.tree?.season ?? r.program?.season ?? new Date().getFullYear().toString(),
  };
}

/* ---------------- tree codes ---------------- */

export async function nextTreeCode(): Promise<string> {
  const rows = await db.select({ c: sql<number>`count(*)` }).from(oliveTrees);
  const n = Number(rows[0]?.c ?? 0) + 1;
  return `ZT-TREE-${String(n).padStart(6, "0")}`;
}

export async function nextCertificateCode(): Promise<string> {
  const rows = await db.select({ c: sql<number>`count(*)` }).from(adoptionCertificates);
  const n = Number(rows[0]?.c ?? 0) + 1;
  return `ZT-CERT-${String(n).padStart(6, "0")}`;
}

/* ---------------- QR + certificate ---------------- */

export function treePublicUrl(treeCode: string): string {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "";
  return `${base}/trees/${treeCode}`;
}

export async function makeQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      margin: 1,
      width: 320,
      color: { dark: "#333d21", light: "#faf8f2" },
      errorCorrectionLevel: "M",
    });
  } catch {
    return "";
  }
}

/**
 * Creates the digital adoption certificate (with QR → public tree page)
 * and stores a denormalized snapshot so the certificate stays valid forever.
 */
export async function issueCertificate(
  adoptionId: number,
  opts: { treeCode?: string | null; publicBase?: string } = {},
): Promise<{ code: string; qrDataUrl: string } | null> {
  const rows = await db
    .select({ a: adoptions, t: oliveTrees, f: farmers, u: users, p: adoptionPrograms })
    .from(adoptions)
    .innerJoin(farmers, eq(adoptions.farmerId, farmers.id))
    .innerJoin(users, eq(adoptions.userId, users.id))
    .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
    .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
    .where(eq(adoptions.id, adoptionId));
  const row = rows[0];
  if (!row) return null;

  const code = await nextCertificateCode();
  const treeUrl = opts.publicBase ? `${opts.publicBase}/trees/${row.t?.treeCode ?? ""}` : treePublicUrl(row.t?.treeCode ?? "");
  const qrDataUrl = row.t ? await makeQrDataUrl(treeUrl) : await makeQrDataUrl(opts.publicBase ? `${opts.publicBase}/farmers/${row.f.slug}` : `/farmers/${row.f.slug}`);

  const sponsorName = row.a.isGift && row.a.giftRecipientName ? row.a.giftRecipientName : row.u.name;

  await db.insert(adoptionCertificates).values({
    adoptionId,
    code,
    qrDataUrl,
    sponsorName,
    treeName: row.a.displayName || row.t?.nameEn || row.t?.nameAr || null,
    treeCode: row.t?.treeCode ?? null,
    farmerName: row.f.nameEn,
    farmName: row.f.farmNameEn ?? row.f.farmNameAr ?? null,
    region: row.t?.region ?? row.f.region ?? row.f.city ?? null,
    season: row.t?.season ?? new Date().getFullYear().toString(),
    startDate: row.a.startDate,
  });

  await db.update(adoptions).set({ certificateCode: code }).where(eq(adoptions.id, adoptionId));
  return { code, qrDataUrl };
}

/* ---------------- notifications to sponsors ---------------- */

/** Notifies every active sponsor of a tree (or of a farmer when treeId is null). */
export async function notifySponsors(opts: {
  treeId?: number | null;
  farmerId: number;
  type: string;
  titleAr: string;
  titleEn: string;
  bodyAr?: string | null;
  bodyEn?: string | null;
  link: string;
}): Promise<number> {
  const rows = await db
    .select({ userId: adoptions.userId })
    .from(adoptions)
    .where(
      and(
        eq(adoptions.farmerId, opts.farmerId),
        opts.treeId ? eq(adoptions.treeId, opts.treeId) : sql`1=1`,
        sql`${adoptions.status} in ('active','pending','paused')`,
      ),
    );
  const ids = [...new Set(rows.map((r) => r.userId))];
  if (!ids.length) return 0;
  await db.insert(notifications).values(
    ids.map((userId) => ({
      userId,
      type: opts.type,
      titleAr: opts.titleAr,
      titleEn: opts.titleEn,
      bodyAr: opts.bodyAr ?? null,
      bodyEn: opts.bodyEn ?? null,
      link: opts.link,
    })),
  );
  return ids.length;
}

/** Latest published update per tree/farmer, for cards. */
export async function latestUpdates(farmerId: number, limit = 8): Promise<UpdateView[]> {
  const rows = await db
    .select({ up: adoptionUpdates, t: oliveTrees })
    .from(adoptionUpdates)
    .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
    .where(and(eq(adoptionUpdates.farmerId, farmerId), eq(adoptionUpdates.published, true)))
    .orderBy(desc(adoptionUpdates.createdAt))
    .limit(limit);
  return rows.map((r) => toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null }));
}

/* ---------------- validation helpers for adoption payloads ---------------- */

export function parseTreeInput(body: Record<string, any>) {
  return {
    nameAr: vStr(body.nameAr, 140) || null,
    nameEn: vStr(body.nameEn, 140) || null,
    treeNumber: body.treeNumber == null ? null : vInt(body.treeNumber, 1, 999999),
    approximateAge: vInt(body.approximateAge, 1, 3000),
    oliveVariety: vStr(body.oliveVariety, 80) || null,
    region: vStr(body.region, 120) || null,
    storyAr: vStr(body.storyAr, 4000) || null,
    storyEn: vStr(body.storyEn, 4000) || null,
    images: vUrls(body.images, 8),
    farmImages: vUrls(body.farmImages, 8),
    maxSponsors: vInt(body.maxSponsors, 1, 50),
    season: vStr(body.season, 20) || String(new Date().getFullYear()),
  };
}

export function parseProgramInput(body: Record<string, any>) {
  const benefits = Array.isArray(body.benefits)
    ? body.benefits
        .filter((b: any) => b && typeof b === "object")
        .map((b: any) => ({ ar: vStr(b.ar, 300), en: vStr(b.en, 300) }))
        .filter((b: { ar: string; en: string }) => b.ar || b.en)
        .slice(0, 20)
    : [];
  const includedProducts = Array.isArray(body.includedProducts)
    ? body.includedProducts
        .filter((p: any) => p && typeof p === "object")
        .map((p: any) => ({
          labelAr: vStr(p.labelAr, 200),
          labelEn: vStr(p.labelEn, 200),
          qty: vInt(p.qty, 1, 100),
          productId: p.productId ? vInt(p.productId, 1) : null,
        }))
        .slice(0, 20)
    : [];
  return { benefits, includedProducts };
}

export function programSlug(nameEn: string): string {
  return `${slugify(nameEn)}-${Math.random().toString(36).slice(2, 6)}`;
}

/* ---------------- gift occasions ---------------- */

export async function activeOccasions() {
  const rows = await db
    .select()
    .from(giftOccasions)
    .where(eq(giftOccasions.active, true))
    .orderBy(giftOccasions.sortOrder);
  return rows.map((r) => ({ key: r.key, nameAr: r.nameAr, nameEn: r.nameEn }));
}
