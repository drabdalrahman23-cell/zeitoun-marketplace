import type { CategoryView, ProductView, ReviewView, SellerView } from "./types";

type AnyRow = Record<string, any>;

export function toCategoryView(r: AnyRow): CategoryView {
  return {
    id: r.id,
    slug: r.slug,
    nameAr: r.nameAr,
    nameEn: r.nameEn,
    icon: r.icon,
    sortOrder: r.sortOrder,
  };
}

export function toSellerView(r: AnyRow): SellerView {
  return {
    id: r.id,
    slug: r.slug,
    shopName: r.shopName,
    region: r.region ?? null,
    city: r.city ?? null,
    about: r.about ?? null,
    story: r.story ?? null,
    images: (r.images ?? []) as string[],
    allowMessages: !!r.allowMessages,
    rating: Number(r.rating ?? 0),
    orderCount: r.orderCount ?? 0,
    joinedAt: new Date(r.joinedAt).toISOString(),
  };
}

export function toProductView(r: AnyRow): ProductView {
  return {
    id: r.id,
    slug: r.slug,
    nameAr: r.nameAr,
    nameEn: r.nameEn,
    priceCents: r.priceCents,
    currency: r.currency ?? "USD",
    images: (r.images ?? []) as string[],
    rating: Number(r.rating ?? 0),
    reviewCount: r.reviewCount ?? 0,
    salesCount: r.salesCount ?? 0,
    stock: r.stock ?? 0,
    weightGrams: r.weightGrams ?? 0,
    originRegion: r.originRegion ?? null,
    category: toCategoryView(r),
    seller: toSellerView(r),
    isFeatured: !!r.isFeatured,
    shipsInternational: !!r.shipsInternational,
    status: r.status,
    createdAt: new Date(r.createdAt).toISOString(),
  };
}

export function toProductFull(r: AnyRow) {
  const base = toProductView(r);
  return {
    ...base,
    descriptionAr: r.descriptionAr ?? null,
    descriptionEn: r.descriptionEn ?? null,
    dimensions: r.dimensions ?? null,
    videoUrl: r.videoUrl ?? null,
    productionMethodAr: r.productionMethodAr ?? null,
    productionMethodEn: r.productionMethodEn ?? null,
    ingredientsAr: r.ingredientsAr ?? null,
    ingredientsEn: r.ingredientsEn ?? null,
    usageAr: r.usageAr ?? null,
    usageEn: r.usageEn ?? null,
    allergensAr: r.allergensAr ?? null,
    allergensEn: r.allergensEn ?? null,
    storyAr: r.storyAr ?? null,
    storyEn: r.storyEn ?? null,
    storyImages: (r.storyImages ?? []) as string[],
    harvestSeason: r.harvestSeason ?? null,
  };
}

export function toReviewView(r: AnyRow): ReviewView {
  return {
    id: r.id,
    userName: r.userName ?? "Customer",
    rating: r.rating,
    qualityRating: r.qualityRating,
    packagingRating: r.packagingRating,
    shippingRating: r.shippingRating,
    commentAr: r.commentAr ?? null,
    commentEn: r.commentEn ?? null,
    createdAt: new Date(r.createdAt).toISOString(),
  };
}
