import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { adoptionPrograms, adoptionUpdates, farmers, farmerSupportPrograms, oliveTrees, products } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { latestUpdates, toFarmerFull, toProgramView, toTreeView, toUpdateView } from "@/lib/adoption";
import { FarmerPageClient } from "@/components/adoption-pages";

export const dynamic = "force-dynamic";

async function load(slug: string) {
  const f = (await db.select().from(farmers).where(eq(farmers.slug, slug)))[0];
  if (!f || !f.active) return null;

  const [treeRows, progRows, prodRows, updRows] = await Promise.all([
    db
      .select()
      .from(oliveTrees)
      .where(and(eq(oliveTrees.farmerId, f.id), eq(oliveTrees.verified, true)))
      .orderBy(desc(oliveTrees.createdAt))
      .limit(24),
    db
      .select({ p: adoptionPrograms, fsp: farmerSupportPrograms })
      .from(farmerSupportPrograms)
      .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
      .where(and(eq(farmerSupportPrograms.farmerId, f.id), eq(farmerSupportPrograms.allowed, true), eq(adoptionPrograms.active, true)))
      .orderBy(asc(adoptionPrograms.sortOrder)),
    f.sellerId
      ? db.select().from(products).where(and(eq(products.sellerId, f.sellerId), eq(products.status, "active"))).orderBy(desc(products.salesCount)).limit(8)
      : Promise.resolve([]),
    db
      .select({ up: adoptionUpdates, t: oliveTrees })
      .from(adoptionUpdates)
      .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
      .where(and(eq(adoptionUpdates.farmerId, f.id), eq(adoptionUpdates.published, true)))
      .orderBy(desc(adoptionUpdates.createdAt))
      .limit(12),
  ]);

  return {
    farmer: toFarmerFull(f),
    trees: treeRows.map((t) => toTreeView({ ...f, ...t })),
    programs: progRows.map((r) => ({
      ...toProgramView(r.p),
      priceCents: r.fsp.allowPriceOverride && r.fsp.customPriceCents ? r.fsp.customPriceCents : r.p.priceCents,
      allowPriceOverride: r.fsp.allowPriceOverride,
      customPriceCents: r.fsp.customPriceCents,
      slots: r.fsp.slots,
    })),
    products: prodRows.map((p) => ({
      id: p.id,
      slug: p.slug,
      nameAr: p.nameAr,
      nameEn: p.nameEn,
      priceCents: p.priceCents,
      images: p.images,
      stock: p.stock,
      weightGrams: p.weightGrams,
    })),
    updates: updRows.map((r) => toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null })),
  };
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const data = await load(slug).catch(() => null);
  if (!data) return { title: "Farmer | Zeitoun" };
  return {
    title: `${data.farmer.nameEn} — Palestinian farmer`,
    description: (data.farmer.storyEn ?? data.farmer.aboutEn ?? "").slice(0, 160),
    openGraph: {
      title: `${data.farmer.nameEn} | Zeitoun`,
      description: (data.farmer.storyEn ?? "").slice(0, 160),
      images: data.farmer.images[0] ? [data.farmer.images[0]] : [],
    },
  };
}

export default async function FarmerPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await load(slug).catch(() => null);
  if (!data) notFound();
  return <FarmerPageClient {...data} />;
}
