import type { Metadata } from "next";
import { db } from "@/db";
import { farmers } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { toFarmerMini } from "@/lib/adoption";
import { FarmersPageClient } from "@/components/adoption-pages";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Meet the farmers | تعرف على المزارعين",
  description: "Palestinian farmers and their stories — sponsor a farmer's season directly.",
};

export default async function FarmersPage() {
  const rows = await db
    .select({
      f: farmers,
      available: sql<number>`(select count(*) from olive_trees where farmer_id = farmers.id and verified and status = 'available')`,
    })
    .from(farmers)
    .where(eq(farmers.active, true))
    .orderBy(desc(farmers.rating), desc(farmers.sponsorCount))
    .limit(60);

  const regions = [...new Set(rows.map((r) => r.f.region ?? r.f.city).filter(Boolean))] as string[];

  return (
    <FarmersPageClient
      farmers={rows.map((r) => ({ ...toFarmerMini(r.f), availableTrees: Number(r.available) }))}
      regions={regions}
    />
  );
}
