import type { Metadata } from "next";
import { db } from "@/db";
import { adoptionPrograms, farmers, farmerSupportPrograms, oliveTrees } from "@/db/schema";
import { and, asc, count, desc, eq, sql } from "drizzle-orm";
import { toFarmerMini, toProgramView, toTreeView } from "@/lib/adoption";
import { AdoptPageClient } from "@/components/adoption-pages";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Adopt an olive tree | تبنَّ شجرة زيتون",
  description:
    "Sponsor a real Palestinian olive tree or support a farmer through the season. Symbolic sponsorship — certificate, seasonal updates, photos and harvest products.",
  openGraph: {
    title: "Adopt a Palestinian olive tree | Zeitoun",
    description: "One tree can carry a whole family's story. Be part of it.",
  },
};

export default async function AdoptPage() {
  const [treeRows, farmerRows, programRows, regionRows] = await Promise.all([
    db
      .select({ t: oliveTrees, f: farmers })
      .from(oliveTrees)
      .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
      .where(and(eq(oliveTrees.verified, true), eq(oliveTrees.status, "available"), eq(farmers.active, true)))
      .orderBy(desc(oliveTrees.verifiedAt), desc(oliveTrees.createdAt))
      .limit(48),
    db
      .select({ f: farmers, available: sql<number>`(select count(*) from olive_trees where farmer_id = farmers.id and verified and status = 'available')` })
      .from(farmers)
      .where(eq(farmers.active, true))
      .orderBy(desc(farmers.rating), desc(farmers.sponsorCount))
      .limit(8),
    db
      .select({ p: adoptionPrograms })
      .from(adoptionPrograms)
      .where(eq(adoptionPrograms.active, true))
      .orderBy(asc(adoptionPrograms.sortOrder)),
    db
      .select({ region: oliveTrees.region, c: count() })
      .from(oliveTrees)
      .where(eq(oliveTrees.verified, true))
      .groupBy(oliveTrees.region),
  ]);

  return (
    <AdoptPageClient
      trees={treeRows.map((r) => toTreeView({ ...r.f, ...r.t }))}
      farmers={farmerRows.map((r) => ({ ...toFarmerMini(r.f), availableTrees: Number(r.available) }))}
      programs={programRows.map((r) => toProgramView(r.p))}
      regions={regionRows.filter((r) => r.region).map((r) => ({ region: r.region as string, count: r.c }))}
    />
  );
}
