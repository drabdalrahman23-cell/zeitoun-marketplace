"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Field, Modal, Spinner, TextInput } from "@/components/ui";
import { PhaseTimeline, TransparencyNote, UpdatesList } from "@/components/adoption";
import { api, errMsg } from "@/lib/api";
import type { AdoptionView, UpdateView } from "@/lib/adoption-types";
import { fmtDate, timeAgo } from "@/lib/utils";

const STATUS_TONE: Record<string, string> = {
  pending: "bg-gold-300/40 text-gold-500",
  active: "bg-olive-700 text-white",
  paused: "bg-cream-200 text-ink-600",
  completed: "bg-olive-100 text-olive-800",
  expired: "bg-clay-100 text-clay-700",
  renewed: "bg-olive-100 text-olive-800",
  cancelled: "bg-cream-200 text-ink-600",
};

export default function MyTreesPage() {
  const { t, d, fmt, me, lang, toast } = useStore();
  const router = useRouter();
  const [items, setItems] = useState<AdoptionView[] | null>(null);
  const [updates, setUpdates] = useState<UpdateView[]>([]);
  const [renewSoon, setRenewSoon] = useState<number[]>([]);
  const [renaming, setRenaming] = useState<AdoptionView | null>(null);
  const [newName, setNewName] = useState("");
  const [renewing, setRenewing] = useState<AdoptionView | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    fetch("/api/adoptions", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => {
        if (x) {
          setItems(x.items);
          setRenewSoon(x.renewSoon ?? []);
        }
      })
      .catch(() => setItems([]));
    fetch("/api/adoption/updates", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setUpdates(x?.items ?? []))
      .catch(() => {});
  };

  useEffect(() => {
    if (!me) router.replace("/auth/login?next=/my-trees");
    else load();
  }, [me, router]);

  const rename = async () => {
    if (!renaming) return;
    setBusy(true);
    try {
      await api(`/api/adoptions/${renaming.id}`, { method: "PATCH", body: { displayName: newName } });
      toast(t("ad_t_renamed"));
      setRenaming(null);
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  const renew = async () => {
    if (!renewing) return;
    setBusy(true);
    try {
      const res = await api<{ certificateCode?: string | null }>(`/api/adoptions/${renewing.id}/renew`, { body: { paymentProvider: "card" } });
      toast(t("ad_t_renewed"));
      setRenewing(null);
      load();
      if (res.certificateCode) router.push(`/certificate/${res.certificateCode}`);
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  const cancel = async (a: AdoptionView) => {
    setBusy(true);
    try {
      await api(`/api/adoptions/${a.id}`, { method: "PATCH", body: { status: "cancelled" } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    } finally {
      setBusy(false);
    }
  };

  if (!me) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <div className="flex items-end justify-between gap-4 flex-wrap mb-6">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">🌿 {t("ad_my_trees")}</h1>
          <p className="text-sm text-ink-400 mt-1">{t("ad_my_trees_sub")}</p>
        </div>
        <Link href="/adopt"><Btn>{t("ad_adopt_another")}</Btn></Link>
      </div>

      {items === null ? (
        <div className="flex justify-center py-16"><Spinner className="w-8 h-8" /></div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<span className="text-3xl">🌿</span>}
          title={t("ad_no_adoptions")}
          hint={t("ad_no_adoptions_hint")}
          action={<Link href="/adopt"><Btn>{t("ad_home_btn1")}</Btn></Link>}
        />
      ) : (
        <div className="space-y-4">
          {items.map((a) => {
            const treeName = a.displayName || (a.tree ? d({ ar: a.tree.nameAr, en: a.tree.nameEn }) || a.tree.treeCode : d({ ar: a.farmer.nameAr, en: a.farmer.nameEn }));
            const endsSoon = renewSoon.includes(a.id);
            const expired = a.status === "expired" || a.status === "completed";
            return (
              <article key={a.id} className="rounded-3xl border border-cream-200 bg-white overflow-hidden">
                <div className="flex flex-col sm:flex-row">
                  <Link
                    href={a.tree ? `/trees/${a.tree.treeCode}` : `/farmers/${a.farmer.slug}`}
                    className="sm:w-44 h-40 sm:h-auto bg-cream-100 overflow-hidden shrink-0 block"
                  >
                    {a.tree?.images[0] || a.farmer.images[0] ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={(a.tree?.images[0] ?? a.farmer.images[0]) as string} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-4xl">🌿</div>
                    )}
                  </Link>
                  <div className="flex-1 p-4 md:p-5 min-w-0">
                    <div className="flex items-start justify-between gap-3 flex-wrap">
                      <div className="min-w-0">
                        <h2 className="font-display font-bold text-lg text-ink-900 truncate">{treeName}</h2>
                        <div className="flex items-center gap-2 mt-1 flex-wrap text-[11px] font-bold text-ink-400">
                          {a.tree && <span dir="ltr">{a.tree.treeCode}</span>}
                          <span>· {d({ ar: a.farmer.nameAr, en: a.farmer.nameEn })}</span>
                          <span>· {t("ad_season")} {a.season}</span>
                        </div>
                      </div>
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${STATUS_TONE[a.status] ?? "bg-cream-100 text-ink-600"}`}>
                        {t(`ad_status_${a.status}`)}
                      </span>
                    </div>

                    <div className="mt-3.5">
                      <PhaseTimeline phase={a.phase} progress={a.progressPercent} compact />
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-xs font-bold text-olive-800">{t(`ad_phase_${a.phase}`)}</span>
                        {a.lastUpdate && (
                          <span className="text-[11px] text-ink-400">
                            {t("ad_last_update")}: {timeAgo(a.lastUpdate.createdAt, lang)}
                          </span>
                        )}
                      </div>
                    </div>

                    {a.isGift && a.giftRecipientName && (
                      <div className="mt-3 text-[11px] font-bold text-clay-600">🎁 {t("ad_gift_for")} {a.giftRecipientName}</div>
                    )}

                    {(endsSoon || expired || a.status === "renewed") && (
                      <div className="mt-3 rounded-xl bg-gold-300/15 border border-gold-300/50 px-3 py-2 text-xs font-bold text-ink-700">
                        ⏳ {expired ? t("ad_renew_expired") : t("ad_renew_soon")}{" "}
                        {a.endDate && <span className="text-ink-400">({fmtDate(a.endDate, lang)})</span>}
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 mt-4">
                      {a.certificateCode && (
                        <Link href={`/certificate/${a.certificateCode}`} className="rounded-xl bg-olive-700 text-cream-50 text-xs font-bold px-3.5 py-2 hover:bg-olive-800 transition">
                          📜 {t("ad_view_cert")}
                        </Link>
                      )}
                      {a.tree && ["pending", "active", "paused"].includes(a.status) && a.renameCount < 3 && (
                        <Btn variant="outline" className="!px-3.5 !py-2 !text-xs" onClick={() => { setRenaming(a); setNewName(a.displayName ?? ""); }}>
                          ✏️ {t("ad_rename")}
                        </Btn>
                      )}
                      {["active", "expired", "completed", "paused"].includes(a.status) && (
                        <Btn variant="outline" className="!px-3.5 !py-2 !text-xs" onClick={() => setRenewing(a)}>
                          🔄 {t("ad_renew")} {a.program ? `· ${fmt(a.program.renewalPriceCents)}` : ""}
                        </Btn>
                      )}
                      {a.program?.kind !== "farmer" && (
                        <Link href="/adopt" className="rounded-xl border border-cream-300 text-ink-700 text-xs font-bold px-3.5 py-2 hover:border-olive-400 transition">
                          🌿 {t("ad_adopt_another")}
                        </Link>
                      )}
                      {a.tree && (
                        <Link href={`/farmers/${a.farmer.slug}`} className="rounded-xl border border-cream-300 text-ink-700 text-xs font-bold px-3.5 py-2 hover:border-olive-400 transition">
                          🛒 {t("ad_option_buy")}
                        </Link>
                      )}
                      {["pending", "active"].includes(a.status) && (
                        <button onClick={() => cancel(a)} disabled={busy} className="text-xs font-bold text-clay-600 hover:underline px-2">
                          {t("ad_cancel")}
                        </button>
                      )}
                    </div>

                    <div className="mt-3.5 pt-3 border-t border-cream-100 flex items-center justify-between text-[11px] text-ink-400 font-semibold flex-wrap gap-2">
                      <span>{t("ad_start_date")}: {fmtDate(a.startDate, lang)} {a.endDate && `→ ${fmtDate(a.endDate, lang)}`}</span>
                      {a.orderNumber && <span dir="ltr">{a.orderNumber} · {fmt(a.priceCents)}</span>}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {items && items.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-xl font-bold text-ink-900 mb-4">{t("ad_updates")}</h2>
          <UpdatesList updates={updates} showFarmer />
        </section>
      )}

      <div className="mt-10">
        <TransparencyNote compact />
      </div>

      <Modal open={!!renaming} onClose={() => setRenaming(null)} title={t("ad_rename")}>
        <Field label={t("ad_name_tree")} hint={`${t("ad_name_tree_hint")} · ${t("ad_rename_limit")}`}>
          <TextInput value={newName} onChange={(e) => setNewName(e.target.value)} maxLength={60} />
        </Field>
        <Btn onClick={rename} disabled={busy || !newName.trim()} className="w-full mt-4">{t("save")}</Btn>
      </Modal>

      <Modal open={!!renewing} onClose={() => setRenewing(null)} title={t("ad_renew")}>
        {renewing && (
          <div className="space-y-4">
            <p className="text-sm text-ink-600 leading-relaxed">{t("ad_faq_a10")}</p>
            <div className="rounded-2xl bg-cream-100/70 border border-cream-200 p-4">
              <div className="flex justify-between text-sm">
                <span className="text-ink-400">{t("ad_renew_price")}</span>
                <b className="font-display">{fmt(renewing.program?.renewalPriceCents ?? 0)}</b>
              </div>
              <div className="flex justify-between text-sm mt-2">
                <span className="text-ink-400">{t("ad_duration")}</span>
                <b>{renewing.program?.durationDays} {t("ad_days_n")}</b>
              </div>
            </div>
            <div className="rounded-xl bg-gold-300/15 border border-gold-300/50 p-3 text-[11px] text-ink-700 leading-relaxed">
              {t("co_mock_note")}
            </div>
            <Btn onClick={renew} disabled={busy} className="w-full">
              {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : `${t("ad_renew")} · ${fmt(renewing.program?.renewalPriceCents ?? 0)}`}
            </Btn>
          </div>
        )}
      </Modal>
    </div>
  );
}
