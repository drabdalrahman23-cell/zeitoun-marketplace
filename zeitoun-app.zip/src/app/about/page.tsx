"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { Btn } from "@/components/ui";

export default function AboutPage() {
  const { t } = useStore();
  const values = [
    { icon: "🫒", title: t("about_v1t"), desc: t("about_v1d") },
    { icon: "🌾", title: t("about_v2t"), desc: t("about_v2d") },
    { icon: "🧵", title: t("about_v3t"), desc: t("about_v3d") },
    { icon: "🏺", title: t("about_v4t"), desc: t("about_v4d") },
  ];
  return (
    <div className="anim-fade-up">
      <section className="bg-olive-950 text-cream-50 py-16 md:py-24">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <span className="text-olive-300 font-bold text-sm">{t("about_kicker")}</span>
          <h1 className="font-display text-4xl md:text-5xl font-bold mt-2">{t("about_title")}</h1>
          <p className="text-cream-200 mt-6 leading-relaxed text-lg">{t("about_p1")}</p>
          <p className="text-cream-200 mt-4 leading-relaxed">{t("about_p2")}</p>
        </div>
      </section>
      <section className="max-w-6xl mx-auto px-4 py-14 md:py-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {values.map((v, i) => (
            <div key={i} className="rounded-2xl border border-cream-200 bg-white p-6">
              <div className="text-3xl">{v.icon}</div>
              <h3 className="font-bold text-ink-900 mt-3">{v.title}</h3>
              <p className="text-sm text-ink-600 mt-2 leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 rounded-3xl leaf-bg bg-cream-100/70 border border-cream-200 p-8 md:p-12 text-center">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-ink-900">{t("home_cta_title")}</h2>
          <p className="text-ink-600 mt-2 max-w-lg mx-auto">{t("home_cta_body")}</p>
          <div className="flex justify-center gap-3 mt-6 flex-wrap">
            <Link href="/apply-seller"><Btn className="!px-7 !py-3">{t("home_cta_btn")}</Btn></Link>
            <Link href="/products" className="rounded-xl border border-olive-300 text-olive-800 font-bold px-7 py-3 hover:bg-olive-50 transition">
              {t("hero_shop")}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
