"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Field, Modal, Select, StatusBadge, TextInput } from "@/components/ui";
import { api, errMsg } from "@/lib/api";
import { fmtDate } from "@/lib/utils";

interface Addr {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  country: string;
  countryCode: string;
  state: string | null;
  city: string;
  addressLine: string;
  postalCode: string;
  isDefault: boolean;
}

const EMPTY: Addr = { id: 0, label: "Home", fullName: "", phone: "", country: "", countryCode: "US", state: "", city: "", addressLine: "", postalCode: "", isDefault: false };

export default function AccountPage() {
  const { t, d, me, refreshMe, lang, toast } = useStore();
  const router = useRouter();
  const [addrs, setAddrs] = useState<Addr[]>([]);
  const [appStatus, setAppStatus] = useState<{ seller: boolean; application: { status: string } | null }>({ seller: false, application: null });
  const [modal, setModal] = useState<Addr | null>(null);
  const [countries, setCountries] = useState<{ code: string; nameAr: string; nameEn: string }[]>([]);

  useEffect(() => {
    if (!me) router.replace("/auth/login");
  }, [me, router]);

  const load = () => {
    fetch("/api/addresses", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((a) => setAddrs(a?.items ?? [])).catch(() => {});
    fetch("/api/seller/status", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((s) => {
        if (s) setAppStatus({ seller: !!s.seller, application: s.applications?.[0] ?? null });
      })
      .catch(() => {});
  };
  useEffect(() => {
    if (me) load();
    fetch("/api/meta").then((r) => (r.ok ? r.json() : null)).then((m) => m?.countries && setCountries(m.countries)).catch(() => {});
  }, [me]);

  if (!me) return null;

  const saveAddr = async () => {
    if (!modal) return;
    try {
      const body = { ...modal, countryCode: modal.countryCode };
      if (modal.id) await api("/api/addresses", { method: "PUT", body });
      else await api("/api/addresses", { body });
      setModal(null);
      load();
      toast(t("t_saved"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const deleteAddr = async (id: number) => {
    try {
      await api("/api/addresses", { method: "DELETE", body: { id } });
      load();
      toast(t("t_deleted"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-6">{t("account_title")}</h1>

      <div className="grid md:grid-cols-2 gap-5">
        {/* profile */}
        <section className="rounded-2xl border border-cream-200 bg-white p-5">
          <h2 className="font-bold text-ink-900 mb-4">{t("account_profile")}</h2>
          <div className="flex items-center gap-4">
            <span className="w-14 h-14 rounded-2xl bg-olive-700 text-cream-50 text-xl font-bold flex items-center justify-center">
              {me.name.slice(0, 1).toUpperCase()}
            </span>
            <div>
              <div className="font-bold text-ink-900">{me.name}</div>
              <div className="text-sm text-ink-400" dir="ltr">{me.email}</div>
              <div className="text-xs text-ink-400 mt-1">
                {t("member_since")} {me.createdAt ? fmtDate(me.createdAt, lang) : ""}
              </div>
            </div>
          </div>
        </section>

        {/* seller status */}
        <section className="rounded-2xl border border-cream-200 bg-white p-5">
          <h2 className="font-bold text-ink-900 mb-4">{t("account_seller")}</h2>
          {appStatus.seller ? (
            <>
              <p className="text-sm text-ink-600">{t("account_app_approved")}</p>
              <Link href="/dashboard/seller"><Btn className="mt-4">{t("seller_dash")}</Btn></Link>
            </>
          ) : appStatus.application?.status === "pending" ? (
            <p className="text-sm text-ink-600 flex items-center gap-2"><StatusBadge status="pending" /> {t("account_app_pending")}</p>
          ) : appStatus.application?.status === "rejected" ? (
            <p className="text-sm text-clay-600 font-bold">{t("account_app_rejected")}</p>
          ) : (
            <>
              <p className="text-sm text-ink-600">{t("account_no_app")}</p>
              <Link href="/apply-seller"><Btn className="mt-4">{t("account_apply")}</Btn></Link>
            </>
          )}
        </section>
      </div>

      {/* addresses */}
      <section className="rounded-2xl border border-cream-200 bg-white p-5 mt-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-ink-900">{t("account_addresses")}</h2>
          <Btn variant="outline" onClick={() => setModal({ ...EMPTY, isDefault: addrs.length === 0 })}>{t("account_add_address")}</Btn>
        </div>
        {addrs.length === 0 ? (
          <p className="text-sm text-ink-400">—</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {addrs.map((a) => (
              <div key={a.id} className="rounded-xl border border-cream-200 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-ink-900">{a.fullName}</span>
                  {a.isDefault && <span className="text-[10px] font-bold rounded-full bg-olive-100 text-olive-800 px-2 py-0.5">{t("account_default")}</span>}
                </div>
                <p className="text-xs text-ink-400 mt-1 leading-relaxed">
                  {a.addressLine}, {a.city}, {a.country} {a.postalCode}
                  <br />
                  {a.phone}
                </p>
                <div className="flex gap-3 mt-3">
                  <button onClick={() => setModal(a)} className="text-xs font-bold text-olive-700 hover:underline">{t("edit")}</button>
                  <button onClick={() => deleteAddr(a.id)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* quick links */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-5">
        {[
          { href: "/orders", label: t("nav_orders"), icon: "📦" },
          { href: "/favorites", label: t("nav_favorites"), icon: "❤️" },
          { href: "/messages", label: t("nav_messages"), icon: "💬" },
          { href: "/notifications", label: t("nav_notifs"), icon: "🔔" },
          { href: "/my-trees", label: t("ad_my_trees"), icon: "🌿" },
        ].map((l) => (
          <Link key={l.href} href={l.href} className="rounded-2xl border border-cream-200 bg-white p-4 text-center hover:border-olive-300 hover:shadow-sm transition">
            <div className="text-2xl">{l.icon}</div>
            <div className="text-sm font-bold text-ink-700 mt-1">{l.label}</div>
          </Link>
        ))}
      </div>

      {/* address modal */}
      <Modal open={modal !== null} onClose={() => setModal(null)} title={modal?.id ? t("edit") : t("account_add_address")}>
        {modal && (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("co_full_name")}>
                <TextInput value={modal.fullName} onChange={(e) => setModal({ ...modal, fullName: e.target.value })} />
              </Field>
              <Field label={t("co_phone")}>
                <TextInput dir="ltr" value={modal.phone} onChange={(e) => setModal({ ...modal, phone: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("co_country")}>
                <Select
                  value={modal.countryCode}
                  onChange={(e) => {
                    const c = countries.find((x) => x.code === e.target.value);
                    setModal({ ...modal, countryCode: e.target.value, country: c ? d({ ar: c.nameAr, en: c.nameEn }) : "" });
                  }}
                >
                  {countries.map((c) => (
                    <option key={c.code} value={c.code}>{d({ ar: c.nameAr, en: c.nameEn })}</option>
                  ))}
                </Select>
              </Field>
              <Field label={`${t("co_state")} (${t("optional")})`}>
                <TextInput value={modal.state ?? ""} onChange={(e) => setModal({ ...modal, state: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("co_city")}>
                <TextInput value={modal.city} onChange={(e) => setModal({ ...modal, city: e.target.value })} />
              </Field>
              <Field label={t("co_postal")}>
                <TextInput dir="ltr" value={modal.postalCode} onChange={(e) => setModal({ ...modal, postalCode: e.target.value })} />
              </Field>
            </div>
            <Field label={t("co_address")}>
              <TextInput value={modal.addressLine} onChange={(e) => setModal({ ...modal, addressLine: e.target.value })} />
            </Field>
            <Btn onClick={saveAddr} className="w-full">{t("save")}</Btn>
          </div>
        )}
      </Modal>
    </div>
  );
}
