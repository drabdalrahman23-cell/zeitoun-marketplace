"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, Field, Spinner, TextArea, TextInput, StatusBadge } from "@/components/ui";
import { api, errMsg } from "@/lib/api";

const TYPES = [
  { id: "olive", ar: "زيت الزيتون والزيتون", en: "Olive oil & olives" },
  { id: "agricultural", ar: "منتجات زراعية", en: "Agricultural" },
  { id: "honey", ar: "عسل وأغذية طبيعية", en: "Honey & natural foods" },
  { id: "herbs", ar: "أعشاب وتوابل", en: "Herbs & spices" },
  { id: "embroidery", ar: "تطريز ومنسوجات", en: "Embroidery & textiles" },
  { id: "crafts", ar: "حرف يدوية", en: "Handicrafts" },
  { id: "wood", ar: "منتجات خشبية", en: "Wood products" },
  { id: "food", ar: "منتجات غذائية", en: "Food" },
  { id: "art", ar: "فنون", en: "Art" },
];

export default function ApplySellerPage() {
  const { t, d, me, lang, toast } = useStore();
  const router = useRouter();
  const [form, setForm] = useState({ shopName: "", city: "", region: "", about: "", types: [] as string[], agree: false });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [status, setStatus] = useState<{ seller: boolean; app: { status: string } | null } | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!me) router.replace("/auth/login?next=/apply-seller");
    else if (me.role === "seller") router.replace("/dashboard/seller");
  }, [me, router]);

  useEffect(() => {
    if (!me) return;
    fetch("/api/seller/status", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((s) => s && setStatus({ seller: !!s.seller, app: s.applications?.[0] ?? null }))
      .catch(() => {});
  }, [me]);

  const toggleType = (id: string) =>
    setForm((f) => ({ ...f, types: f.types.includes(id) ? f.types.filter((x) => x !== id) : [...f.types, id] }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      await api("/api/sellers", { body: form });
      setDone(true);
      toast(t("t_app_sent"));
    } catch (er) {
      setErr(errMsg(er, lang));
    } finally {
      setBusy(false);
    }
  };

  if (done)
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center anim-pop">
        <div className="w-20 h-20 mx-auto rounded-full bg-olive-700 text-cream-50 flex items-center justify-center text-4xl">✓</div>
        <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mt-5">{t("apply_submitted")}</h1>
        <p className="text-ink-400 mt-2">{t("apply_submitted_hint")}</p>
        <Link href="/account"><Btn className="mt-6">{t("nav_account")}</Btn></Link>
      </div>
    );

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 md:py-14 anim-fade-up">
      <div className="text-center mb-8">
        <span className="text-clay-600 font-bold text-sm">Zeitoun for makers</span>
        <h1 className="font-display text-3xl md:text-4xl font-bold text-ink-900 mt-1">{t("apply_title")}</h1>
        <p className="text-ink-400 mt-3 max-w-lg mx-auto">{t("apply_sub")}</p>
      </div>

      {status?.seller ? (
        <div className="rounded-2xl border border-olive-200 bg-olive-50 p-6 text-center">
          <p className="font-bold text-olive-900">{t("account_app_approved")}</p>
          <Link href="/dashboard/seller"><Btn className="mt-4">{t("seller_dash")}</Btn></Link>
        </div>
      ) : status?.app?.status === "pending" ? (
        <div className="rounded-2xl border border-gold-300/60 bg-gold-300/10 p-6 text-center">
          <div className="flex justify-center mb-2"><StatusBadge status="pending" /></div>
          <p className="font-bold text-ink-800">{t("account_app_pending")}</p>
        </div>
      ) : (
        <form onSubmit={submit} className="rounded-3xl border border-cream-200 bg-white p-6 md:p-8 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Field label={t("apply_shop")}>
              <TextInput value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} required />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("apply_city")}>
                <TextInput value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              </Field>
              <Field label={t("apply_region")}>
                <TextInput value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} />
              </Field>
            </div>
          </div>
          <div>
            <span className="block text-sm font-semibold text-ink-700 mb-2">{t("apply_types")}</span>
            <div className="flex flex-wrap gap-2">
              {TYPES.map((tp) => (
                <button
                  key={tp.id}
                  type="button"
                  onClick={() => toggleType(tp.id)}
                  className={`rounded-full border px-3.5 py-1.5 text-xs font-bold transition ${
                    form.types.includes(tp.id) ? "border-olive-600 bg-olive-700 text-cream-50" : "border-cream-300 bg-white text-ink-600 hover:border-olive-400"
                  }`}
                >
                  {d(tp)}
                </button>
              ))}
            </div>
          </div>
          <Field label={t("apply_about")}>
            <TextArea value={form.about} onChange={(e) => setForm({ ...form, about: e.target.value })} />
          </Field>
          <label className="flex items-start gap-2.5 text-sm font-bold text-ink-700 cursor-pointer">
            <input type="checkbox" checked={form.agree} onChange={(e) => setForm({ ...form, agree: e.target.checked })} className="mt-0.5 w-4.5 h-4.5 accent-olive-700" required />
            {t("apply_agree")}
          </label>
          {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
          <Btn type="submit" disabled={busy} className="w-full">
            {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("apply_submit")}
          </Btn>
        </form>
      )}
    </div>
  );
}
