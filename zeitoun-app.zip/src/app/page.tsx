import { db } from "@/db";
import { adoptionPrograms, categories, countries, farmers, oliveTrees, products, reviews, sellers, siteContent, users } from "@/db/schema";
import { and, asc, count, desc, eq, sql } from "drizzle-orm";
import { toCategoryView, toProductView, toReviewView } from "@/lib/views";
import { toFarmerMini, toProgramView, toTreeView } from "@/lib/adoption";
import { HomeClient } from "@/components/home";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [catRows, featured, popular, newest, sellerRows, reviewRows, contentRows, pCount, sCount, cCount, rCount] =
    await Promise.all([
      db.select().from(categories).where(eq(categories.active, true)).orderBy(asc(categories.sortOrder)).limit(12),
      db
        .select({ p: products, c: categories, s: sellers })
        .from(products)
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .innerJoin(sellers, eq(products.sellerId, sellers.id))
        .where(eq(products.status, "active"))
        .orderBy(desc(products.isFeatured), desc(products.salesCount))
        .limit(8),
      db
        .select({ p: products, c: categories, s: sellers })
        .from(products)
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .innerJoin(sellers, eq(products.sellerId, sellers.id))
        .where(eq(products.status, "active"))
        .orderBy(desc(products.salesCount))
        .limit(8),
      db
        .select({ p: products, c: categories, s: sellers })
        .from(products)
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .innerJoin(sellers, eq(products.sellerId, sellers.id))
        .where(eq(products.status, "active"))
        .orderBy(desc(products.createdAt))
        .limit(8),
      db
        .select({
          s: sellers,
          pc: sql<number>`(select count(*) from products where seller_id = sellers.id and status = 'active')`,
        })
        .from(sellers)
        .where(eq(sellers.status, "active"))
        .orderBy(desc(sellers.rating), desc(sellers.orderCount))
        .limit(4),
      db
        .select({ r: reviews, u: users, p: products })
        .from(reviews)
        .innerJoin(users, eq(reviews.userId, users.id))
        .innerJoin(products, eq(reviews.productId, products.id))
        .where(eq(reviews.status, "active"))
        .orderBy(desc(reviews.rating), desc(reviews.createdAt))
        .limit(6),
      db.select().from(siteContent),
      db.select({ c: count() }).from(products).where(eq(products.status, "active")),
      db.select({ c: count() }).from(sellers).where(eq(sellers.status, "active")),
      db.select({ c: count() }).from(countries).where(eq(countries.active, true)),
      db.select({ c: count() }).from(reviews).where(eq(reviews.status, "active")),
    ]);

  const hero = contentRows.find((r) => r.key === "hero")?.value ?? null;

  /* Adoption feature: server-rendered so the home sections are SEO-visible and flash-free */
  const [adoptTreeRows, adoptFarmerRows, adoptProgramRows] = await Promise.all([
    db
      .select({ t: oliveTrees, f: farmers })
      .from(oliveTrees)
      .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
      .where(and(eq(oliveTrees.verified, true), eq(oliveTrees.status, "available"), eq(farmers.active, true)))
      .orderBy(desc(oliveTrees.verifiedAt), desc(oliveTrees.createdAt))
      .limit(4)
      .catch(() => []),
    db
      .select()
      .from(farmers)
      .where(eq(farmers.active, true))
      .orderBy(desc(farmers.rating), desc(farmers.sponsorCount))
      .limit(4)
      .catch(() => []),
    db
      .select()
      .from(adoptionPrograms)
      .where(eq(adoptionPrograms.active, true))
      .orderBy(asc(adoptionPrograms.sortOrder))
      .catch(() => []),
  ]);

  return (
    <HomeClient
      categories={catRows.map(toCategoryView)}
      featured={featured.map((r) => toProductView({ ...r.c, ...r.s, ...r.p }))}
      popular={popular.map((r) => toProductView({ ...r.c, ...r.s, ...r.p }))}
      newest={newest.map((r) => toProductView({ ...r.c, ...r.s, ...r.p }))}
      sellers={sellerRows.map((r) => ({
        id: r.s.id,
        slug: r.s.slug,
        shopName: r.s.shopName,
        region: r.s.region,
        city: r.s.city,
        about: r.s.about,
        rating: Number(r.s.rating),
        orderCount: r.s.orderCount,
        images: r.s.images,
        productCount: Number(r.pc),
        joinedAt: new Date(r.s.joinedAt).toISOString(),
      }))}
      reviews={reviewRows.map(({ r, u, p }) => ({
        ...toReviewView({ ...r, userName: u.name }),
        productAr: p.nameAr,
        productEn: p.nameEn,
      }))}
      hero={hero}
      stats={{ products: pCount[0].c, sellers: sCount[0].c, countries: cCount[0].c, reviews: rCount[0].c }}
      adoptTrees={adoptTreeRows.map((r) => toTreeView({ ...r.f, ...r.t }))}
      adoptFarmers={adoptFarmerRows.map((r) => toFarmerMini(r))}
      adoptPrograms={adoptProgramRows.map((r) => toProgramView(r))}
    />
  );
}
