import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter, Almarai, Fraunces } from "next/font/google";
import "./globals.css";
import { StoreProvider } from "@/components/store";
import { Header, Footer, MobileNav } from "@/components/chrome";
import { SwRegister } from "@/components/sw-register";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const almarai = Almarai({ subsets: ["arabic"], weight: ["300", "400", "700", "800"], variable: "--font-almarai", display: "swap" });
const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL("https://zeitoun.example"),
  title: {
    default: "Zeitoun | زيتون — Palestinian Products. Directly From Their Makers.",
    template: "%s | Zeitoun",
  },
  description:
    "Zeitoun is a Palestinian marketplace connecting farmers and artisans with customers worldwide — olive oil, honey, za'atar, embroidery, handicrafts and more, directly from the land of Palestine to your door.",
  openGraph: {
    title: "Zeitoun | زيتون — من أرض فلسطين إلى العالم",
    description: "منتجات فلسطينية. مباشرة من أصحابها. Palestinian products, directly from their makers.",
    type: "website",
    images: [{ url: "/images/hero.jpg", width: 1200, height: 675 }],
  },
};

export const viewport: Viewport = {
  themeColor: "#465628",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${inter.variable} ${almarai.variable} ${fraunces.variable}`}>
      <body>
        <StoreProvider>
          <Header />
          <main className="min-h-[70vh] pb-16 md:pb-0">{children}</main>
          <Footer />
          <MobileNav />
        </StoreProvider>
        <SwRegister />
      </body>
    </html>
  );
}
