"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Spinner, StatusBadge } from "@/components/ui";
import { fmtDate } from "@/lib/utils";

interface OrderRow {
  id: number;
  orderNumber: string;
  status: string;
  createdAt: string;
  totalCents: number;
  itemCount: number;
  firstItemNameAr: string | null;
  firstItemNameEn: string | null;
  firstItemImage: string | null;
  seller: { id: number; slug: string; shopName: string; city: string | null };
}

export default function OrdersPage() {
  const { t, d, fmt, me, lang } = useStore();
  const [orders, setOrders] = useState<OrderRow[] | null>(null);

  useEffect(() => {
    if (!me) return;
    fetch("/api/orders", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => data?.items && setOrders(data.items))
      .catch(() => setOrders([]));
  }, [me]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-6">{t("orders_title")}</h1>
      {!me ? (
        <EmptyState icon={<span className="text-3xl">📦</span>} title={t("login_required")} />
      ) : orders === null ? (
        <div className="flex justify-center py-16">
          <Spinner className="w-8 h-8" />
        </div>
      ) : orders.length === 0 ? (
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-current" strokeWidth="1.5">
              <path d="M21 8l-9-5-9 5v8l9 5 9-5z" /><path d="M3 8l9 5 9-5M12 13v8" />
            </svg>
          }
          title={t("orders_empty")}
          hint={t("orders_empty_hint")}
          action={<Link href="/products"><Btn>{t("go_shop")}</Btn></Link>}
        />
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <Link
              key={o.id}
              href={`/orders/${o.id}`}
              className="block rounded-2xl border border-cream-200 bg-white p-4 md:p-5 hover:shadow-md hover:border-olive-300 transition"
            >
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl bg-cream-100 overflow-hidden shrink-0">
                    {o.firstItemImage ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={o.firstItemImage} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">🫒</div>
                    )}
                  </div>
                  <div>
                    <div className="font-display font-bold text-ink-900" dir="ltr">{o.orderNumber}</div>
                    <div className="text-xs text-ink-400 mt-0.5">
                      {fmtDate(o.createdAt, lang)} · {o.seller.shopName}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <StatusBadge status={o.status} />
                  <div className="text-end">
                    <div className="font-display font-bold">{fmt(o.totalCents)}</div>
                    <div className="text-[11px] text-ink-400">{o.itemCount} {t("cart_items_count")}</div>
                  </div>
                </div>
              </div>
              <div className="text-sm text-ink-600 mt-3 border-t border-cream-100 pt-3 truncate">
                {d({ ar: o.firstItemNameAr, en: o.firstItemNameEn })}
                {o.itemCount > 1 && ` +${o.itemCount - 1}`}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
