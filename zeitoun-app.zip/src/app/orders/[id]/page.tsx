"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Modal, Select, Spinner, StatusBadge } from "@/components/ui";
import { ReviewForm } from "@/components/product-view";
import { api, errMsg } from "@/lib/api";
import { fmtDate, timeAgo } from "@/lib/utils";

const FLOW = ["pending", "confirmed", "preparing", "ready", "shipped", "in_transit", "delivered"] as const;
const SELLER_NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["ready"],
  ready: ["shipped"],
  shipped: ["in_transit"],
  in_transit: ["delivered"],
  delivered: ["refunded"],
};

interface OrderDetail {
  order: any;
  items: any[];
  shipment: any;
}

export default function OrderDetailPage() {
  const { t, d, fmt, me, lang } = useStore();
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<OrderDetail | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [reviewFor, setReviewFor] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    fetch(`/api/orders/${id}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setData(x))
      .catch(() => setData(null));
  };
  useEffect(load, [id]);

  if (!me) return <div className="max-w-3xl mx-auto px-4 py-10"><EmptyState icon={<span className="text-3xl">🔒</span>} title={t("login_required")} /></div>;
  if (!data)
    return (
      <div className="flex justify-center py-20">
        <Spinner className="w-8 h-8" />
      </div>
    );

  const { order, items, shipment } = data;
  const terminal = order.status === "cancelled" || order.status === "refunded";
  const curIdx = FLOW.indexOf(order.status as (typeof FLOW)[number]);

  const eventAt = (status: string) => (shipment?.events ?? []).find((e: any) => e.status === status);

  const changeStatus = async (to: string) => {
    setBusy(true);
    try {
      await api(`/api/orders/${order.id}`, { method: "PATCH", body: { status: to } });
      load();
    } catch (e) {
      // ignore, state unchanged
    } finally {
      setBusy(false);
    }
  };

  const cancelOrder = async () => {
    setBusy(true);
    try {
      await api(`/api/orders/${order.id}`, { method: "PATCH", body: { status: "cancelled" } });
      setConfirmCancel(false);
      load();
    } catch {
      /* noop */
    } finally {
      setBusy(false);
    }
  };

  const allowedNext =
    me.role === "admin" ? Object.keys(SELLER_NEXT) : order.isSeller ? SELLER_NEXT[order.status] ?? [] : [];

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-6">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900" dir="ltr">{order.orderNumber}</h1>
          <p className="text-sm text-ink-400 mt-1">
            {t("orders_placed")} {fmtDate(order.createdAt, lang)} · {order.seller.shopName}
          </p>
        </div>
        <StatusBadge status={order.status} />
      </div>

      <div className="grid lg:grid-cols-[1fr_340px] gap-6 items-start">
        <div className="space-y-5">
          {/* timeline */}
          <section className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-4">{t("orders_timeline")}</h2>
            {terminal ? (
              <div className="flex items-center gap-3 rounded-xl bg-clay-50 border border-clay-200 p-4 text-sm font-bold text-clay-700">
                <span className="text-xl">{order.status === "cancelled" ? "✕" : "↩"}</span>
                {t(`st_${order.status}`)}
              </div>
            ) : (
              <ol className="relative">
                {FLOW.map((s, i) => {
                  const done = i <= curIdx;
                  const ev = eventAt(s);
                  return (
                    <li key={s} className="flex gap-3.5 pb-5 last:pb-0">
                      <div className="flex flex-col items-center">
                        <span
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                            done ? "bg-olive-700 text-cream-50" : "bg-cream-100 text-ink-300"
                          }`}
                        >
                          {done ? "✓" : i + 1}
                        </span>
                        {i < FLOW.length - 1 && <span className={`w-0.5 flex-1 mt-1 ${done && i < curIdx ? "bg-olive-600" : "bg-cream-200"}`} />}
                      </div>
                      <div className="pt-1">
                        <div className={`text-sm font-bold ${done ? "text-ink-900" : "text-ink-300"}`}>{t(`st_${s}`)}</div>
                        {ev && <div className="text-[11px] text-ink-400 mt-0.5">{timeAgo(ev.at, lang)}</div>}
                      </div>
                    </li>
                  );
                })}
              </ol>
            )}
          </section>

          {/* items */}
          <section className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-4">{t("orders_items")}</h2>
            <div className="divide-y divide-cream-100">
              {items.map((it) => (
                <div key={it.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="w-14 h-14 rounded-xl bg-cream-100 overflow-hidden shrink-0">
                    {it.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={it.image} alt="" className="w-full h-full object-cover" />
                    ) : null}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-ink-900 truncate">{d({ ar: it.productNameAr, en: it.productNameEn })}</div>
                    <div className="text-xs text-ink-400">×{it.quantity} · {fmt(it.priceCents)}</div>
                  </div>
                  {order.status === "delivered" && order.isOwner && (
                    <Btn variant="outline" onClick={() => setReviewFor(it.productId)} className="!px-3 !py-1.5 !text-xs">
                      {t("orders_review")}
                    </Btn>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* status update (seller/admin) */}
          {(order.isSeller || me.role === "admin") && allowedNext.length > 0 && (
            <section className="rounded-2xl border border-olive-200 bg-olive-50/60 p-5">
              <h2 className="font-bold text-ink-900 mb-3">{t("sd_update_status")}</h2>
              <div className="flex flex-wrap gap-2">
                {allowedNext.map((s) => (
                  <Btn key={s} variant={s === "cancelled" ? "danger" : "primary"} disabled={busy} onClick={() => changeStatus(s)}>
                    → {t(`st_${s}`)}
                  </Btn>
                ))}
              </div>
            </section>
          )}

          {/* cancel (customer) */}
          {order.isOwner && !terminal && (order.status === "pending" || order.status === "confirmed") && (
            <section className="rounded-2xl border border-cream-200 bg-white p-5">
              {!confirmCancel ? (
                <Btn variant="danger" onClick={() => setConfirmCancel(true)}>{t("orders_cancel")}</Btn>
              ) : (
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="text-sm font-bold text-clay-700">{t("orders_cancel_hint")}</span>
                  <Btn variant="danger" disabled={busy} onClick={cancelOrder}>{t("confirm")}</Btn>
                  <Btn variant="ghost" onClick={() => setConfirmCancel(false)}>{t("cancel")}</Btn>
                </div>
              )}
            </section>
          )}
        </div>

        {/* side: tracking + address + payment */}
        <div className="space-y-5">
          <section className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-3">🚚 {t("orders_eta")}</h2>
            {shipment?.trackingNumber ? (
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-ink-400">{t("orders_tracking")}</span>
                  <b dir="ltr">{shipment.trackingNumber}</b>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-400">{t("orders_carrier")}</span>
                  <b>{shipment.carrier}</b>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-400">{t("orders_eta")}</span>
                  <b>{shipment.eta}</b>
                </div>
              </div>
            ) : (
              <p className="text-sm text-ink-400">{t("orders_no_tracking")}</p>
            )}
          </section>

          <section className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-3">{t("orders_address")}</h2>
            <div className="text-sm text-ink-700 leading-relaxed">
              <b>{order.address.fullName}</b>
              <br />
              {order.address.addressLine}
              <br />
              {order.address.city}, {order.address.state && `${order.address.state}, `}{order.address.country}
              <br />
              {order.address.postalCode} · {order.address.phone}
            </div>
          </section>

          <section className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-3">{t("orders_payment")}</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-ink-400">{t("subtotal")}</span><b>{fmt(order.subtotalCents)}</b></div>
              {order.discountCents > 0 && (
                <div className="flex justify-between text-olive-700"><span>{t("discount")}</span><b>− {fmt(order.discountCents)}</b></div>
              )}
              <div className="flex justify-between"><span className="text-ink-400">{t("shipping_fee")}</span><b>{fmt(order.shippingCents)}</b></div>
              <div className="flex justify-between border-t border-cream-200 pt-2"><span className="font-bold">{t("total")}</span><b className="font-display text-lg">{fmt(order.totalCents)}</b></div>
              <div className="text-[11px] text-ink-400 pt-1">
                {order.payment?.provider === "mock_cod" ? t("co_cod") : `${t("co_pay_mock")}${order.payment?.last4 ? ` ····${order.payment.last4}` : ""}`}
              </div>
            </div>
          </section>
        </div>
      </div>

      <Modal open={reviewFor !== null} onClose={() => setReviewFor(null)} title={t("p_write_review")}>
        {reviewFor !== null && (
          <ReviewForm
            productId={reviewFor}
            onDone={() => setReviewFor(null)}
            fields={[
              { key: "rating", label: t("p_overall") },
              { key: "qualityRating", label: t("p_quality") },
              { key: "packagingRating", label: t("p_packaging") },
              { key: "shippingRating", label: t("p_speed") },
            ]}
            commentAr={lang === "ar"}
          />
        )}
      </Modal>
    </div>
  );
}
