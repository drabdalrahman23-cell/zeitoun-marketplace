"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store";
import { Btn, EmptyState, ProductCard, Spinner } from "@/components/ui";
import type { ProductView } from "@/lib/types";

export default function FavoritesPage() {
  const { t, me } = useStore();
  const [items, setItems] = useState<ProductView[] | null>(null);

  useEffect(() => {
    if (!me) return;
    fetch("/api/favorites", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setItems(d?.items ?? []))
      .catch(() => setItems([]));
  }, [me]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-6">{t("fav_title")}</h1>
      {!me ? (
        <EmptyState icon={<span className="text-3xl">🤍</span>} title={t("login_required")} />
      ) : items === null ? (
        <div className="flex justify-center py-16"><Spinner className="w-8 h-8" /></div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-current" strokeWidth="1.6">
              <path d="M12 21s-7.5-4.8-9.5-9.2C.9 8.4 3 5 6.4 5c2 0 3.4 1 4.1 2.2h3C14.2 6 15.6 5 17.6 5 21 5 23.1 8.4 21.5 11.8 19.5 16.2 12 21 12 21z" />
            </svg>
          }
          title={t("fav_empty")}
          hint={t("fav_empty_hint")}
          action={<Link href="/products"><Btn>{t("go_shop")}</Btn></Link>}
        />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {items.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      )}
    </div>
  );
}
