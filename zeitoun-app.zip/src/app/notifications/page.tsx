"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Spinner } from "@/components/ui";
import { timeAgo } from "@/lib/utils";

interface Notif {
  id: number;
  type: string;
  titleAr: string;
  titleEn: string;
  bodyAr: string | null;
  bodyEn: string | null;
  link: string | null;
  readAt: string | null;
  createdAt: string;
}

export default function NotificationsPage() {
  const { t, d, me, lang } = useStore();
  const router = useRouter();
  const [items, setItems] = useState<Notif[] | null>(null);
  const [unread, setUnread] = useState(0);

  const load = () => {
    fetch("/api/notifications", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => {
        if (x) {
          setItems(x.items);
          setUnread(x.unread);
        }
      })
      .catch(() => setItems([]));
  };
  useEffect(() => {
    if (!me) router.replace("/auth/login");
    else load();
  }, [me, router]);

  const markRead = async (id: number) => {
    await fetch("/api/notifications", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) }).catch(() => {});
    load();
  };

  const markAll = async () => {
    await fetch("/api/notifications", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ all: true }) }).catch(() => {});
    load();
  };

  const open = async (n: Notif) => {
    if (!n.readAt) await markRead(n.id);
    if (n.link) router.push(n.link);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">{t("notifs_title")}</h1>
        {unread > 0 && (
          <Btn variant="outline" onClick={markAll}>{t("notifs_all")} ({unread})</Btn>
        )}
      </div>
      {!me ? null : items === null ? (
        <div className="flex justify-center py-16"><Spinner className="w-8 h-8" /></div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-current" strokeWidth="1.6">
              <path d="M18 9a6 6 0 10-12 0c0 6-2.5 7-2.5 7h17S18 15 18 9zM10.3 20a2 2 0 003.4 0" />
            </svg>
          }
          title={t("notifs_empty")}
          hint={t("notifs_empty_hint")}
        />
      ) : (
        <div className="space-y-2.5">
          {items.map((n) => (
            <button
              key={n.id}
              onClick={() => open(n)}
              className={`w-full text-start rounded-2xl border p-4 transition ${n.readAt ? "border-cream-200 bg-white" : "border-olive-300 bg-olive-50/70 shadow-sm"}`}
            >
              <div className="flex items-start gap-3">
                <span className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${n.readAt ? "bg-cream-300" : "bg-olive-600"}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold text-ink-900">{d({ ar: n.titleAr, en: n.titleEn })}</div>
                  {d({ ar: n.bodyAr, en: n.bodyEn }) && <div className="text-sm text-ink-600 mt-0.5">{d({ ar: n.bodyAr, en: n.bodyEn })}</div>}
                  <div className="text-[11px] text-ink-300 mt-1.5">{timeAgo(n.createdAt, lang)}</div>
                </div>
                {n.link && <Link href={n.link} onClick={(e) => e.stopPropagation()} className="text-xs font-bold text-olive-700 hover:underline shrink-0 mt-0.5">→</Link>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
