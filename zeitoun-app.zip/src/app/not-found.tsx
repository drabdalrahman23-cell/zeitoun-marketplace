"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { Btn } from "@/components/ui";

export default function NotFound() {
  const { t } = useStore();
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <div className="text-6xl mb-4">🫒</div>
      <h1 className="font-display text-3xl font-bold text-ink-900">{t("nf_title")}</h1>
      <p className="text-ink-400 mt-2">{t("nf_sub")}</p>
      <Link href="/" className="inline-block mt-6">
        <Btn>{t("nf_home")}</Btn>
      </Link>
    </div>
  );
}
