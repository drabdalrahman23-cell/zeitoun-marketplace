"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Field, Modal, Spinner, TextArea } from "@/components/ui";
import { api, errMsg } from "@/lib/api";
import { timeAgo } from "@/lib/utils";

interface Conv {
  id: number;
  sellerId: number;
  shopName: string;
  buyerName: string;
  lastBody: string | null;
  lastAt: string | null;
  unread: number;
}

export default function MessagesPage() {
  const { t, me, lang, toast } = useStore();
  const router = useRouter();
  const [convs, setConvs] = useState<Conv[] | null>(null);
  const [active, setActive] = useState<Conv | null>(null);
  const [msgs, setMsgs] = useState<{ id: number; senderId: number; body: string; createdAt: string }[]>([]);
  const [text, setText] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!me) router.replace("/auth/login");
  }, [me, router]);

  useEffect(() => {
    if (!me) return;
    fetch("/api/messages", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setConvs(d?.items ?? []))
      .catch(() => setConvs([]));
  }, [me]);

  useEffect(() => {
    if (!active) return;
    let alive = true;
    const load = () =>
      fetch(`/api/messages/thread?cid=${active.id}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (alive && d) setMsgs(d.messages);
        })
        .catch(() => {});
    load();
    const iv = setInterval(load, 4000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [active]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  if (!me) return null;

  const send = async () => {
    if (!text.trim() || !active) return;
    try {
      await api("/api/messages", { body: { conversationId: active.id, body: text } });
      setText("");
      fetch(`/api/messages/thread?cid=${active.id}`, { cache: "no-store" }).then((r) => r.json()).then((d) => d && setMsgs(d.messages)).catch(() => {});
      toast(t("t_msg_sent"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const report = async () => {
    if (!reason.trim() || !active) return;
    try {
      await api("/api/reports", { body: { targetType: "user", targetId: active.sellerId, reason } });
      setReportOpen(false);
      setReason("");
      toast(t("msg_reported"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const isSeller = me.role !== "customer";

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-6">{t("msg_title")}</h1>
      {!convs ? (
        <div className="flex justify-center py-16"><Spinner className="w-8 h-8" /></div>
      ) : (
        <div className="grid md:grid-cols-[300px_1fr] gap-4 rounded-3xl border border-cream-200 bg-white overflow-hidden md:min-h-[520px]">
          {/* list */}
          <div className="border-b md:border-b-0 md:border-e border-cream-200 divide-y divide-cream-100 overflow-y-auto max-h-[240px] md:max-h-[520px]">
            {convs.length === 0 ? (
              <div className="p-6 text-center">
                <p className="font-bold text-ink-700 text-sm">{t("msg_empty")}</p>
                <p className="text-xs text-ink-400 mt-1">{t("msg_empty_hint")}</p>
              </div>
            ) : (
              convs.map((c) => (
                <button key={c.id} onClick={() => setActive(c)} className={`w-full text-start p-4 hover:bg-cream-100/60 transition ${active?.id === c.id ? "bg-olive-50" : ""}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-sm text-ink-900 truncate">{isSeller ? c.buyerName : c.shopName}</span>
                    {c.unread > 0 && <span className="min-w-5 h-5 px-1.5 rounded-full bg-olive-700 text-white text-[10px] font-bold flex items-center justify-center">{c.unread}</span>}
                  </div>
                  <div className="text-xs text-ink-400 truncate mt-0.5">{c.lastBody ?? "—"}</div>
                  <div className="text-[10px] text-ink-300 mt-1">{c.lastAt ? timeAgo(c.lastAt, lang) : ""}</div>
                </button>
              ))
            )}
          </div>

          {/* thread */}
          <div className="flex flex-col">
            {!active ? (
              <div className="flex-1 flex items-center justify-center">
                <p className="text-sm text-ink-400">{t("msg_no_conv")}</p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between px-4 py-3 border-b border-cream-100">
                  <div className="font-bold text-sm text-ink-900">{isSeller ? active.buyerName : active.shopName}</div>
                  <button onClick={() => setReportOpen(true)} className="text-[11px] text-ink-400 hover:text-clay-600 underline underline-offset-2">
                    {t("msg_report")}
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[380px]">
                  {msgs.map((m) => {
                    const mine = m.senderId === me.id;
                    return (
                      <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 text-sm ${mine ? "bg-olive-700 text-cream-50 rounded-ee-sm" : "bg-cream-100 text-ink-800 rounded-ss-sm"}`}>
                          {m.body}
                          <div className={`text-[10px] mt-1 ${mine ? "text-cream-200/70" : "text-ink-300"}`}>{timeAgo(m.createdAt, lang)}</div>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={endRef} />
                </div>
                <div className="p-3 border-t border-cream-100 flex gap-2">
                  <input
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && send()}
                    placeholder={t("msg_ph")}
                    className="flex-1 rounded-xl border border-cream-300 px-3.5 py-2.5 text-sm outline-none focus:border-olive-500"
                  />
                  <Btn onClick={send}>{t("send")}</Btn>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title={t("msg_report")}>
        <Field label={t("msg_report_reason")}>
          <TextArea value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
        <Btn onClick={report} className="w-full mt-4">{t("send")}</Btn>
      </Modal>
    </div>
  );
}
