import type { Metadata } from "next";
import { notFound } from "next/navigation";
import QRCode from "qrcode";
import { db } from "@/db";
import { adoptionPrograms, adoptionUpdates, farmers, farmerSupportPrograms, oliveTrees, products, treeSeasons } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { latestUpdates, toFarmerFull, toProgramView, toTreeFull, toUpdateView } from "@/lib/adoption";
import { TreePageClient } from "@/components/adoption-pages";

export const dynamic = "force-dynamic";

async function load(code: string) {
  const rows = await db
    .select({ t: oliveTrees, f: farmers })
    .from(oliveTrees)
    .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
    .where(eq(oliveTrees.treeCode, code.toUpperCase()));
  const row = rows[0];
  if (!row || !row.t.verified) return null;

  const [progRows, prodRows, updRows] = await Promise.all([
    db
      .select({ p: adoptionPrograms, fsp: farmerSupportPrograms })
      .from(farmerSupportPrograms)
      .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
      .where(and(eq(farmerSupportPrograms.farmerId, row.f.id), eq(farmerSupportPrograms.allowed, true), eq(adoptionPrograms.active, true)))
      .orderBy(asc(adoptionPrograms.sortOrder)),
    row.f.sellerId
      ? db.select().from(products).where(and(eq(products.sellerId, row.f.sellerId), eq(products.status, "active"))).orderBy(desc(products.salesCount)).limit(8)
      : Promise.resolve([]),
    db
      .select({ up: adoptionUpdates, t: oliveTrees })
      .from(adoptionUpdates)
      .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
      .where(and(eq(adoptionUpdates.farmerId, row.f.id), eq(adoptionUpdates.published, true)))
      .orderBy(desc(adoptionUpdates.createdAt))
      .limit(12),
  ]);

  let qrDataUrl = "";
  try {
    const base = process.env.NEXT_PUBLIC_SITE_URL || "";
    qrDataUrl = await QRCode.toDataURL(`${base}/trees/${row.t.treeCode}`, {
      margin: 1,
      width: 300,
      color: { dark: "#333d21", light: "#faf8f2" },
    });
  } catch {
    qrDataUrl = "";
  }

  return {
    tree: toTreeFull({ ...row.f, ...row.t }),
    farmer: toFarmerFull(row.f),
    programs: progRows.map((r) => ({
      ...toProgramView(r.p),
      priceCents: r.fsp.allowPriceOverride && r.fsp.customPriceCents ? r.fsp.customPriceCents : r.p.priceCents,
    })),
    products: prodRows.map((p) => ({
      id: p.id,
      slug: p.slug,
      nameAr: p.nameAr,
      nameEn: p.nameEn,
      priceCents: p.priceCents,
      images: p.images,
      stock: p.stock,
      weightGrams: p.weightGrams,
    })),
    updates: updRows
      .filter((r) => r.up.treeId === row.t.id || r.up.treeId === null)
      .map((r) => toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null })),
    qrDataUrl,
  };
}

export async function generateMetadata({ params }: { params: Promise<{ code: string }> }): Promise<Metadata> {
  const { code } = await params;
  const data = await load(code).catch(() => null);
  if (!data) return { title: "Olive tree | Zeitoun" };
  return {
    title: `${data.tree.nameEn || data.tree.treeCode} — Adopt an olive tree`,
    description: (data.tree.storyEn ?? data.tree.storyAr ?? "").slice(0, 160),
    openGraph: {
      title: `${data.tree.nameEn || data.tree.treeCode} | Zeitoun`,
      description: (data.tree.storyEn ?? "").slice(0, 160),
      images: data.tree.images[0] ? [data.tree.images[0]] : [],
    },
  };
}

export default async function TreePage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const data = await load(code).catch(() => null);
  if (!data) notFound();
  return <TreePageClient {...data} />;
}
