"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, Field, Select, Spinner, TextInput } from "@/components/ui";
import type { CountryView } from "@/lib/types";

interface Address {
  fullName: string;
  phone: string;
  country: string;
  countryCode: string;
  state: string;
  city: string;
  addressLine: string;
  postalCode: string;
}

const EMPTY_ADDR: Address = { fullName: "", phone: "", country: "", countryCode: "US", state: "", city: "", addressLine: "", postalCode: "" };

export default function CheckoutPage() {
  const { t, d, fmt, cart, clearCart, cartSubtotal, me, lang, toast } = useStore();
  const router = useRouter();

  const [step, setStep] = useState(1);
  const [countries, setCountries] = useState<CountryView[]>([]);
  const [methods, setMethods] = useState<{ id: number; nameAr: string; nameEn: string; daysMin: number; daysMax: number }[]>([]);
  const [savedAddrs, setSavedAddrs] = useState<any[]>([]);
  const [addr, setAddr] = useState<Address>(EMPTY_ADDR);
  const [useSaved, setUseSaved] = useState<number | "new">(savedAddrs.length ? "new" : "new");
  const [saveAddr, setSaveAddr] = useState(false);
  const [methodId, setMethodId] = useState(1);
  const [payment, setPayment] = useState<"card" | "cod">("card");
  const [card, setCard] = useState({ name: "", number: "", exp: "", cvc: "" });
  const [offer, setOffer] = useState("");
  const [offerApplied, setOfferApplied] = useState(false);
  const [quotes, setQuotes] = useState<Record<number, { cents: number; daysMin: number; daysMax: number }>>({});
  const [placing, setPlacing] = useState(false);
  const [orderNumbers, setOrderNumbers] = useState<string[]>([]);
  const [paidTotal, setPaidTotal] = useState(0);
  const [error, setError] = useState<{ ar: string; en: string } | null>(null);

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => (r.ok ? r.json() : null))
      .then((m) => {
        if (m?.countries) setCountries(m.countries);
        if (m?.shippingMethods) setMethods(m.shippingMethods);
      })
      .catch(() => {});
    if (me)
      fetch("/api/addresses", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((a) => a?.items && setSavedAddrs(a.items))
        .catch(() => {});
  }, [me]);

  useEffect(() => {
    if (!me) router.replace("/auth/login?next=/checkout");
    else if (!cart.length && step < 5) router.replace("/cart");
  }, [me, cart.length, step, router]);

  /* group by seller */
  const groups = useMemo(() => {
    const m = new Map<number, { sellerId: number; shopName: string; items: typeof cart; weight: number; subtotal: number }>();
    for (const it of cart) {
      const g = m.get(it.sellerId) ?? { sellerId: it.sellerId, shopName: it.shopName, items: [], weight: 0, subtotal: 0 };
      g.items.push(it);
      g.weight += it.weightGrams * it.qty;
      g.subtotal += it.priceCents * it.qty;
      m.set(it.sellerId, g);
    }
    return [...m.values()];
  }, [cart]);

  /* shipping quotes per seller group */
  useEffect(() => {
    if (!addr.countryCode || !countries.length || groups.length === 0) return;
    let alive = true;
    (async () => {
      const out: Record<number, { cents: number; daysMin: number; daysMax: number }> = {};
      for (const g of groups) {
        const r = await fetch("/api/shipping", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ countryCode: addr.countryCode, weightGrams: g.weight, methodId }),
        }).catch(() => null);
        if (r?.ok) {
          const q = await r.json();
          out[g.sellerId] = { cents: q.quoteCents, daysMin: q.daysMin, daysMax: q.daysMax };
        }
      }
      if (alive) setQuotes(out);
    })();
    return () => {
      alive = false;
    };
  }, [addr.countryCode, methodId, groups, countries.length]);

  const totalShipping = Object.values(quotes).reduce((s, q) => s + q.cents, 0);
  const grandTotal = cartSubtotal + totalShipping;
  const eta = useMemo(() => {
    const days = Object.values(quotes);
    if (!days.length) return "—";
    const min = Math.min(...days.map((x) => x.daysMin));
    const max = Math.max(...days.map((x) => x.daysMax));
    return `${new Date(Date.now() + min * 86400000).toLocaleDateString(lang === "ar" ? "ar" : "en-US", { month: "short", day: "numeric" })} – ${new Date(Date.now() + max * 86400000).toLocaleDateString(lang === "ar" ? "ar" : "en-US", { month: "short", day: "numeric" })}`;
  }, [quotes, lang]);

  const selectSaved = (id: number) => {
    const a = savedAddrs.find((x) => x.id === id);
    if (!a) return;
    setUseSaved(id);
    setAddr({ fullName: a.fullName, phone: a.phone, country: a.country, countryCode: a.countryCode, state: a.state ?? "", city: a.city, addressLine: a.addressLine, postalCode: a.postalCode });
  };

  const validAddr = addr.fullName && addr.phone && addr.countryCode && addr.city && addr.addressLine && addr.postalCode;

  const validCard =
    payment === "cod" ||
    (card.name.trim().length > 1 && card.number.replace(/\s/g, "").length >= 12 && /^\d{2}\/\d{2}$/.test(card.exp) && card.cvc.length >= 3);

  const placeOrder = async () => {
    if (!validAddr) return setError({ ar: "أكمل بيانات العنوان", en: "Complete the shipping address" });
    if (!validCard) return setError({ ar: "بيانات البطاقة غير صالحة", en: "Card details are invalid" });
    setPlacing(true);
    setError(null);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map((i) => ({ productId: i.productId, quantity: i.qty })),
          address: addr,
          saveAddress: saveAddr,
          methodId,
          offerCode: offerApplied ? offer : undefined,
          paymentProvider: payment,
          cardLast4: payment === "card" ? card.number.replace(/\D/g, "").slice(-4) : undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error ?? { ar: t("error_generic"), en: "Error" });
        return;
      }
      if (saveAddr)
        await fetch("/api/addresses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...addr, label: "Home" }),
        }).catch(() => {});
      setOrderNumbers(data.orderNumbers);
      setPaidTotal(data.totalCents);
      clearCart();
      setStep(5);
      window.scrollTo(0, 0);
    } catch {
      setError({ ar: t("error_generic"), en: "Network error" });
    } finally {
      setPlacing(false);
    }
  };

  const steps = [t("co_step1"), t("co_step2"), t("co_step3"), t("co_step4"), t("co_step5")];

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-6">{t("co_title")}</h1>

      {/* stepper */}
      <div className="flex items-center gap-1.5 mb-8 overflow-x-auto no-scrollbar">
        {steps.map((s, i) => (
          <div key={i} className="flex items-center gap-1.5 shrink-0">
            <div
              className={`flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-bold ${
                step === i + 1 ? "bg-olive-700 text-cream-50" : step > i + 1 ? "bg-olive-100 text-olive-800" : "bg-cream-100 text-ink-400"
              }`}
            >
              <span className={`w-4.5 h-4.5 rounded-full text-[10px] flex items-center justify-center ${step === i + 1 ? "bg-cream-50/20" : "bg-white"}`}>
                {step > i + 1 ? "✓" : i + 1}
              </span>
              {s}
            </div>
            {i < steps.length - 1 && <div className="w-4 h-px bg-cream-300" />}
          </div>
        ))}
      </div>

      {step < 5 && (
        <div className="grid lg:grid-cols-[1fr_300px] gap-6 items-start">
          <div className="rounded-2xl border border-cream-200 bg-white p-5 md:p-6">
            {/* STEP 1: address */}
            {step === 1 && (
              <div className="space-y-4">
                <h2 className="font-bold text-lg text-ink-900">{t("co_step1")}</h2>
                {savedAddrs.length > 0 && (
                  <div className="space-y-2">
                    {savedAddrs.map((a) => (
                      <button
                        key={a.id}
                        onClick={() => selectSaved(a.id)}
                        className={`w-full text-start rounded-xl border p-3.5 text-sm transition ${useSaved === a.id ? "border-olive-600 bg-olive-50" : "border-cream-300 hover:border-olive-300"}`}
                      >
                        <span className="font-bold text-ink-900">{a.fullName}</span>
                        <span className="text-ink-400 block mt-0.5">
                          {a.addressLine}, {a.city}, {a.country} {a.postalCode} · {a.phone}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
                <div className="pt-2 border-t border-cream-100 grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  <Field label={t("co_full_name")}>
                    <TextInput value={addr.fullName} onChange={(e) => setAddr({ ...addr, fullName: e.target.value })} />
                  </Field>
                  <Field label={t("co_phone")}>
                    <TextInput dir="ltr" value={addr.phone} onChange={(e) => setAddr({ ...addr, phone: e.target.value })} placeholder="+1 ..." />
                  </Field>
                  <Field label={t("co_country")}>
                    <Select
                      value={addr.countryCode}
                      onChange={(e) => {
                        const c = countries.find((x) => x.code === e.target.value);
                        setAddr({ ...addr, countryCode: e.target.value, country: c ? d({ ar: c.nameAr, en: c.nameEn }) : "" });
                      }}
                    >
                      {countries.map((c) => (
                        <option key={c.code} value={c.code}>{d({ ar: c.nameAr, en: c.nameEn })}</option>
                      ))}
                    </Select>
                  </Field>
                  <Field label={`${t("co_state")} (${t("optional")})`}>
                    <TextInput value={addr.state} onChange={(e) => setAddr({ ...addr, state: e.target.value })} />
                  </Field>
                  <Field label={t("co_city")}>
                    <TextInput value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} />
                  </Field>
                  <Field label={t("co_postal")}>
                    <TextInput dir="ltr" value={addr.postalCode} onChange={(e) => setAddr({ ...addr, postalCode: e.target.value })} />
                  </Field>
                  <div className="md:col-span-2">
                    <Field label={t("co_address")}>
                      <TextInput value={addr.addressLine} onChange={(e) => setAddr({ ...addr, addressLine: e.target.value })} />
                    </Field>
                  </div>
                </div>
                <label className="flex items-center gap-2 text-sm font-bold text-ink-700 cursor-pointer">
                  <input type="checkbox" checked={saveAddr} onChange={(e) => setSaveAddr(e.target.checked)} className="w-4.5 h-4.5 accent-olive-700" />
                  {t("co_save_address")}
                </label>
                {error && <p className="text-sm text-clay-600 font-bold">{lang === "ar" ? error.ar : error.en}</p>}
                <Btn disabled={!validAddr} onClick={() => setStep(2)} className="w-full md:w-auto">{t("next")}</Btn>
              </div>
            )}

            {/* STEP 2: shipping method */}
            {step === 2 && (
              <div className="space-y-4">
                <h2 className="font-bold text-lg text-ink-900">{t("co_step2")}</h2>
                <p className="text-sm text-ink-400">{t("co_method_sub")}</p>
                {methods.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMethodId(m.id)}
                    className={`w-full text-start rounded-xl border p-4 transition ${methodId === m.id ? "border-olive-600 bg-olive-50" : "border-cream-300 hover:border-olive-300"}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-ink-900">{d({ ar: m.nameAr, en: m.nameEn })}</span>
                      <span className="text-sm font-bold text-olive-700">{m.daysMin}–{m.daysMax} {t("p_days")}</span>
                    </div>
                  </button>
                ))}
                {groups.map((g) => {
                  const q = quotes[g.sellerId];
                  return (
                    <div key={g.sellerId} className="rounded-xl bg-cream-100/70 p-3.5 text-sm flex items-center justify-between">
                      <span className="font-bold text-ink-700">{g.shopName}</span>
                      <span className="font-bold text-ink-900">{q ? fmt(q.cents) : "…"}</span>
                    </div>
                  );
                })}
                {error && <p className="text-sm text-clay-600 font-bold">{lang === "ar" ? error.ar : error.en}</p>}
                <div className="flex gap-2">
                  <Btn variant="ghost" onClick={() => setStep(1)}>{t("back")}</Btn>
                  <Btn onClick={() => setStep(3)} className="flex-1">{t("next")}</Btn>
                </div>
              </div>
            )}

            {/* STEP 3: payment */}
            {step === 3 && (
              <div className="space-y-4">
                <h2 className="font-bold text-lg text-ink-900">{t("co_step3")}</h2>
                <div className="rounded-xl bg-gold-300/20 border border-gold-300/50 p-3.5 text-xs text-ink-700 leading-relaxed">{t("co_mock_note")}</div>
                <div className="space-y-2">
                  <button
                    onClick={() => setPayment("card")}
                    className={`w-full text-start rounded-xl border p-3.5 text-sm font-bold flex items-center gap-3 transition ${payment === "card" ? "border-olive-600 bg-olive-50 text-ink-900" : "border-cream-300 text-ink-600"}`}
                  >
                    <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.8"><rect x="2.5" y="5" width="19" height="14" rx="2.5" /><path d="M2.5 10h19" /></svg>
                    {t("co_card_number")}
                  </button>
                  <button
                    onClick={() => setPayment("cod")}
                    className={`w-full text-start rounded-xl border p-3.5 text-sm font-bold flex items-center gap-3 transition ${payment === "cod" ? "border-olive-600 bg-olive-50 text-ink-900" : "border-cream-300 text-ink-600"}`}
                  >
                    <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.8"><rect x="3" y="6" width="18" height="12" rx="2" /><circle cx="12" cy="12" r="3" /></svg>
                    {t("co_cod")}
                  </button>
                </div>
                {payment === "card" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div className="md:col-span-2">
                      <Field label={t("co_card_name")}>
                        <TextInput value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} />
                      </Field>
                    </div>
                    <div className="md:col-span-2">
                      <Field label={t("co_card_number")} hint="4242 4242 4242 4242">
                        <TextInput dir="ltr" inputMode="numeric" value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value })} placeholder="4242 4242 4242 4242" />
                      </Field>
                    </div>
                    <Field label={t("co_card_exp")}>
                      <TextInput dir="ltr" value={card.exp} onChange={(e) => setCard({ ...card, exp: e.target.value })} placeholder="12/27" />
                    </Field>
                    <Field label={t("co_card_cvc")}>
                      <TextInput dir="ltr" inputMode="numeric" maxLength={4} value={card.cvc} onChange={(e) => setCard({ ...card, cvc: e.target.value })} placeholder="123" />
                    </Field>
                  </div>
                )}
                <p className="text-[11px] text-ink-400">{t("co_payment_sub")}</p>
                {error && <p className="text-sm text-clay-600 font-bold">{lang === "ar" ? error.ar : error.en}</p>}
                <div className="flex gap-2">
                  <Btn variant="ghost" onClick={() => setStep(2)}>{t("back")}</Btn>
                  <Btn disabled={!validCard} onClick={() => setStep(4)} className="flex-1">{t("next")}</Btn>
                </div>
              </div>
            )}

            {/* STEP 4: review */}
            {step === 4 && (
              <div className="space-y-5">
                <h2 className="font-bold text-lg text-ink-900">{t("co_step4")}</h2>
                <div>
                  <h3 className="text-sm font-bold text-ink-600 mb-2">{t("co_address")}</h3>
                  <p className="text-sm text-ink-800">
                    {addr.fullName} · {addr.phone}
                    <br />
                    {addr.addressLine}, {addr.city}, {addr.state && `${addr.state}, `}{addr.country} {addr.postalCode}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-ink-600 mb-2">{t("co_items")}</h3>
                  <div className="divide-y divide-cream-100 rounded-xl border border-cream-200">
                    {cart.map((i) => (
                      <div key={i.productId} className="flex items-center gap-3 p-3">
                        <div className="w-12 h-12 rounded-lg bg-cream-100 overflow-hidden shrink-0">
                          {i.image ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={i.image} alt="" className="w-full h-full object-cover" />
                          ) : null}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-bold text-ink-900 truncate">{d({ ar: i.nameAr, en: i.nameEn })}</div>
                          <div className="text-xs text-ink-400">{i.shopName} · ×{i.qty}</div>
                        </div>
                        <div className="text-sm font-bold">{fmt(i.priceCents * i.qty)}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <TextInput value={offer} onChange={(e) => setOffer(e.target.value.toUpperCase())} placeholder={t("co_discount")} dir="ltr" className="flex-1" />
                  <Btn variant="outline" disabled={offerApplied || !offer.trim()} onClick={() => setOfferApplied(true)}>
                    {t("co_apply")}
                  </Btn>
                </div>
                {offerApplied && <p className="text-xs font-bold text-olive-700">✓ {t("co_code_applied")}: {offer}</p>}
                {error && <p className="text-sm text-clay-600 font-bold">{lang === "ar" ? error.ar : error.en}</p>}
                <div className="flex gap-2">
                  <Btn variant="ghost" onClick={() => setStep(3)}>{t("back")}</Btn>
                  <Btn onClick={placeOrder} disabled={placing} className="flex-1">
                    {placing ? (
                      <>
                        <Spinner className="!w-4 !h-4 !text-white" /> {t("co_processing")}
                      </>
                    ) : (
                      <>
                        {t("co_place")} · {fmt(grandTotal)}
                      </>
                    )}
                  </Btn>
                </div>
              </div>
            )}
          </div>

          {/* summary sidebar */}
          <div className="rounded-2xl border border-cream-200 bg-white p-5">
            <h2 className="font-bold text-ink-900 mb-4">{t("cart_summary")}</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-ink-400">{t("subtotal")} ({cart.length})</span>
                <span className="font-bold">{fmt(cartSubtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-400">{t("shipping_fee")}</span>
                <span className="font-bold">{totalShipping ? fmt(totalShipping) : "…"}</span>
              </div>
              {offerApplied && (
                <div className="flex justify-between text-olive-700">
                  <span>{t("discount")}</span>
                  <span className="font-bold">− {offer}</span>
                </div>
              )}
            </div>
            <div className="border-t border-cream-200 mt-4 pt-4 flex justify-between items-center">
              <span className="font-bold">{t("total")}</span>
              <span className="font-display font-bold text-xl">{fmt(grandTotal)}</span>
            </div>
            <p className="text-xs text-ink-400 mt-2">{t("co_eta")}: <b>{eta}</b></p>
          </div>
        </div>
      )}

      {/* STEP 5: done */}
      {step === 5 && (
        <div className="max-w-xl mx-auto text-center anim-pop">
          <div className="w-20 h-20 mx-auto rounded-full bg-olive-700 text-cream-50 flex items-center justify-center text-4xl">✓</div>
          <h2 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mt-5">{t("co_done_title")}</h2>
          <p className="text-ink-400 mt-2">{t("co_done_sub")}</p>
          <div className="mt-6 rounded-2xl border border-cream-200 bg-white p-5">
            <div className="text-sm font-bold text-ink-600 mb-3">{t("co_order_numbers")}</div>
            <div className="space-y-2">
              {orderNumbers.map((n) => (
                <Link key={n} href="/orders" className="block font-display font-bold text-xl text-olive-800 hover:underline" dir="ltr">
                  {n}
                </Link>
              ))}
            </div>
            <div className="text-sm text-ink-400 mt-3">
              {t("total")}: <b className="text-ink-900">{fmt(paidTotal)}</b>
            </div>
          </div>
          <div className="flex gap-3 mt-6 justify-center flex-wrap">
            <Link href="/orders" className="rounded-xl bg-olive-700 text-cream-50 font-bold px-6 py-3 hover:bg-olive-800 transition">
              {t("track")}
            </Link>
            <Link href="/products" className="rounded-xl border border-olive-300 text-olive-800 font-bold px-6 py-3 hover:bg-olive-50 transition">
              {t("co_keep_shopping")}
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
