"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, Field, Select, Spinner, StatusBadge, TextArea, TextInput } from "@/components/ui";
import { SellerProducts } from "@/components/seller-products";
import { SellerTreesTab } from "@/components/seller-trees";
import { api, errMsg } from "@/lib/api";
import { fmtDate, timeAgo } from "@/lib/utils";

function BarChart({ data, fmt }: { data: { label: string; cents: number }[]; fmt: (c: number) => string }) {
  const max = Math.max(...data.map((x) => x.cents), 1);
  return (
    <div className="flex items-end gap-1.5 h-36">
      {data.map((x, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1 group" title={fmt(x.cents)}>
          <div className="w-full rounded-t-md bg-olive-600/80 group-hover:bg-olive-700 transition-all min-h-[3px]" style={{ height: `${(x.cents / max) * 100}%` }} />
          <span className="text-[9px] text-ink-300 font-bold truncate max-w-full">{x.label}</span>
        </div>
      ))}
    </div>
  );
}

const SELLER_NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["ready"],
  ready: ["shipped"],
  shipped: ["in_transit"],
  in_transit: ["delivered"],
  delivered: ["refunded"],
};

function SellerDashboardInner() {
  const { t, d, fmt, me, lang, toast } = useStore();
  const router = useRouter();
  const sp = useSearchParams();
  const tab = sp.get("tab") ?? "overview";
  const setTab = (x: string) => router.replace(`/dashboard/seller?tab=${x}`);

  const [stats, setStats] = useState<any | null>(null);
  const [orders, setOrders] = useState<any[] | null>(null);
  const [convs, setConvs] = useState<any[] | null>(null);
  const [activeConv, setActiveConv] = useState<number | null>(null);
  const [msgs, setMsgs] = useState<any[]>([]);
  const [text, setText] = useState("");
  const [profile, setProfile] = useState<any | null>(null);

  useEffect(() => {
    if (!me) router.replace("/auth/login");
    else if (me.role !== "seller" && me.role !== "admin") router.replace("/apply-seller");
  }, [me, router]);

  useEffect(() => {
    if (!me || (me.role !== "seller" && me.role !== "admin")) return;
    fetch("/api/seller/stats", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then(setStats).catch(() => {});
    fetch("/api/seller/status", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((s) => s && setProfile(s.seller)).catch(() => {});
  }, [me]);

  useEffect(() => {
    if (!me || tab !== "orders") return;
    fetch("/api/orders?scope=seller", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((x) => setOrders(x?.items ?? []))
      .catch(() => setOrders([]));
  }, [me, tab]);

  useEffect(() => {
    if (!me || tab !== "messages") return;
    fetch("/api/messages", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setConvs(x?.items ?? [])).catch(() => setConvs([]));
  }, [me, tab]);

  useEffect(() => {
    if (!me || !activeConv) return;
    let alive = true;
    const load = () =>
      fetch(`/api/messages/thread?cid=${activeConv}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((x) => alive && x && setMsgs(x.messages))
        .catch(() => {});
    load();
    const iv = setInterval(load, 4000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [me, activeConv]);

  if (!me || (me.role !== "seller" && me.role !== "admin")) return null;

  const changeStatus = async (orderId: number, to: string) => {
    try {
      await api(`/api/orders/${orderId}`, { method: "PATCH", body: { status: to } });
      toast(t("t_order_updated"));
      fetch("/api/orders?scope=seller", { cache: "no-store" }).then((r) => r.json()).then((x) => setOrders(x?.items ?? [])).catch(() => {});
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const sendMsg = async () => {
    if (!text.trim() || !activeConv) return;
    try {
      await api("/api/messages", { body: { conversationId: activeConv, body: text } });
      setText("");
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const saveProfile = async () => {
    try {
      await api("/api/seller", {
        method: "PUT",
        body: {
          shopName: profile.shopName,
          city: profile.city,
          region: profile.region,
          about: profile.about,
          story: profile.story,
          allowMessages: profile.allowMessages,
          images: profile.images,
        },
      });
      toast(t("t_saved"));
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  const tabs = [
    { id: "overview", label: t("sd_overview") },
    { id: "products", label: t("sd_products") },
    { id: "orders", label: t("sd_orders") },
    { id: "messages", label: t("sd_messages") },
    { id: "trees", label: t("ad_st_farmer") },
    { id: "profile", label: t("sd_profile") },
  ];

  const cards = [
    { label: t("sd_sales"), value: stats ? fmt(stats.totalSalesCents) : "—" },
    { label: t("sd_revenue"), value: stats ? fmt(stats.totalSalesCents) : "—" },
    { label: t("sd_orders_n"), value: stats?.totalOrders ?? "—" },
    { label: t("sd_pending"), value: stats?.pendingOrders ?? "—" },
    { label: t("sd_completed"), value: stats?.completedOrders ?? "—" },
    { label: t("sd_products_n"), value: stats ? `${stats.activeProducts}/${stats.productCount}` : "—" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-1">{t("sd_title")}</h1>
      {profile && <p className="text-sm text-ink-400 mb-5">{profile.shopName} · {profile.city ?? "Palestine"} · {t("member_since")} {fmtDate(profile.joinedAt, lang)}</p>}

      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
        {tabs.map((x) => (
          <button
            key={x.id}
            onClick={() => setTab(x.id)}
            className={`rounded-xl px-4 py-2 text-sm font-bold whitespace-nowrap transition ${tab === x.id ? "bg-olive-700 text-cream-50" : "bg-white border border-cream-300 text-ink-600 hover:border-olive-400"}`}
          >
            {x.label}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {cards.map((c, i) => (
              <div key={i} className="rounded-2xl border border-cream-200 bg-white p-4">
                <div className="text-[11px] font-bold text-ink-400">{c.label}</div>
                <div className="font-display text-lg md:text-xl font-bold text-ink-900 mt-1 truncate">{c.value}</div>
              </div>
            ))}
          </div>
          <div className="grid lg:grid-cols-2 gap-5">
            <div className="rounded-2xl border border-cream-200 bg-white p-5">
              <h3 className="font-bold text-ink-900 mb-4 text-sm">{t("sd_chart_days")}</h3>
              <BarChart data={stats?.byDay ?? []} fmt={fmt} />
            </div>
            <div className="rounded-2xl border border-cream-200 bg-white p-5">
              <h3 className="font-bold text-ink-900 mb-4 text-sm">{t("sd_chart_months")}</h3>
              <BarChart data={stats?.byMonth ?? []} fmt={fmt} />
            </div>
          </div>
          {!stats && <div className="flex justify-center py-8"><Spinner className="w-8 h-8" /></div>}
        </div>
      )}

      {tab === "products" && <SellerProducts />}

      {tab === "orders" && (
        <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
          {!orders ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : orders.length === 0 ? (
            <EmptyState icon={<span className="text-3xl">📦</span>} title={t("sd_no_orders")} />
          ) : (
            <table className="w-full text-sm min-w-[720px]">
              <thead>
                <tr className="border-b border-cream-200 text-xs text-ink-400">
                  <th className="text-start p-3 font-bold">{t("sd_order")}</th>
                  <th className="text-start p-3 font-bold">{t("sd_customer")}</th>
                  <th className="text-start p-3 font-bold">{t("total")}</th>
                  <th className="text-start p-3 font-bold">{t("status")}</th>
                  <th className="text-start p-3 font-bold">{t("date")}</th>
                  <th className="p-3" />
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id} className="border-b border-cream-100 last:border-0">
                    <td className="p-3">
                      <Link href={`/orders/${o.id}`} className="font-display font-bold text-ink-900 hover:underline" dir="ltr">{o.orderNumber}</Link>
                      <div className="text-[11px] text-ink-400">{o.itemCount} {t("cart_items_count")}</div>
                    </td>
                    <td className="p-3">
                      <div className="font-bold text-ink-800">{o.customerName}</div>
                      <div className="text-[11px] text-ink-400">{o.address?.country}</div>
                    </td>
                    <td className="p-3 font-bold">{fmt(o.totalCents)}</td>
                    <td className="p-3"><StatusBadge status={o.status} /></td>
                    <td className="p-3 text-ink-400">{fmtDate(o.createdAt, lang)}</td>
                    <td className="p-3">
                      <div className="flex gap-1.5 flex-wrap justify-end">
                        {(SELLER_NEXT[o.status] ?? []).map((s) => (
                          <button key={s} onClick={() => changeStatus(o.id, s)}
                            className={`text-[11px] font-bold rounded-lg px-2.5 py-1.5 ${s === "cancelled" ? "bg-clay-100 text-clay-700 hover:bg-clay-200" : "bg-olive-100 text-olive-800 hover:bg-olive-200"}`}>
                            → {t(`st_${s}`)}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === "messages" && (
        <div className="grid md:grid-cols-[280px_1fr] gap-4 rounded-2xl border border-cream-200 bg-white overflow-hidden md:min-h-[440px]">
          <div className="border-b md:border-b-0 md:border-e border-cream-200 divide-y divide-cream-100 overflow-y-auto max-h-[220px] md:max-h-[440px]">
            {!convs ? (
              <div className="p-4 flex justify-center"><Spinner /></div>
            ) : convs.length === 0 ? (
              <div className="p-6 text-center text-sm text-ink-400">{t("sd_conv_empty")}</div>
            ) : (
              convs.map((c) => (
                <button key={c.id} onClick={() => setActiveConv(c.id)} className={`w-full text-start p-4 hover:bg-cream-100/60 ${activeConv === c.id ? "bg-olive-50" : ""}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-ink-900 truncate">{c.buyerName}</span>
                    {c.unread > 0 && <span className="min-w-5 h-5 px-1.5 rounded-full bg-olive-700 text-white text-[10px] font-bold flex items-center justify-center">{c.unread}</span>}
                  </div>
                  <div className="text-xs text-ink-400 truncate mt-0.5">{c.lastBody ?? "—"}</div>
                </button>
              ))
            )}
          </div>
          <div className="flex flex-col">
            {!activeConv ? (
              <div className="flex-1 flex items-center justify-center text-sm text-ink-400">{t("msg_no_conv")}</div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[320px]">
                  {msgs.map((m) => (
                    <div key={m.id} className={`flex ${m.senderId === me.id ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 text-sm ${m.senderId === me.id ? "bg-olive-700 text-cream-50" : "bg-cream-100 text-ink-800"}`}>
                        {m.body}
                        <div className={`text-[10px] mt-1 ${m.senderId === me.id ? "text-cream-200/70" : "text-ink-300"}`}>{timeAgo(m.createdAt, lang)}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 border-t border-cream-100 flex gap-2">
                  <input
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && sendMsg()}
                    placeholder={t("sd_msg_ph")}
                    className="flex-1 rounded-xl border border-cream-300 px-3.5 py-2.5 text-sm outline-none focus:border-olive-500"
                  />
                  <Btn onClick={sendMsg}>{t("send")}</Btn>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {tab === "trees" && <SellerTreesTab />}

      {tab === "profile" && (
        <div className="max-w-2xl rounded-2xl border border-cream-200 bg-white p-5 space-y-4">
          {!profile ? (
            <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>
          ) : (
            <>
              <div className="grid md:grid-cols-2 gap-3.5">
                <Field label={t("sd_shop_name")}>
                  <TextInput value={profile.shopName ?? ""} onChange={(e) => setProfile({ ...profile, shopName: e.target.value })} />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label={t("apply_city")}>
                    <TextInput value={profile.city ?? ""} onChange={(e) => setProfile({ ...profile, city: e.target.value })} />
                  </Field>
                  <Field label={t("apply_region")}>
                    <TextInput value={profile.region ?? ""} onChange={(e) => setProfile({ ...profile, region: e.target.value })} />
                  </Field>
                </div>
              </div>
              <Field label={t("sd_about")}>
                <TextArea value={profile.about ?? ""} onChange={(e) => setProfile({ ...profile, about: e.target.value })} />
              </Field>
              <Field label={t("sd_story_shop")}>
                <TextArea value={profile.story ?? ""} onChange={(e) => setProfile({ ...profile, story: e.target.value })} />
              </Field>
              <Field label={t("sd_images")}>
                <TextArea dir="ltr" value={(profile.images ?? []).join("\n")}
                  onChange={(e) => setProfile({ ...profile, images: e.target.value.split("\n").map((x: string) => x.trim()).filter(Boolean) })} />
              </Field>
              <label className="flex items-center gap-2 text-sm font-bold text-ink-700 cursor-pointer">
                <input type="checkbox" checked={!!profile.allowMessages} onChange={(e) => setProfile({ ...profile, allowMessages: e.target.checked })} className="w-4.5 h-4.5 accent-olive-700" />
                {t("sd_allow_msg")}
              </label>
              <Btn onClick={saveProfile}>{t("save")}</Btn>
              {profile.slug && (
                <Link href={`/seller/${profile.slug}`} className="block text-sm font-bold text-olive-700 hover:underline text-center">
                  {t("p_visit_shop")} →
                </Link>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default function SellerDashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-7xl mx-auto px-4 py-16 flex justify-center">
          <Spinner className="w-8 h-8" />
        </div>
      }
    >
      <SellerDashboardInner />
    </Suspense>
  );
}
