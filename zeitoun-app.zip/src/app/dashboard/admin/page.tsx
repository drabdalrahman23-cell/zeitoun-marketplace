"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, Field, Select, Spinner, StatusBadge, TextInput } from "@/components/ui";
import { api, errMsg } from "@/lib/api";
import { fmtDate } from "@/lib/utils";
import { OrdersTab, ReviewsTab, ReportsTab, ContentTab, CurrenciesTab, ShippingTab, OffersTab } from "@/components/admin-ops";
import { AdminAdoptionTab } from "@/components/admin-adoption";

function useAdminGuard() {
  const { me } = useStore();
  const router = useRouter();
  useEffect(() => {
    if (!me) router.replace("/auth/login");
    else if (me.role !== "admin") router.replace("/");
  }, [me, router]);
  return me?.role === "admin";
}

function OverviewTab() {
  const { t, fmt } = useStore();
  const [s, setS] = useState<any | null>(null);
  useEffect(() => {
    fetch("/api/admin/stats", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then(setS).catch(() => {});
  }, []);
  if (!s) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  const cards = [
    { label: t("ad_users_n"), value: s.totalUsers },
    { label: t("ad_sellers_n"), value: s.totalSellers },
    { label: t("ad_products_n"), value: s.totalProducts },
    { label: t("ad_orders_n"), value: s.totalOrders },
    { label: t("ad_revenue"), value: fmt(s.totalRevenue) },
    { label: t("ad_pending_orders"), value: s.pendingOrders },
    { label: t("ad_new_sellers"), value: s.newSellerApps },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
      {cards.map((c, i) => (
        <div key={i} className="rounded-2xl border border-cream-200 bg-white p-4">
          <div className="text-[11px] font-bold text-ink-400">{c.label}</div>
          <div className="font-display text-xl font-bold text-ink-900 mt-1 truncate">{c.value}</div>
        </div>
      ))}
    </div>
  );
}

function UsersTab() {
  const { t, lang, toast } = useStore();
  const [users, setUsers] = useState<any[] | null>(null);
  const [q, setQ] = useState("");

  const load = () => {
    fetch(`/api/admin/users?q=${encodeURIComponent(q)}`, { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setUsers(x?.items ?? [])).catch(() => setUsers([]));
  };
  useEffect(load, []);
  useEffect(() => {
    const h = setTimeout(load, 350);
    return () => clearTimeout(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const act = async (id: number, body: Record<string, unknown>) => {
    try {
      await api("/api/admin/users", { method: "PUT", body: { id, ...body } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };
  const del = async (id: number) => {
    try {
      await api("/api/admin/users", { method: "DELETE", body: { id } });
      toast(t("t_deleted"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!users) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div>
      <TextInput placeholder={`${t("search")}...`} value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs mb-4" />
      <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
        <table className="w-full text-sm min-w-[680px]">
          <thead>
            <tr className="border-b border-cream-200 text-xs text-ink-400">
              <th className="text-start p-3 font-bold">{t("name")}</th>
              <th className="text-start p-3 font-bold">{t("email")}</th>
              <th className="text-start p-3 font-bold">{t("ad_role")}</th>
              <th className="text-start p-3 font-bold">{t("date")}</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className={`border-b border-cream-100 last:border-0 ${u.suspended ? "opacity-60" : ""}`}>
                <td className="p-3 font-bold text-ink-900">
                  {u.name}
                  {u.shopName && <div className="text-[11px] text-olive-700 font-semibold">🫒 {u.shopName}</div>}
                </td>
                <td className="p-3 text-ink-600" dir="ltr">{u.email}</td>
                <td className="p-3">
                  <Select value={u.role} onChange={(e) => act(u.id, { role: e.target.value })} className="!w-32 !py-1.5 !text-xs">
                    <option value="customer">customer</option>
                    <option value="seller">seller</option>
                    <option value="admin">admin</option>
                  </Select>
                </td>
                <td className="p-3 text-ink-400">{fmtDate(u.createdAt, lang)}</td>
                <td className="p-3">
                  <div className="flex gap-2 justify-end items-center">
                    {u.suspended && <StatusBadge status="suspended" />}
                    <button onClick={() => act(u.id, { suspended: !u.suspended })} className="text-xs font-bold text-ink-600 hover:underline">
                      {u.suspended ? t("ad_unsuspend") : t("ad_suspend")}
                    </button>
                    <button onClick={() => del(u.id)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SellersTab() {
  const { t, d, lang, toast } = useStore();
  const [apps, setApps] = useState<any[] | null>(null);
  const [sellers, setSellers] = useState<any[] | null>(null);

  const load = () => {
    fetch("/api/admin/applications", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setApps(x?.items ?? [])).catch(() => setApps([]));
    fetch("/api/admin/sellers", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setSellers(x?.items ?? [])).catch(() => setSellers([]));
  };
  useEffect(load, []);

  const decide = async (id: number, decision: string) => {
    try {
      await api("/api/admin/applications", { method: "PUT", body: { id, decision } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };
  const toggle = async (id: number, status: string) => {
    try {
      await api("/api/admin/sellers", { method: "PUT", body: { id, status } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!apps || !sellers) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_new_sellers")}</h3>
        {apps.filter((a) => a.status === "pending").length === 0 ? (
          <p className="text-sm text-ink-400">—</p>
        ) : (
          <div className="space-y-3">
            {apps.filter((a) => a.status === "pending").map((a) => (
              <div key={a.id} className="rounded-2xl border border-gold-300/60 bg-gold-300/10 p-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div className="font-bold text-ink-900">{a.shopName} <span className="text-ink-400 font-normal">({a.userName} · {a.userEmail})</span></div>
                    <div className="text-xs text-ink-500 mt-0.5">
                      {a.city ?? ""} {a.region && `· ${a.region}`} {a.productTypes?.length > 0 && `· ${a.productTypes.join("، ")}`}
                    </div>
                    {a.about && <p className="text-sm text-ink-600 mt-2 max-w-2xl">{a.about}</p>}
                  </div>
                  <div className="flex gap-2">
                    <Btn onClick={() => decide(a.id, "approve")}>{t("ad_approve")}</Btn>
                    <Btn variant="danger" onClick={() => decide(a.id, "reject")}>{t("ad_reject")}</Btn>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div>
        <h3 className="font-bold text-ink-900 mb-3">{t("ad_sellers")}</h3>
        <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-cream-200 text-xs text-ink-400">
                <th className="text-start p-3 font-bold">{t("sd_shop_name")}</th>
                <th className="text-start p-3 font-bold">{t("apply_region")}</th>
                <th className="text-start p-3 font-bold">{t("rating")}</th>
                <th className="text-start p-3 font-bold">{t("orders_n")}</th>
                <th className="text-start p-3 font-bold">{t("status")}</th>
                <th className="p-3" />
              </tr>
            </thead>
            <tbody>
              {sellers.map((s) => (
                <tr key={s.id} className="border-b border-cream-100 last:border-0">
                  <td className="p-3">
                    <Link href={`/seller/${s.slug}`} className="font-bold text-olive-800 hover:underline">{s.shopName}</Link>
                    <div className="text-[11px] text-ink-400" dir="ltr">{s.userEmail}</div>
                  </td>
                  <td className="p-3">{s.city ?? s.region ?? "—"}</td>
                  <td className="p-3">{s.rating ? s.rating.toFixed(1) : "—"}</td>
                  <td className="p-3">{s.orderCount}</td>
                  <td className="p-3"><StatusBadge status={s.status} /></td>
                  <td className="p-3 text-end">
                    <button onClick={() => toggle(s.id, s.status === "active" ? "suspended" : "active")} className="text-xs font-bold text-ink-600 hover:underline">
                      {s.status === "active" ? t("ad_suspend") : t("ad_unsuspend")}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ProductsTab() {
  const { t, d, fmt, lang, toast } = useStore();
  const [items, setItems] = useState<any[] | null>(null);
  const [filter, setFilter] = useState("");

  const load = () => {
    fetch(`/api/admin/products?status=${filter}`, { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((x) => setItems(x?.items ?? [])).catch(() => setItems([]));
  };
  useEffect(load, [filter]);

  const act = async (id: number, body: Record<string, unknown>) => {
    try {
      await api("/api/admin/products", { method: "PUT", body: { id, ...body } });
      toast(t("t_updated"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!items) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  const filters = [
    { id: "", label: t("all") },
    { id: "pending", label: t("pending") },
    { id: "active", label: t("active") },
    { id: "rejected", label: t("rejected") },
    { id: "archived", label: "archived" },
  ];
  return (
    <div>
      <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar">
        {filters.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold whitespace-nowrap ${filter === f.id ? "bg-olive-700 text-cream-50" : "bg-white border border-cream-300 text-ink-600"}`}>
            {f.label}
          </button>
        ))}
      </div>
      <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
        <table className="w-full text-sm min-w-[720px]">
          <thead>
            <tr className="border-b border-cream-200 text-xs text-ink-400">
              <th className="text-start p-3 font-bold">{t("name")}</th>
              <th className="text-start p-3 font-bold">{t("sd_sellers") ?? "Seller"}</th>
              <th className="text-start p-3 font-bold">{t("price")}</th>
              <th className="text-start p-3 font-bold">{t("status")}</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {items.map((p) => (
              <tr key={p.id} className="border-b border-cream-100 last:border-0">
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-cream-100 overflow-hidden shrink-0">
                      {p.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.image} alt="" className="w-full h-full object-cover" />
                      ) : null}
                    </div>
                    <div>
                      <div className="font-bold text-ink-900">{d({ ar: p.nameAr, en: p.nameEn })}</div>
                      <div className="text-[11px] text-ink-400">{p.category.nameEn} · {p.stock} {t("sd_stock")}</div>
                    </div>
                  </div>
                </td>
                <td className="p-3">{p.seller.shopName}</td>
                <td className="p-3 font-bold">{fmt(p.priceCents)}</td>
                <td className="p-3"><StatusBadge status={p.status} /></td>
                <td className="p-3">
                  <div className="flex gap-2 justify-end flex-wrap">
                    {p.status === "pending" && <button onClick={() => act(p.id, { status: "active" })} className="text-xs font-bold text-olive-700 hover:underline">{t("ad_approve")}</button>}
                    {p.status === "active" && <button onClick={() => act(p.id, { status: "rejected" })} className="text-xs font-bold text-clay-600 hover:underline">{t("ad_reject")}</button>}
                    {p.status !== "archived" && <button onClick={() => act(p.id, { status: "archived" })} className="text-xs font-bold text-ink-400 hover:underline">archive</button>}
                    <button onClick={() => act(p.id, { isFeatured: !p.isFeatured })} className={`text-xs font-bold hover:underline ${p.isFeatured ? "text-gold-500" : "text-ink-400"}`}>
                      {p.isFeatured ? t("ad_unfeature") : t("ad_feature")}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CategoriesTab() {
  const { t, d, lang, toast } = useStore();
  const [cats, setCats] = useState<any[] | null>(null);
  const [form, setForm] = useState({ nameAr: "", nameEn: "", icon: "📦" });

  const load = () => {
    fetch("/api/meta", { cache: "no-store" }).then((r) => r.json()).then((m) => setCats(m?.categories ?? [])).catch(() => setCats([]));
  };
  useEffect(() => {
    load();
  }, []);

  const add = async () => {
    try {
      await api("/api/categories", { body: form });
      setForm({ nameAr: "", nameEn: "", icon: "📦" });
      toast(t("t_saved"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };
  const del = async (id: number) => {
    try {
      await api("/api/categories", { method: "DELETE", body: { id } });
      toast(t("t_deleted"));
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };
  const toggle = async (c: any) => {
    try {
      await api("/api/categories", { method: "PUT", body: { id: c.id, active: !c.active } });
      load();
    } catch (e) {
      toast(errMsg(e, lang), "err");
    }
  };

  if (!cats) return <div className="flex justify-center py-10"><Spinner className="w-8 h-8" /></div>;
  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-cream-200 bg-white p-4 flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[160px]"><Field label={t("ad_cat_name_ar")}><TextInput value={form.nameAr} onChange={(e) => setForm({ ...form, nameAr: e.target.value })} /></Field></div>
        <div className="flex-1 min-w-[160px]"><Field label={t("ad_cat_name_en")}><TextInput dir="ltr" value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} /></Field></div>
        <div className="w-20"><Field label={t("ad_cat_icon")}><TextInput value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} maxLength={4} /></Field></div>
        <Btn onClick={add}>{t("ad_add_category")}</Btn>
      </div>
      <div className="rounded-2xl border border-cream-200 bg-white overflow-x-auto">
        <table className="w-full text-sm min-w-[560px]">
          <thead>
            <tr className="border-b border-cream-200 text-xs text-ink-400">
              <th className="text-start p-3 font-bold">{t("name")}</th>
              <th className="text-start p-3 font-bold">Slug</th>
              <th className="text-start p-3 font-bold">{t("status")}</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {cats.map((c) => (
              <tr key={c.id} className="border-b border-cream-100 last:border-0">
                <td className="p-3 font-bold text-ink-900">{c.icon} {d({ ar: c.nameAr, en: c.nameEn })}</td>
                <td className="p-3 text-ink-400" dir="ltr">{c.slug}</td>
                <td className="p-3">{c.active ? <StatusBadge status="active" /> : <StatusBadge status="archived" />}</td>
                <td className="p-3">
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => toggle(c)} className="text-xs font-bold text-ink-600 hover:underline">{c.active ? t("inactive") : t("active")}</button>
                    <button onClick={() => del(c.id)} className="text-xs font-bold text-clay-600 hover:underline">{t("delete")}</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminDashboardInner() {
  const { t } = useStore();
  const router = useRouter();
  const sp = useSearchParams();
  const allowed = useAdminGuard();
  const tab = sp.get("tab") ?? "overview";
  const setTab = (x: string) => router.replace(`/dashboard/admin?tab=${x}`);

  if (!allowed) return null;

  const tabs = [
    { id: "overview", label: t("ad_overview") },
    { id: "users", label: t("ad_users") },
    { id: "sellers", label: t("ad_sellers") },
    { id: "products", label: t("ad_products") },
    { id: "categories", label: t("ad_categories") },
    { id: "orders", label: t("ad_orders") },
    { id: "reviews", label: t("ad_reviews") },
    { id: "reports", label: t("ad_reports") },
    { id: "content", label: t("ad_content") },
    { id: "currencies", label: t("ad_currencies") },
    { id: "shipping", label: t("ad_shipping") },
    { id: "offers", label: t("ad_offers") },
    { id: "adoption", label: `🌿 ${t("ad_adm")}` },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10">
      <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900 mb-5">{t("ad_title")}</h1>
      <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-1">
        {tabs.map((x) => (
          <button key={x.id} onClick={() => setTab(x.id)}
            className={`rounded-xl px-3.5 py-2 text-xs md:text-sm font-bold whitespace-nowrap transition ${tab === x.id ? "bg-olive-700 text-cream-50" : "bg-white border border-cream-300 text-ink-600 hover:border-olive-400"}`}>
            {x.label}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab />}
      {tab === "users" && <UsersTab />}
      {tab === "sellers" && <SellersTab />}
      {tab === "products" && <ProductsTab />}
      {tab === "categories" && <CategoriesTab />}
      {tab === "orders" && <OrdersTab />}
      {tab === "reviews" && <ReviewsTab />}
      {tab === "reports" && <ReportsTab />}
      {tab === "content" && <ContentTab />}
      {tab === "currencies" && <CurrenciesTab />}
      {tab === "shipping" && <ShippingTab />}
      {tab === "offers" && <OffersTab />}
      {tab === "adoption" && <AdminAdoptionTab />}
    </div>
  );
}

export default function AdminDashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-7xl mx-auto px-4 py-16 flex justify-center">
          <Spinner className="w-8 h-8" />
        </div>
      }
    >
      <AdminDashboardInner />
    </Suspense>
  );
}
