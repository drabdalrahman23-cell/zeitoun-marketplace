"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState } from "@/components/ui";

export default function CartPage() {
  const { t, d, fmt, cart, setQty, removeFromCart, clearCart, cartSubtotal, cartCount, me, toast } = useStore();
  const router = useRouter();

  const grouped = new Map<number, { shopName: string; slug: string; items: typeof cart; subtotal: number }>();
  for (const item of cart) {
    const g = grouped.get(item.sellerId) ?? { shopName: item.shopName, slug: item.sellerSlug, items: [], subtotal: 0 };
    g.items.push(item);
    g.subtotal += item.priceCents * item.qty;
    grouped.set(item.sellerId, g);
  }

  const checkout = () => {
    if (!me) {
      toast(t("login_required"), "err");
      router.push("/auth/login?next=/checkout");
      return;
    }
    router.push("/checkout");
  };

  if (!cart.length) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-10">
        <h1 className="font-display text-3xl font-bold text-ink-900 mb-6">{t("cart_title")}</h1>
        <EmptyState
          icon={
            <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-current" strokeWidth="1.6">
              <path d="M6 7h14l-1.5 8.5a2 2 0 01-2 1.5H9.4a2 2 0 01-2-1.6L5.2 4.5H2.5" />
            </svg>
          }
          title={t("cart_empty")}
          hint={t("cart_empty_hint")}
          action={
            <Btn onClick={() => router.push("/products")}>{t("go_shop")}</Btn>
          }
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 anim-fade-up">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">
          {t("cart_title")} <span className="text-ink-400 text-lg">({cartCount})</span>
        </h1>
        <Btn variant="ghost" onClick={() => { clearCart(); toast(t("t_removed")); }}>{t("cart_clear")}</Btn>
      </div>

      <div className="grid lg:grid-cols-[1fr_340px] gap-6 items-start">
        <div className="space-y-5">
          {[...grouped.entries()].map(([sellerId, g]) => (
            <div key={sellerId} className="rounded-2xl border border-cream-200 bg-white overflow-hidden">
              <div className="px-4 py-3 bg-cream-100/70 border-b border-cream-200 flex items-center justify-between">
                <Link href={`/seller/${g.slug}`} className="text-sm font-bold text-olive-800 hover:underline">
                  {t("cart_seller_section")} {g.shopName}
                </Link>
                <span className="text-xs text-ink-400 font-semibold">
                  {g.items.length} {t("cart_items_count")}
                </span>
              </div>
              <div className="divide-y divide-cream-100">
                {g.items.map((item) => (
                  <div key={item.productId} className="flex gap-3 p-4">
                    <Link href={`/products/${item.slug}`} className="w-20 h-20 rounded-xl overflow-hidden bg-cream-100 shrink-0">
                      {item.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={item.image} alt="" className="w-full h-full object-cover" />
                      ) : null}
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link href={`/products/${item.slug}`} className="font-bold text-sm text-ink-900 hover:text-olive-700 line-clamp-2">
                        {d({ ar: item.nameAr, en: item.nameEn })}
                      </Link>
                      <div className="text-xs text-ink-400 mt-0.5">{item.weightGrams} g · {g.shopName}</div>
                      <div className="flex items-center gap-3 mt-2.5">
                        <div className="flex items-center rounded-lg border border-cream-300 overflow-hidden">
                          <button onClick={() => setQty(item.productId, item.qty - 1)} className="w-8 h-8 font-bold text-ink-600 hover:bg-cream-100">−</button>
                          <span className="w-8 text-center text-sm font-bold">{item.qty}</span>
                          <button onClick={() => setQty(item.productId, Math.min(item.stock, item.qty + 1))} className="w-8 h-8 font-bold text-ink-600 hover:bg-cream-100">+</button>
                        </div>
                        <span className="font-display font-bold text-ink-900">{fmt(item.priceCents * item.qty)}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => { removeFromCart(item.productId); toast(t("t_removed")); }}
                      className="self-start w-8 h-8 rounded-full text-ink-300 hover:text-clay-600 hover:bg-clay-50 flex items-center justify-center"
                      aria-label={t("remove")}
                    >
                      <svg viewBox="0 0 20 20" className="w-4 h-4 fill-none stroke-current" strokeWidth="1.8" strokeLinecap="round">
                        <path d="M5 5l10 10M15 5L5 15" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
              <div className="px-4 py-3 border-t border-cream-100 flex items-center justify-between text-sm">
                <span className="font-bold text-ink-600">{t("subtotal")}</span>
                <span className="font-display font-bold">{fmt(g.subtotal)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-2xl border border-cream-200 bg-white p-5 lg:sticky lg:top-24">
          <h2 className="font-bold text-ink-900 mb-4">{t("cart_summary")}</h2>
          <div className="space-y-2.5 text-sm">
            <div className="flex justify-between">
              <span className="text-ink-400">{t("subtotal")}</span>
              <span className="font-bold">{fmt(cartSubtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-ink-400">{t("shipping_fee")}</span>
              <span className="text-ink-400 text-xs pt-1">—</span>
            </div>
          </div>
          <div className="border-t border-cream-200 mt-4 pt-4 flex justify-between items-center">
            <span className="font-bold">{t("total")}</span>
            <span className="font-display font-bold text-xl">{fmt(cartSubtotal)}</span>
          </div>
          <p className="text-[11px] text-ink-400 mt-3 leading-relaxed">{t("cart_note")}</p>
          <Btn onClick={checkout} className="w-full mt-4">{t("cart_checkout")}</Btn>
          <Link href="/products" className="block text-center text-sm font-bold text-olive-700 hover:text-olive-900 mt-3">
            {t("co_keep_shopping")}
          </Link>
        </div>
      </div>
    </div>
  );
}
