import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { categories, products, reviews, sellers, users } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { toProductFull, toReviewView } from "@/lib/views";
import { ProductView } from "@/components/product-view";

export const dynamic = "force-dynamic";

async function get(slug: string) {
  const rows = await db
    .select({ p: products, c: categories, s: sellers })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .innerJoin(sellers, eq(products.sellerId, sellers.id))
    .where(eq(products.slug, slug));
  const row = rows[0];
  if (!row) return null;
  const reviewRows = await db
    .select({ r: reviews, u: users })
    .from(reviews)
    .innerJoin(users, eq(reviews.userId, users.id))
    .where(and(eq(reviews.productId, row.p.id), eq(reviews.status, "active")))
    .orderBy(desc(reviews.createdAt))
    .limit(50);
  return { ...row, reviews: reviewRows.map((r) => toReviewView({ ...r.r, userName: r.u.name })) };
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const row = await get(slug).catch(() => null);
  if (!row) return { title: "Product | Zeitoun" };
  return {
    title: row.p.nameEn,
    description: (row.p.descriptionEn ?? row.p.storyEn ?? "").slice(0, 160),
    openGraph: {
      title: row.p.nameEn,
      description: (row.p.descriptionEn ?? row.p.storyEn ?? "").slice(0, 160),
      images: row.p.images[0] ? [row.p.images[0]] : [],
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const row = await get(slug).catch(() => null);
  if (!row || row.p.status !== "active") notFound();
  return <ProductView product={toProductFull({ ...row.c, ...row.s, ...row.p })} reviews={row.reviews} />;
}
