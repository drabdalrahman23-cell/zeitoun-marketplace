"use client";

import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, EmptyState, ProductCard, Select, Spinner, TextInput } from "@/components/ui";
import type { ProductView } from "@/lib/types";

const REGIONS = ["Jenin", "Nablus", "Ramallah", "Tubas", "Hebron", "Bethlehem", "Jericho", "Tulkarem"];

function Catalog() {
  const { t, d } = useStore();
  const router = useRouter();
  const sp = useSearchParams();

  const [cats, setCats] = useState<{ slug: string; nameAr: string; nameEn: string; icon: string }[]>([]);
  const [data, setData] = useState<{ items: ProductView[]; total: number; page: number; pages: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const q = sp.get("q") ?? "";
  const category = sp.get("category") ?? "";
  const region = sp.get("region") ?? "";
  const min = sp.get("min") ?? "";
  const max = sp.get("max") ?? "";
  const rating = sp.get("minRating") ?? "";
  const intl = sp.get("intl") ?? "";
  const stock = sp.get("stock") ?? "";
  const sort = sp.get("sort") ?? "relevance";
  const page = parseInt(sp.get("page") ?? "1", 10) || 1;

  useEffect(() => {
    fetch("/api/meta")
      .then((r) => (r.ok ? r.json() : null))
      .then((m) => m?.categories && setCats(m.categories))
      .catch(() => {});
  }, []);

  const key = [q, category, region, min, max, rating, intl, stock, sort, page].join("|");
  useEffect(() => {
    let alive = true;
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category) params.set("category", category);
    if (region) params.set("region", region);
    if (min) params.set("min", min);
    if (max) params.set("max", max);
    if (rating) params.set("minRating", rating);
    if (intl) params.set("intl", "1");
    if (stock) params.set("stock", "1");
    params.set("sort", sort);
    params.set("page", String(page));
    fetch(`/api/products?${params.toString()}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((res) => {
        if (!alive || !res) return;
        setData(res);
        setLoading(false);
      })
      .catch(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const setParam = (k: string, v: string) => {
    const params = new URLSearchParams(sp.toString());
    if (v) params.set(k, v);
    else params.delete(k);
    if (k !== "page") params.delete("page");
    const qs = params.toString();
    router.push(qs ? `/products?${qs}` : "/products");
  };

  const clearAll = () => router.push("/products");

  const filters = (
    <div className="space-y-5">
      <div>
        <label className="text-sm font-bold text-ink-700 mb-2 block">{t("f_category")}</label>
        <Select value={category} onChange={(e) => setParam("category", e.target.value)}>
          <option value="">{t("all")}</option>
          {cats.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.icon} {d({ ar: c.nameAr, en: c.nameEn })}
            </option>
          ))}
        </Select>
      </div>
      <div>
        <label className="text-sm font-bold text-ink-700 mb-2 block">{t("f_price")}</label>
        <div className="flex items-center gap-2">
          <TextInput type="number" min={0} placeholder={t("f_min")} value={min} onChange={(e) => setParam("min", e.target.value)} />
          <span className="text-ink-300">—</span>
          <TextInput type="number" min={0} placeholder={t("f_max")} value={max} onChange={(e) => setParam("max", e.target.value)} />
        </div>
      </div>
      <div>
        <label className="text-sm font-bold text-ink-700 mb-2 block">{t("f_region")}</label>
        <Select value={region} onChange={(e) => setParam("region", e.target.value)}>
          <option value="">{t("all")}</option>
          {REGIONS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </Select>
      </div>
      <div>
        <label className="text-sm font-bold text-ink-700 mb-2 block">{t("f_rating")}</label>
        <button
          onClick={() => setParam("minRating", rating ? "" : "4")}
          className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-bold transition ${rating ? "border-olive-600 bg-olive-50 text-olive-800" : "border-cream-300 bg-white text-ink-600"}`}
        >
          <span className="text-gold-400">★★★★</span> {t("up_rating")}
        </button>
      </div>
      <div className="space-y-2.5">
        <label className="flex items-center gap-2.5 text-sm font-bold text-ink-700 cursor-pointer">
          <input type="checkbox" checked={stock === "1"} onChange={(e) => setParam("stock", e.target.checked ? "1" : "")} className="w-4.5 h-4.5 accent-olive-700" />
          {t("f_instock")}
        </label>
        <label className="flex items-center gap-2.5 text-sm font-bold text-ink-700 cursor-pointer">
          <input type="checkbox" checked={intl === "1"} onChange={(e) => setParam("intl", e.target.checked ? "1" : "")} className="w-4.5 h-4.5 accent-olive-700" />
          {t("f_intl")}
        </label>
      </div>
      <Btn variant="ghost" onClick={clearAll} className="w-full">
        {t("clear_filters")}
      </Btn>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-8">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-5">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-ink-900">
            {q ? `"${q}"` : t("nav_shop")}
          </h1>
          {data && <p className="text-sm text-ink-400 mt-1">{data.total} {t("products")}</p>}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setFiltersOpen(!filtersOpen)} className="lg:hidden rounded-xl border border-cream-300 bg-white px-3.5 py-2.5 text-sm font-bold text-ink-700">
            {t("filters")}
          </button>
          <Select value={sort} onChange={(e) => setParam("sort", e.target.value)} className="!w-52">
            <option value="relevance">{t("sort_relevance")}</option>
            <option value="newest">{t("sort_newest")}</option>
            <option value="price_asc">{t("sort_price_asc")}</option>
            <option value="price_desc">{t("sort_price_desc")}</option>
            <option value="selling">{t("sort_selling")}</option>
            <option value="rated">{t("sort_rated")}</option>
          </Select>
        </div>
      </div>

      {q && (
        <div className="mb-5">
          <Btn variant="outline" onClick={() => setParam("q", "")}>✕ {q}</Btn>
        </div>
      )}

      <div className="grid lg:grid-cols-[240px_1fr] gap-8">
        <aside className={`${filtersOpen ? "block" : "hidden"} lg:block`}>
          <div className="rounded-2xl border border-cream-200 bg-white p-4 lg:sticky lg:top-24">{filters}</div>
        </aside>

        <div>
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <Spinner className="w-8 h-8" />
            </div>
          ) : data && data.items.length > 0 ? (
            <>
              <div className="grid grid-cols-2 xl:grid-cols-3 gap-3 md:gap-4">
                {data.items.map((p) => (
                  <ProductCard key={p.id} p={p} />
                ))}
              </div>
              {data.pages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-10">
                  <Btn variant="outline" disabled={page <= 1} onClick={() => setParam("page", String(page - 1))}>
                    {t("back")}
                  </Btn>
                  <span className="text-sm font-bold text-ink-600 px-2">
                    {page} / {data.pages}
                  </span>
                  <Btn variant="outline" disabled={page >= data.pages} onClick={() => setParam("page", String(page + 1))}>
                    {t("next")}
                  </Btn>
                </div>
              )}
            </>
          ) : (
            <EmptyState
              icon={
                <svg viewBox="0 0 24 24" className="w-8 h-8 fill-none stroke-current" strokeWidth="1.6">
                  <circle cx="11" cy="11" r="7" />
                  <path d="M20 20l-3.5-3.5" strokeLinecap="round" />
                </svg>
              }
              title={t("no_results")}
              hint={t("no_results_hint")}
              action={
                <Btn onClick={clearAll}>{t("clear_filters")}</Btn>
              }
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center py-24">
          <Spinner className="w-8 h-8" />
        </div>
      }
    >
      <Catalog />
    </Suspense>
  );
}
