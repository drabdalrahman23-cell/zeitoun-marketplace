import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { categories, products, sellers } from "@/db/schema";
import { count, desc, eq } from "drizzle-orm";
import { toProductView } from "@/lib/views";
import { SellerView } from "@/components/seller-view";

export const dynamic = "force-dynamic";

async function getSeller(slug: string) {
  const rows = await db.select().from(sellers).where(eq(sellers.slug, slug));
  const s = rows[0];
  if (!s) return null;
  const [[pc], prods] = await Promise.all([
    db.select({ c: count() }).from(products).where(eq(products.sellerId, s.id)),
    db
      .select({ p: products, c: categories, s: sellers })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(sellers, eq(products.sellerId, sellers.id))
      .where(eq(products.sellerId, s.id))
      .orderBy(desc(products.createdAt))
      .limit(24),
  ]);
  return {
    seller: {
      id: s.id,
      slug: s.slug,
      shopName: s.shopName,
      region: s.region,
      city: s.city,
      about: s.about,
      story: s.story,
      images: s.images,
      rating: Number(s.rating),
      orderCount: s.orderCount,
      joinedAt: new Date(s.joinedAt).toISOString(),
      productCount: pc.c,
    },
    products: prods.map((r) => toProductView({ ...r.c, ...r.s, ...r.p })),
  };
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const data = await getSeller(slug).catch(() => null);
  if (!data) return { title: "Seller | Zeitoun" };
  return {
    title: `${data.seller.shopName} — ${data.seller.city ?? "Palestine"}`,
    description: data.seller.about ?? "",
  };
}

export default async function SellerPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getSeller(slug).catch(() => null);
  if (!data || data.seller.productCount === -1) notFound();
  if (!data) notFound();
  return <SellerView seller={data.seller} products={data.products} />;
}
