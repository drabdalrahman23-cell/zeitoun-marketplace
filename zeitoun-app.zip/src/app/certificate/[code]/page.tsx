import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { headers } from "next/headers";
import { db } from "@/db";
import { adoptionCertificates, adoptionGifts, adoptions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionFromCookie } from "@/lib/auth";
import { CertificateClient, type CertificateData } from "@/components/adoption-pages";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Sponsorship certificate | شهادة الرعاية",
};

export default async function CertificatePage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const h = await headers();
  const session = await getSessionFromCookie(h.get("cookie"));

  const rows = await db
    .select({ c: adoptionCertificates, a: adoptions, g: adoptionGifts, u: users })
    .from(adoptionCertificates)
    .innerJoin(adoptions, eq(adoptionCertificates.adoptionId, adoptions.id))
    .innerJoin(users, eq(adoptions.userId, users.id))
    .leftJoin(adoptionGifts, eq(adoptionGifts.adoptionId, adoptions.id))
    .where(eq(adoptionCertificates.code, code.toUpperCase()));
  const row = rows[0];
  if (!row) notFound();

  /* Only the sponsor (or an admin) may open the certificate. */
  if (!session || (session.id !== row.a.userId && session.role !== "admin")) notFound();

  const cert: CertificateData = {
    code: row.c.code,
    qrDataUrl: row.c.qrDataUrl,
    sponsorName: row.c.sponsorName,
    treeName: row.c.treeName,
    treeCode: row.c.treeCode,
    farmerName: row.c.farmerName,
    farmName: row.c.farmName,
    region: row.c.region,
    season: row.c.season ?? String(new Date(row.c.startDate).getFullYear()),
    startDate: new Date(row.c.startDate).toISOString(),
    issuedAt: new Date(row.c.issuedAt).toISOString(),
    treeUrl: row.c.treeCode ? `/trees/${row.c.treeCode}` : null,
    isGift: row.a.isGift,
    giftFrom: row.a.isGift ? row.u.name : null,
    giftMessage: row.g?.message ?? row.a.giftMessage ?? null,
    giftOccasion: row.g?.occasion ?? row.a.giftOccasion ?? null,
  };

  return <CertificateClient cert={cert} />;
}
