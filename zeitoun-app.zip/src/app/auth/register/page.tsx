"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, Field, Spinner, TextInput } from "@/components/ui";
import { OliveLogo } from "@/components/chrome";
import { api, errMsg } from "@/lib/api";

export default function RegisterPage() {
  const { t, toast, refreshMe, lang } = useStore();
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      await api("/api/auth/register", { body: { name, email, password } });
      await refreshMe();
      toast(`${t("auth_welcome")} ${name.split(" ")[0]} 🫒`);
      router.replace("/");
    } catch (er) {
      setErr(errMsg(er, lang));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10 md:py-16 anim-fade-up">
      <div className="rounded-3xl border border-cream-200 bg-white p-6 md:p-8 shadow-sm">
        <div className="flex justify-center mb-5"><OliveLogo size={44} /></div>
        <h1 className="font-display text-2xl font-bold text-ink-900 text-center">{t("register_title")}</h1>
        <p className="text-sm text-ink-400 text-center mt-1 mb-6">{t("register_sub")}</p>
        <form onSubmit={submit} className="space-y-4">
          <Field label={t("auth_name")}>
            <TextInput value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <Field label={t("email")}>
            <TextInput dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label={t("password")} hint={t("auth_pw_hint")}>
            <TextInput dir="ltr" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
          </Field>
          {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
          <Btn type="submit" disabled={busy} className="w-full">
            {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("auth_submit_register")}
          </Btn>
        </form>
        <p className="text-sm text-center mt-6">
          <span className="text-ink-400">{t("auth_have_account")} </span>
          <Link href="/auth/login" className="font-bold text-olive-700 hover:underline">{t("nav_login")}</Link>
        </p>
      </div>
    </div>
  );
}
