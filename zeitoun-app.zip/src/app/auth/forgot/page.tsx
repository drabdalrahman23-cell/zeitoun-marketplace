"use client";

import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/components/store";
import { Btn, Field, Spinner, TextInput } from "@/components/ui";
import { api, errMsg } from "@/lib/api";

export default function ForgotPage() {
  const { t, toast, lang } = useStore();
  const [stage, setStage] = useState<1 | 2>(1);
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [mockCode, setMockCode] = useState("");
  const [newPw, setNewPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);

  const sendCode = async () => {
    setBusy(true);
    setErr("");
    try {
      const res = await api<{ mockCode?: string }>("/api/auth/forgot", { body: { email } });
      if (res.mockCode) setMockCode(res.mockCode);
      setStage(2);
    } catch (e) {
      setErr(errMsg(e, lang));
    } finally {
      setBusy(false);
    }
  };

  const reset = async () => {
    setBusy(true);
    setErr("");
    try {
      await api("/api/auth/reset", { body: { email, code, password: newPw } });
      setDone(true);
    } catch (e) {
      setErr(errMsg(e, lang));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10 md:py-16 anim-fade-up">
      <div className="rounded-3xl border border-cream-200 bg-white p-6 md:p-8 shadow-sm">
        <h1 className="font-display text-2xl font-bold text-ink-900 text-center mb-1">{t("forgot_title")}</h1>
        <p className="text-sm text-ink-400 text-center mb-6">{t("forgot_sub")}</p>

        {done ? (
          <div className="text-center">
            <div className="text-4xl mb-3">✅</div>
            <p className="font-bold text-ink-900">{t("forgot_success")}</p>
            <Link href="/auth/login"><Btn className="mt-5">{t("nav_login")}</Btn></Link>
          </div>
        ) : stage === 1 ? (
          <div className="space-y-4">
            <Field label={t("email")}>
              <TextInput dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
            <Btn onClick={sendCode} disabled={busy || !email} className="w-full">
              {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("forgot_send")}
            </Btn>
          </div>
        ) : (
          <div className="space-y-4">
            {mockCode && (
              <div className="rounded-xl bg-gold-300/20 border border-gold-300/50 p-3.5 text-sm font-bold text-ink-800">
                {t("forgot_mock_code")}: <span dir="ltr" className="font-display text-lg tracking-widest">{mockCode}</span>
              </div>
            )}
            <Field label={t("forgot_code")}>
              <TextInput dir="ltr" value={code} onChange={(e) => setCode(e.target.value)} placeholder="123456" maxLength={6} />
            </Field>
            <Field label={t("forgot_new_pw")} hint={t("auth_pw_hint")}>
              <TextInput dir="ltr" type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} minLength={8} />
            </Field>
            {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
            <Btn onClick={reset} disabled={busy} className="w-full">
              {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("forgot_submit")}
            </Btn>
          </div>
        )}

        <Link href="/auth/login" className="block text-center text-sm font-bold text-olive-700 hover:underline mt-6">
          ← {t("back")}
        </Link>
      </div>
    </div>
  );
}
