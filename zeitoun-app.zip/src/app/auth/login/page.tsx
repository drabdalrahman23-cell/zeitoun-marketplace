"use client";

import Link from "next/link";
import { Suspense, useState, type FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useStore } from "@/components/store";
import { Btn, Field, Spinner, TextInput } from "@/components/ui";
import { OliveLogo } from "@/components/chrome";
import { api, errMsg } from "@/lib/api";

function LoginInner() {
  const { t, toast, refreshMe, lang } = useStore();
  const router = useRouter();
  const sp = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const afterLogin = (role?: string) => {
    const next = sp.get("next");
    if (next) router.replace(next);
    else if (role === "admin") router.replace("/dashboard/admin");
    else router.replace("/");
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      const res = await api("/api/auth/login", { body: { email, password } });
      await refreshMe();
      toast(t("t_login_ok"));
      afterLogin(res.role);
    } catch (er) {
      setErr(errMsg(er, lang));
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    try {
      await api("/api/auth/google", { body: {} });
      await refreshMe();
      toast(t("t_login_ok"));
      afterLogin();
    } catch (er) {
      setErr(errMsg(er, lang));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10 md:py-16 anim-fade-up">
      <div className="rounded-3xl border border-cream-200 bg-white p-6 md:p-8 shadow-sm">
        <div className="flex justify-center mb-5"><OliveLogo size={44} /></div>
        <h1 className="font-display text-2xl font-bold text-ink-900 text-center">{t("login_title")}</h1>
        <p className="text-sm text-ink-400 text-center mt-1 mb-6">{t("login_sub")}</p>

        <form onSubmit={submit} className="space-y-4">
          <Field label={t("email")}>
            <TextInput dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label={t("password")}>
            <TextInput dir="ltr" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </Field>
          {err && <p className="text-sm font-bold text-clay-600">{err}</p>}
          <Btn type="submit" disabled={busy} className="w-full">
            {busy ? <Spinner className="!w-4 !h-4 !text-white" /> : t("auth_submit_login")}
          </Btn>
        </form>

        <button onClick={google} disabled={busy} className="w-full mt-3 rounded-xl border border-cream-300 bg-white font-bold text-sm text-ink-700 py-2.5 hover:bg-cream-100 transition flex items-center justify-center gap-2">
          <svg viewBox="0 0 24 24" className="w-4 h-4"><path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.3H12v4.5h6.5c-.1 1.1-.8 2.7-2.4 3.8l3.8 2.9c2.3-2.1 3.6-5.2 3.6-8.9z" /><path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.9-3c-1 .8-2.4 1.4-4.1 1.4-3.1 0-5.8-2.1-6.7-5l-4 3.1C3.4 21.3 7.4 24 12 24z" /><path fill="#FBBC05" d="M5.3 14.5c-.3-.8-.4-1.6-.4-2.5s.2-1.7.4-2.5l-4-3.1C.4 8.3 0 10.1 0 12s.4 3.7 1.3 5.5l4-3z" /><path fill="#EA4335" d="M12 4.7c1.8 0 3 .8 3.7 1.4l3.4-3.3C17.1 1.1 14.9 0 12 0 7.4 0 3.4 2.7 1.3 6.4l4 3.1c.9-2.9 3.6-4.8 6.7-4.8z" /></svg>
          {t("auth_google")}
        </button>
        <p className="text-[11px] text-ink-300 text-center mt-1.5">{t("auth_google_mock")}</p>

        <div className="flex items-center justify-between mt-6 text-sm">
          <Link href="/auth/forgot" className="font-bold text-olive-700 hover:underline">{t("auth_forgot")}</Link>
          <Link href="/auth/register" className="font-bold text-olive-700 hover:underline">{t("auth_no_account")}</Link>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginInner />
    </Suspense>
  );
}
