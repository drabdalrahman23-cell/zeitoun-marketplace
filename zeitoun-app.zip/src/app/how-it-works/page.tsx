"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { Btn } from "@/components/ui";

export default function HowItWorksPage() {
  const { t } = useStore();
  const steps = [
    { n: "01", icon: "🔍", title: t("how_t1"), desc: t("how_d1") },
    { n: "02", icon: "", title: t("how_t2"), desc: t("how_d2") },
    { n: "03", icon: "🌍", title: t("how_t3"), desc: t("how_d3") },
    { n: "04", icon: "🏠", title: t("how_t4"), desc: t("how_d4") },
  ];
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-20 anim-fade-up">
      <div className="text-center mb-12">
        <h1 className="font-display text-3xl md:text-5xl font-bold text-ink-900">{t("how_title")}</h1>
        <p className="text-ink-400 mt-3">{t("how_sub")}</p>
      </div>
      <div className="space-y-5">
        {steps.map((s, i) => (
          <div key={i} className="flex items-start gap-5 rounded-2xl border border-cream-200 bg-white p-6">
            <div className="w-14 h-14 rounded-2xl bg-olive-100 flex items-center justify-center text-2xl shrink-0">{s.icon}</div>
            <div>
              <div className="text-xs font-bold text-clay-600">{s.n}</div>
              <h2 className="font-display text-lg md:text-xl font-bold text-ink-900 mt-0.5">{s.title}</h2>
              <p className="text-sm text-ink-600 mt-1.5 leading-relaxed">{s.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="text-center mt-12">
        <Link href="/products"><Btn className="!px-8 !py-3.5">{t("hero_shop")}</Btn></Link>
      </div>
    </div>
  );
}
