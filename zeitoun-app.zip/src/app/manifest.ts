import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Zeitoun | زيتون — Palestinian Products Marketplace",
    short_name: "Zeitoun",
    description:
      "Authentic Palestinian products, directly from farmers and artisans to the world.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#faf8f2",
    theme_color: "#465628",
    lang: "ar",
    dir: "rtl",
    icons: [
      { src: "/icons/icon-512.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
