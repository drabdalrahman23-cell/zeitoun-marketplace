import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { asc, count, eq } from "drizzle-orm";
import { ApiError, errRes, requireUser, requireRole } from "@/lib/auth";
import { slugify, vInt, vStr } from "@/lib/utils";
import { toCategoryView } from "@/lib/views";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(categories).where(eq(categories.active, true)).orderBy(asc(categories.sortOrder));
    return NextResponse.json(rows.map(toCategoryView));
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["admin"]);
    const body = await req.json().catch(() => ({}));
    const nameAr = vStr(body.nameAr, 120);
    const nameEn = vStr(body.nameEn, 120);
    if (!nameAr || !nameEn) throw new ApiError(400, "أدخل اسمي التصنيف", "Enter both category names");
    let slug = slugify(body.slug || nameEn);
    const exists = await db.select({ id: categories.id }).from(categories).where(eq(categories.slug, slug));
    if (exists.length) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
    const [row] = await db
      .insert(categories)
      .values({ nameAr, nameEn, slug, icon: vStr(body.icon, 10) || "📦", sortOrder: vInt(body.sortOrder, 0, 9999) })
      .returning();
    return NextResponse.json(toCategoryView(row));
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["admin"]);
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);
    const patch: Record<string, unknown> = {};
    if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 120);
    if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 120);
    if (typeof body.icon === "string") patch.icon = vStr(body.icon, 10);
    if (typeof body.sortOrder === "number") patch.sortOrder = vInt(body.sortOrder, 0, 9999);
    if (typeof body.active === "boolean") patch.active = body.active;
    if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
    await db.update(categories).set(patch as never).where(eq(categories.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["admin"]);
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);
    const countRow = await db.select({ c: count() }).from(products).where(eq(products.categoryId, id));
    const c = countRow[0]?.c ?? 0;
    if (c > 0) throw new ApiError(400, "لا يمكن حذف تصنيف يحتوي منتجات", "Cannot delete a category that has products");
    await db.delete(categories).where(eq(categories.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
