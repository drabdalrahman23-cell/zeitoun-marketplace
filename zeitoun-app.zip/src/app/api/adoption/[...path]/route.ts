import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  adoptionCertificates,
  adoptionGifts,
  adoptionOrders,
  adoptionPrograms,
  adoptionUpdates,
  adoptions,
  farmers,
  farmerSupportPrograms,
  giftOccasions,
  notifications,
  oliveTrees,
  orderItems,
  orders,
  payments,
  products,
  sellers,
  shippingMethods,
  countries,
  treeSeasons,
  users,
} from "@/db/schema";
import { and, asc, count, desc, eq, inArray, sql } from "drizzle-orm";
import { ApiError, errRes, getSessionFromCookie, requireUser } from "@/lib/auth";
import {
  activeOccasions,
  issueCertificate,
  makeQrDataUrl,
  notifySponsors,
  phaseProgress,
  toAdoptionView,
  toProgramView,
  toUpdateView,
} from "@/lib/adoption";
import { quoteShipping, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

/* ============================== GET ============================== */

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const { path } = await params;
    const sub = path[0] ?? "";
    const sp = req.nextUrl.searchParams;

    if (sub === "programs") {
      const rows = await db
        .select()
        .from(adoptionPrograms)
        .where(eq(adoptionPrograms.active, true))
        .orderBy(asc(adoptionPrograms.sortOrder));
      return NextResponse.json({ items: rows.map(toProgramView) });
    }

    if (sub === "occasions") {
      return NextResponse.json({ items: await activeOccasions() });
    }

    /* Public, DB-driven impact numbers (no fake constants). */
    if (sub === "stats") {
      const [treesAll, treesSponsored, farmersC, sponsors, regions, countriesC, value, renewals] = await Promise.all([
        db.select({ c: count() }).from(oliveTrees).where(eq(oliveTrees.verified, true)),
        db.select({ c: count() }).from(oliveTrees).where(sql`${oliveTrees.status} in ('adopted','reserved')`),
        db.select({ c: count() }).from(farmers).where(eq(farmers.active, true)),
        db.select({ c: sql<number>`count(distinct user_id)` }).from(adoptions).where(sql`${adoptions.status} in ('active','completed','renewed','pending')`),
        db.select({ c: sql<number>`count(distinct region)` }).from(oliveTrees).where(eq(oliveTrees.verified, true)),
        db.select({ c: count() }).from(countries).where(eq(countries.active, true)),
        db
          .select({ v: sql<number>`coalesce(sum(price_cents),0)` })
          .from(adoptions)
          .where(sql`${adoptions.status} in ('active','completed','renewed')`),
        db.select({ c: count() }).from(adoptions).where(eq(adoptions.status, "renewed")),
      ]);
      return NextResponse.json({
        trees: treesAll[0].c,
        treesSponsored: treesSponsored[0].c,
        farmers: farmersC[0].c,
        sponsors: Number(sponsors[0].c),
        regions: Number(regions[0].c),
        countries: countriesC[0].c,
        valueCents: Number(value[0]?.v ?? 0),
        renewals: renewals[0].c,
      });
    }

    /* Update feed for the signed-in sponsor (their trees/farmers). */
    if (sub === "updates") {
      const session = await getSessionFromCookie(req.headers.get("cookie"));
      if (!session) throw new ApiError(401, "يجب تسجيل الدخول", "Please sign in");
      const myAdoptions = await db
        .select({ farmerId: adoptions.farmerId, treeId: adoptions.treeId })
        .from(adoptions)
        .where(eq(adoptions.userId, session.id));
      if (!myAdoptions.length) return NextResponse.json({ items: [] });
      const farmerIds = [...new Set(myAdoptions.map((a) => a.farmerId))];
      const rows = await db
        .select({ up: adoptionUpdates, t: oliveTrees, f: farmers })
        .from(adoptionUpdates)
        .innerJoin(farmers, eq(adoptionUpdates.farmerId, farmers.id))
        .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
        .where(and(inArray(adoptionUpdates.farmerId, farmerIds), eq(adoptionUpdates.published, true)))
        .orderBy(desc(adoptionUpdates.createdAt))
        .limit(50);
      return NextResponse.json({
        items: rows.map((r) => ({
          ...toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null }),
          farmerNameAr: r.f.nameAr,
          farmerNameEn: r.f.nameEn,
          treeNameAr: r.t?.nameAr ?? null,
          treeNameEn: r.t?.nameEn ?? null,
        })),
      });
    }

    /* Public certificate lookup by code (no sponsor private data beyond the name on it). */
    if (sub === "certificate") {
      const code = vStr(sp.get("code"), 40).toUpperCase();
      const rows = await db.select().from(adoptionCertificates).where(eq(adoptionCertificates.code, code));
      const c = rows[0];
      if (!c) throw new ApiError(404, "الشهادة غير موجودة", "Certificate not found");
      return NextResponse.json({
        code: c.code,
        qrDataUrl: c.qrDataUrl,
        sponsorName: c.sponsorName,
        treeName: c.treeName,
        treeCode: c.treeCode,
        farmerName: c.farmerName,
        farmName: c.farmName,
        region: c.region,
        season: c.season,
        startDate: new Date(c.startDate).toISOString(),
        issuedAt: new Date(c.issuedAt).toISOString(),
        treeUrl: c.treeCode ? `/trees/${c.treeCode}` : null,
      });
    }

    /* QR image for a tree code (used by the tree page / certificate). */
    if (sub === "qr") {
      const target = vStr(sp.get("target"), 300);
      if (!target) throw new ApiError(400, "هدف غير صالح", "Invalid target");
      const dataUrl = await makeQrDataUrl(target);
      return NextResponse.json({ dataUrl });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

/* ============================== POST ============================== */

export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const { path } = await params;
    const sub = path[0] ?? "";
    if (sub !== "checkout") throw new ApiError(404, "غير موجود", "Not found");

    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const origin = req.headers.get("origin") ?? req.headers.get("host") ?? "";
    const publicBase = origin.startsWith("http") ? origin : origin ? `https://${origin}` : "";

    /* ---- program ---- */
    const programId = vInt(body.programId, 1);
    const progRows = await db.select().from(adoptionPrograms).where(eq(adoptionPrograms.id, programId));
    const program = progRows[0];
    if (!program || !program.active) throw new ApiError(400, "البرنامج غير متاح", "Program not available");

    /* ---- tree / farmer resolution ---- */
    let tree: typeof oliveTrees.$inferSelect | null = null;
    let farmer: typeof farmers.$inferSelect | null = null;

    const treeId = vInt(body.treeId, 0);
    if (treeId) {
      const tRows = await db.select().from(oliveTrees).where(eq(oliveTrees.id, treeId));
      tree = tRows[0] ?? null;
      if (!tree) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
      if (!tree.verified) throw new ApiError(400, "هذه الشجرة قيد التحقق", "This tree is still under verification");
      if (tree.status !== "available") throw new ApiError(409, "هذه الشجرة تحت الرعاية بالفعل", "This tree is already sponsored");
      farmer = (await db.select().from(farmers).where(eq(farmers.id, tree.farmerId)))[0] ?? null;
    } else {
      const farmerId = vInt(body.farmerId, 0);
      if (!farmerId) throw new ApiError(400, "اختر شجرة أو مزارعًا", "Choose a tree or a farmer");
      farmer = (await db.select().from(farmers).where(eq(farmers.id, farmerId)))[0] ?? null;
    }
    if (!farmer || !farmer.active) throw new ApiError(404, "المزارع غير موجود", "Farmer not found");
    if (program.kind === "tree" && !tree) throw new ApiError(400, "هذا البرنامج يتطلب اختيار شجرة", "This program requires a specific tree");
    if (program.kind === "farmer" && tree) throw new ApiError(400, "هذا البرنامج لدعم المزارع بدون شجرة محددة", "This program supports a farmer without a specific tree");

    /* ---- farmer participation + allowed price override ---- */
    const fspRows = await db
      .select()
      .from(farmerSupportPrograms)
      .where(and(eq(farmerSupportPrograms.farmerId, farmer.id), eq(farmerSupportPrograms.programId, program.id)));
    const fsp = fspRows[0];
    if (!fsp || !fsp.allowed) throw new ApiError(400, "هذا المزارع غير مشارك في البرنامج", "This farmer does not participate in this program");
    const priceCents = fsp.allowPriceOverride && fsp.customPriceCents ? fsp.customPriceCents : program.priceCents;

    /* sponsor cap per tree (program + tree level) */
    const maxSponsors = tree ? Math.min(tree.maxSponsors, program.maxSponsorsPerTree) : program.maxSponsorsPerTree;
    const currentSponsors = tree
      ? tree.sponsorCount
      : (
          await db
            .select({ c: count() })
            .from(adoptions)
            .where(and(eq(adoptions.farmerId, farmer.id), eq(adoptions.programId, program.id), sql`${adoptions.status} in ('pending','active','paused')`))
        )[0].c;
    if (currentSponsors >= maxSponsors) throw new ApiError(409, "اكتمل عدد الرعاة لهذا البرنامج", "This program is fully sponsored");

    /* ---- optional products in the same order ---- */
    const rawItems = Array.isArray(body.items) ? body.items : [];
    const itemRows: { p: typeof products.$inferSelect; qty: number }[] = [];
    let itemsSubtotal = 0;
    let itemsWeight = 0;
    for (const it of rawItems) {
      const pid = vInt((it as any)?.productId, 1);
      const qty = vInt((it as any)?.quantity, 1, 50);
      const p = (await db.select().from(products).where(eq(products.id, pid)))[0];
      if (!p || p.status !== "active") throw new ApiError(400, "منتج غير متاح", "Product unavailable");
      if (p.stock < qty) throw new ApiError(409, "المخزون غير كافٍ", "Not enough stock");
      itemRows.push({ p, qty });
      itemsSubtotal += p.priceCents * qty;
      itemsWeight += p.weightGrams * qty;
    }

    /* ---- shipping (only when physical products are included) ---- */
    const rawAddr = body.address ?? {};
    const hasAddress = !!(rawAddr.fullName && rawAddr.countryCode && rawAddr.city && rawAddr.addressLine && rawAddr.postalCode);
    let shippingCents = 0;
    let address: Record<string, string> | null = null;
    if (itemRows.length) {
      if (!hasAddress) throw new ApiError(400, "أكمل عنوان الشحن للمنتجات", "Complete the shipping address for products");
      const methodId = vInt(body.methodId, 1);
      const method = (await db.select().from(shippingMethods).where(eq(shippingMethods.id, methodId)))[0];
      const countryCode = vStr(rawAddr.countryCode, 8).toUpperCase();
      const country = (await db.select().from(countries).where(eq(countries.code, countryCode)))[0];
      if (!method || !method.active) throw new ApiError(400, "طريقة الشحن غير صالحة", "Invalid shipping method");
      if (!country || !country.active) throw new ApiError(400, "الدولة غير مدعومة", "Destination not supported");
      address = {
        fullName: vStr(rawAddr.fullName, 120),
        phone: vStr(rawAddr.phone, 40),
        country: vStr(rawAddr.country, 80),
        countryCode,
        state: vStr(rawAddr.state, 80),
        city: vStr(rawAddr.city, 80),
        addressLine: vStr(rawAddr.addressLine, 200),
        postalCode: vStr(rawAddr.postalCode, 20),
      };
      shippingCents = program.shippingIncluded
        ? 0
        : quoteShipping({
            baseCents: method.baseCents,
            perKgCents: method.perKgCents,
            surchargeCents: country.surchargeCents,
            weightGrams: itemsWeight,
            daysMin: method.daysMin,
            daysMax: method.daysMax,
          });
    }

    if (!farmer.sellerId) throw new ApiError(400, "هذا المزارع غير مرتبط بمتجر بعد", "This farmer is not linked to a store yet");
    const seller = (await db.select().from(sellers).where(eq(sellers.id, farmer.sellerId)))[0];
    if (!seller) throw new ApiError(400, "متجر المزارع غير موجود", "Farmer store not found");

    const totalCents = priceCents + itemsSubtotal + shippingCents;
    const orderType = itemRows.length ? "ADOPTION_AND_PRODUCT_ORDER" : "ADOPTION_ORDER";

    /* ---- order (existing order system, new order type) ---- */
    const year = new Date().getFullYear();
    const cntRow = await db.select({ c: count() }).from(orders);
    const seq = (cntRow[0]?.c ?? 0) + 1;
    const orderNumber = `ZT-${year}-${String(seq).padStart(6, "0")}`;

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber,
        checkoutId: `ZA-${Date.now().toString(36).toUpperCase()}`,
        orderType: orderType as never,
        userId: u.id,
        sellerId: seller.id,
        subtotalCents: priceCents + itemsSubtotal,
        discountCents: 0,
        shippingCents,
        totalCents,
        currency: "USD",
        status: "confirmed",
        address: address ?? { note: "digital adoption" },
        note: vStr(body.note, 500) || null,
      })
      .returning();

    /* mock payment provider (never stores card data) */
    await db.insert(payments).values({
      orderId: order.id,
      provider: body.paymentProvider === "cod" ? "mock_cod" : "mock_card",
      status: "succeeded",
      amountCents: totalCents,
      last4: (vStr(body.cardLast4, 4) || "").replace(/\D/g, "").slice(-4) || null,
    });

    for (const { p, qty } of itemRows) {
      await db.insert(orderItems).values({
        orderId: order.id,
        productId: p.id,
        productNameAr: p.nameAr,
        productNameEn: p.nameEn,
        priceCents: p.priceCents,
        quantity: qty,
        weightGrams: p.weightGrams * qty,
        image: p.images[0] ?? null,
      });
      await db
        .update(products)
        .set({ stock: sql`stock - ${qty}`, salesCount: sql`sales_count + ${qty}` })
        .where(eq(products.id, p.id));
    }

    /* ---- adoption record ---- */
    const startDate = new Date();
    const endDate = new Date(startDate.getTime() + program.durationDays * 86400000);
    const isGift = !!body.isGift && program.giftEnabled;

    let seasonId: number | null = null;
    if (tree) {
      const season = tree.season;
      let sRow = (
        await db.select().from(treeSeasons).where(and(eq(treeSeasons.treeId, tree.id), eq(treeSeasons.season, season)))
      )[0];
      if (!sRow) {
        [sRow] = await db
          .insert(treeSeasons)
          .values({ treeId: tree.id, season, phase: tree.phase, progressPercent: tree.progressPercent || phaseProgress(tree.phase) })
          .returning();
      }
      seasonId = sRow.id;
    }

    const [adoption] = await db
      .insert(adoptions)
      .values({
        userId: u.id,
        treeId: tree?.id ?? null,
        farmerId: farmer.id,
        programId: program.id,
        seasonId,
        orderNumber,
        displayName: vStr(body.displayName, 120) || null,
        status: "active",
        isGift,
        giftRecipientName: isGift ? vStr(body.giftRecipientName, 120) || null : null,
        giftMessage: isGift ? vStr(body.giftMessage, 500) || null : null,
        giftOccasion: isGift ? vStr(body.giftOccasion, 40) || null : null,
        giftSendAt: isGift && body.giftSendAt ? new Date(body.giftSendAt) : null,
        startDate,
        endDate,
        priceCents,
      })
      .returning();

    await db.insert(adoptionOrders).values({
      orderId: order.id,
      adoptionId: adoption.id,
      programId: program.id,
      treeId: tree?.id ?? null,
      amountCents: totalCents,
      isRenewal: false,
    });

    if (isGift) {
      await db.insert(adoptionGifts).values({
        adoptionId: adoption.id,
        recipientName: vStr(body.giftRecipientName, 120) || u.name,
        message: vStr(body.giftMessage, 500) || null,
        occasion: vStr(body.giftOccasion, 40) || "general",
        sendAt: body.giftSendAt ? new Date(body.giftSendAt) : null,
      });
    }

    /* ---- tree / farmer counters ---- */
    if (tree) {
      const newCount = tree.sponsorCount + 1;
      await db
        .update(oliveTrees)
        .set({ sponsorCount: newCount, status: newCount >= maxSponsors ? "adopted" : "reserved" })
        .where(eq(oliveTrees.id, tree.id));
    }
    await db.update(farmers).set({ sponsorCount: sql`sponsor_count + 1` }).where(eq(farmers.id, farmer.id));

    /* ---- certificate (with QR to the public tree page) ---- */
    const cert = await issueCertificate(adoption.id, { publicBase });

    /* ---- notifications ---- */
    await db.insert(notifications).values({
      userId: u.id,
      type: "adoption_created",
      titleAr: isGift ? "🎁 تم إنشاء هدية الرعاية" : "🌿 شكرًا لك! أصبحت راعيًا",
      titleEn: isGift ? "🎁 Your sponsorship gift is ready" : "🌿 Thank you! You are now a sponsor",
      bodyAr: tree
        ? `شجرتك ${adoption.displayName || tree.nameAr || tree.treeCode} — الشهادة جاهزة.`
        : `رعايتك لمزرعة ${farmer.nameAr} — الشهادة جاهزة.`,
      bodyEn: tree
        ? `Your tree ${adoption.displayName || tree.nameEn || tree.treeCode} — certificate ready.`
        : `Your sponsorship of ${farmer.nameEn}'s farm — certificate ready.`,
      link: cert ? `/certificate/${cert.code}` : "/my-trees",
    });
    await db.insert(notifications).values({
      userId: seller.userId,
      type: "new_sponsor",
      titleAr: "🌿 داعم جديد لبرنامج التبني",
      titleEn: "🌿 New adoption sponsor",
      bodyAr: tree ? `شجرة ${tree.treeCode} — ${orderNumber}` : `مزرعتك — ${orderNumber}`,
      bodyEn: tree ? `Tree ${tree.treeCode} — ${orderNumber}` : `Your farm — ${orderNumber}`,
      link: "/dashboard/seller?tab=trees",
    });

    return NextResponse.json({
      ok: true,
      orderNumber,
      orderType,
      adoptionId: adoption.id,
      certificateCode: cert?.code ?? null,
      totalCents,
      treeCode: tree?.treeCode ?? null,
      endDate: endDate.toISOString(),
    });
  } catch (e) {
    return errRes(e);
  }
}
