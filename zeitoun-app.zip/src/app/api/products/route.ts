import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products, sellers } from "@/db/schema";
import { and, asc, count, desc, eq, gte, ilike, lte, or, type SQL } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { slugify, vInt, vStr, vUrls } from "@/lib/utils";
import { toProductView } from "@/lib/views";

export const dynamic = "force-dynamic";

const ACTIVE = eq(products.status, "active");

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const q = (sp.get("q") ?? "").trim();
    const category = sp.get("category") ?? "";
    const sellerSlug = sp.get("seller") ?? "";
    const region = sp.get("region") ?? "";
    const min = parseFloat(sp.get("min") ?? "");
    const max = parseFloat(sp.get("max") ?? "");
    const minRating = sp.get("minRating") ?? "";
    const intl = sp.get("intl") === "1";
    const inStock = sp.get("stock") === "1";
    const sort = sp.get("sort") ?? "relevance";
    const page = Math.max(1, parseInt(sp.get("page") ?? "1", 10) || 1);
    const limit = 24;

    const conds: SQL[] = [ACTIVE];
    if (q)
      conds.push(
        or(
          ilike(products.nameAr, `%${q}%`),
          ilike(products.nameEn, `%${q}%`),
          ilike(products.descriptionAr, `%${q}%`),
          ilike(products.descriptionEn, `%${q}%`),
          ilike(categories.nameAr, `%${q}%`),
          ilike(categories.nameEn, `%${q}%`),
        ) as SQL,
      );
    if (category) conds.push(eq(categories.slug, category));
    if (sellerSlug) conds.push(eq(sellers.slug, sellerSlug));
    if (region) conds.push(ilike(products.originRegion, `%${region}%`));
    if (!Number.isNaN(min)) conds.push(gte(products.priceCents, Math.round(min * 100)));
    if (!Number.isNaN(max)) conds.push(lte(products.priceCents, Math.round(max * 100)));
    if (minRating) conds.push(gte(products.rating, minRating));
    if (intl) conds.push(eq(products.shipsInternational, true));
    if (inStock) conds.push(gte(products.stock, 1));

    const where = and(...conds);
    const totalRow = await db.select({ c: count() }).from(products).where(where);
    const total = totalRow[0]?.c ?? 0;

    const orderBy =
      sort === "newest"
        ? [desc(products.createdAt)]
        : sort === "price_asc"
          ? [asc(products.priceCents)]
          : sort === "price_desc"
            ? [desc(products.priceCents)]
            : sort === "selling"
              ? [desc(products.salesCount)]
              : sort === "rated"
                ? [desc(products.rating), desc(products.reviewCount)]
                : [desc(products.isFeatured), desc(products.salesCount), desc(products.createdAt)];

    const rows = await db
      .select({ p: products, c: categories, s: sellers })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(sellers, eq(products.sellerId, sellers.id))
      .where(where)
      .orderBy(...orderBy)
      .limit(limit)
      .offset((page - 1) * limit);

    return NextResponse.json({
      items: rows.map((r) => toProductView({ ...r.c, ...r.s, ...r.p })),
      total,
      page,
      pages: Math.max(1, Math.ceil(total / limit)),
    });
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    if (u.role === "customer") throw new ApiError(403, "الحساب غير معتمد كمتجر بعد", "Your account is not an approved store yet");
    const body = await req.json().catch(() => ({}));

    let sellerRow;
    if (u.role === "admin") {
      const sid = vInt(body.sellerId, 1);
      const rows = await db.select().from(sellers).where(eq(sellers.id, sid));
      sellerRow = rows[0];
      if (!sellerRow) throw new ApiError(404, "البائع غير موجود", "Seller not found");
    } else {
      const rows = await db.select().from(sellers).where(eq(sellers.userId, u.id));
      sellerRow = rows[0];
      if (!sellerRow) throw new ApiError(403, "لا يوجد متجر مرتبط بحسابك", "No store linked to your account");
    }

    const nameAr = vStr(body.nameAr, 200);
    const nameEn = vStr(body.nameEn, 200);
    const categoryId = vInt(body.categoryId, 1);
    const priceCents = vInt(body.priceCents, 1, 10_000_000);
    if (!nameAr || !nameEn || priceCents < 1) throw new ApiError(400, "أكمل الحقول المطلوبة", "Please complete the required fields");

    const catRows = await db.select().from(categories).where(eq(categories.id, categoryId));
    if (!catRows[0]) throw new ApiError(400, "التصنيف غير موجود", "Category not found");

    const slug = `${slugify(nameEn)}-${Math.random().toString(36).slice(2, 7)}`;

    const [created] = await db
      .insert(products)
      .values({
        sellerId: sellerRow.id,
        categoryId,
        nameAr,
        nameEn,
        slug,
        descriptionAr: vStr(body.descriptionAr, 4000) || null,
        descriptionEn: vStr(body.descriptionEn, 4000) || null,
        priceCents,
        stock: vInt(body.stock, 0, 100000),
        weightGrams: vInt(body.weightGrams, 10, 100000),
        dimensions: vStr(body.dimensions, 80) || null,
        originRegion: vStr(body.originRegion, 120) || sellerRow.city || null,
        images: vUrls(body.images, 8),
        videoUrl: typeof body.videoUrl === "string" && /^https?:\/\//.test(body.videoUrl) ? body.videoUrl : null,
        productionMethodAr: vStr(body.productionMethodAr, 2000) || null,
        productionMethodEn: vStr(body.productionMethodEn, 2000) || null,
        ingredientsAr: vStr(body.ingredientsAr, 1000) || null,
        ingredientsEn: vStr(body.ingredientsEn, 1000) || null,
        usageAr: vStr(body.usageAr, 1000) || null,
        usageEn: vStr(body.usageEn, 1000) || null,
        allergensAr: vStr(body.allergensAr, 500) || null,
        allergensEn: vStr(body.allergensEn, 500) || null,
        storyAr: vStr(body.storyAr, 4000) || null,
        storyEn: vStr(body.storyEn, 4000) || null,
        harvestSeason: vStr(body.harvestSeason, 80) || null,
        shipsInternational: body.shipsInternational !== false,
        /* Moderation: every seller-created product starts pending admin review. */
        status: u.role === "admin" ? "active" : "pending",
      })
      .returning();

    return NextResponse.json(toProductView({ ...catRows[0], ...sellerRow, ...created }));
  } catch (e) {
    return errRes(e);
  }
}
