import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products, reviews, sellers, users } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { ApiError, errRes, getSessionFromCookie, requireUser } from "@/lib/auth";
import { slugify, vInt, vStr, vUrls } from "@/lib/utils";
import { toProductFull, toReviewView } from "@/lib/views";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const rows = await db
      .select({ p: products, c: categories, s: sellers })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(sellers, eq(products.sellerId, sellers.id))
      .where(eq(products.slug, slug));
    const row = rows[0];
    if (!row) throw new ApiError(404, "المنتج غير موجود", "Product not found");

    const session = await getSessionFromCookie(req.headers.get("cookie"));
    const isOwner = session ? row.s.userId === session.id : false;
    if (row.p.status !== "active" && session?.role !== "admin" && !isOwner) {
      throw new ApiError(404, "المنتج غير موجود", "Product not found");
    }

    const reviewRows = await db
      .select({ r: reviews, u: users })
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(and(eq(reviews.productId, row.p.id), eq(reviews.status, "active")))
      .orderBy(desc(reviews.createdAt));

    return NextResponse.json({
      product: toProductFull({ ...row.c, ...row.s, ...row.p }),
      reviews: reviewRows.map((r) => toReviewView({ ...r.r, userName: r.u.name })),
    });
  } catch (e) {
    return errRes(e);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const u = await requireUser(req);
    const { slug } = await params;
    const rows = await db.select().from(products).where(eq(products.slug, slug));
    const p = rows[0];
    if (!p) throw new ApiError(404, "المنتج غير موجود", "Product not found");

    const sellerRows = await db.select().from(sellers).where(eq(sellers.id, p.sellerId));
    const seller = sellerRows[0];
    const isOwner = seller.userId === u.id;
    if (!isOwner && u.role !== "admin") throw new ApiError(403, "لا تملك هذا المنتج", "You don't own this product");

    const body = await req.json().catch(() => ({}));
    const patch: Record<string, unknown> = {};
    const strFields = [
      "nameAr", "nameEn", "descriptionAr", "descriptionEn", "dimensions", "originRegion",
      "videoUrl", "productionMethodAr", "productionMethodEn", "ingredientsAr", "ingredientsEn",
      "usageAr", "usageEn", "allergensAr", "allergensEn", "storyAr", "storyEn", "harvestSeason",
    ];
    for (const f of strFields) if (typeof body[f] === "string") patch[f] = body[f].trim().slice(0, 4000) || null;
    if (typeof body.priceCents === "number") patch.priceCents = vInt(body.priceCents, 1, 10_000_000);
    if (typeof body.stock === "number") patch.stock = vInt(body.stock, 0, 100000);
    if (typeof body.weightGrams === "number") patch.weightGrams = vInt(body.weightGrams, 10, 100000);
    if (typeof body.categoryId === "number") patch.categoryId = vInt(body.categoryId, 1);
    if (Array.isArray(body.images)) patch.images = vUrls(body.images, 8);
    if (Array.isArray(body.storyImages)) patch.storyImages = vUrlsAny2(body.storyImages);
    if (typeof body.shipsInternational === "boolean") patch.shipsInternational = body.shipsInternational;
    if (typeof body.status === "string") {
      if (u.role !== "admin") throw new ApiError(403, "لا يمكن تغيير حالة المراجعة", "Only admins change moderation status");
      if (!["pending", "active", "rejected", "archived"].includes(body.status)) throw new ApiError(400, "حالة غير صالحة", "Invalid status");
      patch.status = body.status;
    }
    if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");

    const [updated] = await db.update(products).set(patch as never).where(eq(products.id, p.id)).returning();
    return NextResponse.json({ ok: true, product: { id: updated.id, status: updated.status } });
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const u = await requireUser(req);
    const { slug } = await params;
    const rows = await db.select().from(products).where(eq(products.slug, slug));
    const p = rows[0];
    if (!p) throw new ApiError(404, "المنتج غير موجود", "Product not found");
    const sellerRows = await db.select().from(sellers).where(eq(sellers.id, p.sellerId));
    if (sellerRows[0].userId !== u.id && u.role !== "admin") throw new ApiError(403, "لا تملك هذا المنتج", "You don't own this product");
    await db.update(products).set({ status: "archived" }).where(eq(products.id, p.id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}

function vUrlsAny2(v: unknown): string[] {
  return vUrls(v, 8);
}
