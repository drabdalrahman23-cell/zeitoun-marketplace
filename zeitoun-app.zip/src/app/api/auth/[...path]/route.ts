import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { users, passwordResets } from "@/db/schema";
import { and, eq, gt, lt } from "drizzle-orm";
import {
  ApiError,
  clearSessionCookie,
  clientIp,
  errRes,
  requireUser,
  setSessionCookie,
  signSession,
} from "@/lib/auth";
import { rateLimit, vEmail, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function loginRes(u: { id: number; name: string; email: string; role: "customer" | "seller" | "admin" }) {
  const res = NextResponse.json({ ok: true, id: u.id, role: u.role });
  setSessionCookie(res, await signSession(u));
  return res;
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const { path } = await params;
    const action = path[0] ?? "";
    const ip = clientIp(req);
    const body = await req.json().catch(() => ({}));

    if (action === "register") {
      if (!rateLimit(`reg:${ip}`, 5, 60000)) throw new ApiError(429, "محاولات كثيرة، انتظر دقيقة", "Too many attempts, wait a minute");
      const name = vStr(body.name, 120);
      const email = vEmail(body.email);
      const password = typeof body.password === "string" ? body.password : "";
      if (!name || !email) throw new ApiError(400, "أكمل الاسم والبريد الإلكتروني", "Please provide name and email");
      if (password.length < 8) throw new ApiError(400, "كلمة المرور 8 أحرف على الأقل", "Password must be at least 8 characters");
      const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email));
      if (existing.length) throw new ApiError(409, "هذا البريد مسجل مسبقاً", "This email is already registered");
      const passwordHash = await bcrypt.hash(password, 10);
      const [u] = await db.insert(users).values({ name, email, passwordHash }).returning();
      return loginRes({ id: u.id, name: u.name, email: u.email, role: u.role });
    }

    if (action === "login") {
      if (!rateLimit(`login:${ip}`, 8, 60000)) throw new ApiError(429, "محاولات كثيرة، انتظر دقيقة", "Too many attempts, wait a minute");
      const email = vEmail(body.email);
      const password = typeof body.password === "string" ? body.password : "";
      if (!email || !password) throw new ApiError(400, "أدخل البريد وكلمة المرور", "Please enter email and password");
      const rows = await db.select().from(users).where(eq(users.email, email));
      const u = rows[0];
      const ok = u && (await bcrypt.compare(password, u.passwordHash));
      if (!ok) throw new ApiError(401, "بيانات دخول غير صحيحة", "Invalid email or password");
      if (u.suspended) throw new ApiError(403, "هذا الحساب موقوف", "This account is suspended");
      return loginRes({ id: u.id, name: u.name, email: u.email, role: u.role });
    }

    if (action === "logout") {
      const res = NextResponse.json({ ok: true });
      clearSessionCookie(res);
      return res;
    }

    /* MOCK Google OAuth — replace with a real OAuth provider in production (see README). */
    if (action === "google") {
      const email = "demo.google@gmail.com";
      let rows = await db.select().from(users).where(eq(users.email, email));
      let u = rows[0];
      if (!u) {
        const passwordHash = await bcrypt.hash("oauth-no-local-login", 10);
        [u] = await db.insert(users).values({ name: "Google Demo User", email, passwordHash }).returning();
      }
      return loginRes({ id: u.id, name: u.name, email: u.email, role: u.role });
    }

    if (action === "forgot") {
      if (!rateLimit(`forgot:${ip}`, 4, 60000)) throw new ApiError(429, "محاولات كثيرة", "Too many attempts");
      const email = vEmail(body.email);
      if (!email) throw new ApiError(400, "أدخل بريدك الإلكتروني", "Please enter your email");
      const rows = await db.select().from(users).where(eq(users.email, email));
      const u = rows[0];
      if (!u) throw new ApiError(404, "لا يوجد حساب بهذا البريد", "No account with this email");
      const code = String(Math.floor(100000 + Math.random() * 900000));
      await db.insert(passwordResets).values({
        userId: u.id,
        code,
        expiresAt: new Date(Date.now() + 30 * 60000),
      });
      /* Mock mode: in production this code is emailed via your EMAIL provider (see README). */
      return NextResponse.json({ ok: true, mockCode: code });
    }

    if (action === "reset") {
      const email = vEmail(body.email);
      const code = vStr(body.code, 10);
      const password = typeof body.password === "string" ? body.password : "";
      if (!email || !code || password.length < 8) throw new ApiError(400, "أكمل جميع الحقول", "Please complete all fields (password 8+)");
      const rows = await db.select().from(users).where(eq(users.email, email));
      const u = rows[0];
      if (!u) throw new ApiError(404, "لا يوجد حساب بهذا البريد", "No account with this email");
      const found = await db
        .select()
        .from(passwordResets)
        .where(and(eq(passwordResets.userId, u.id), eq(passwordResets.code, code), gt(passwordResets.expiresAt, new Date())))
        .orderBy(passwordResets.id)
        .limit(1);
      const r = found[found.length - 1];
      if (!r || r.usedAt) throw new ApiError(400, "الرمز غير صالح أو منتهي", "Invalid or expired code");
      const passwordHash = await bcrypt.hash(password, 10);
      await db.update(users).set({ passwordHash }).where(eq(users.id, u.id));
      await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, r.id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const rows = await db.select().from(users).where(eq(users.id, u.id));
    const full = rows[0];
    return NextResponse.json({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      phone: full?.phone ?? null,
      createdAt: full ? new Date(full.createdAt).toISOString() : null,
    });
  } catch (e) {
    return errRes(e);
  }
}
