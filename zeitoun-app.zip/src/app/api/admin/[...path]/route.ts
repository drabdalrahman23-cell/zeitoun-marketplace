import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  categories,
  countries,
  currencies,
  notifications,
  offers,
  orderItems,
  orders,
  products,
  reports,
  reviews,
  sellerApplications,
  sellers,
  shippingMethods,
  siteContent,
  users,
} from "@/db/schema";
import { and, asc, count, desc, eq, inArray, ilike, isNull, ne, or, sql } from "drizzle-orm";
import { ApiError, errRes, requireRole, requireUser, type SessionUser } from "@/lib/auth";
import { slugify, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function admin(req: NextRequest): Promise<SessionUser> {
  const u = await requireUser(req);
  requireRole(u, ["admin"]);
  return u;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const sp = req.nextUrl.searchParams;

    if (sub === "stats") {
      const [uA, sA, pA, oA, oP, appA] = await Promise.all([
        db.select({ c: count() }).from(users),
        db.select({ c: count() }).from(sellers),
        db.select({ c: count() }).from(products).where(eq(products.status, "active")),
        db.select({ c: count() }).from(orders),
        db.select({ c: count() }).from(orders).where(inArray(orders.status, ["pending", "confirmed", "preparing", "ready"])),
        db.select({ c: count() }).from(sellerApplications).where(eq(sellerApplications.status, "pending")),
      ]);
      const rev = await db
        .select({ v: sql<number>`coalesce(sum(total_cents),0)` })
        .from(orders)
        .where(and(ne(orders.status, "cancelled"), ne(orders.status, "refunded")));
      return NextResponse.json({
        totalUsers: uA[0].c,
        totalSellers: sA[0].c,
        totalProducts: pA[0].c,
        totalOrders: oA[0].c,
        totalRevenue: Number(rev[0]?.v ?? 0),
        pendingOrders: oP[0].c,
        newSellerApps: appA[0].c,
      });
    }

    if (sub === "users") {
      const q = (sp.get("q") ?? "").trim();
      const rows = await db
        .select({ u: users, s: sellers })
        .from(users)
        .leftJoin(sellers, eq(sellers.userId, users.id))
        .where(q ? or(ilike(users.name, `%${q}%`), ilike(users.email, `%${q}%`)) : undefined)
        .orderBy(desc(users.createdAt))
        .limit(300);
      return NextResponse.json({
        items: rows.map(({ u, s }) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          suspended: u.suspended,
          createdAt: new Date(u.createdAt).toISOString(),
          sellerId: s?.id ?? null,
          shopName: s?.shopName ?? null,
        })),
      });
    }

    if (sub === "applications") {
      const rows = await db
        .select({ a: sellerApplications, u: users })
        .from(sellerApplications)
        .innerJoin(users, eq(sellerApplications.userId, users.id))
        .orderBy(desc(sellerApplications.createdAt))
        .limit(200);
      return NextResponse.json({
        items: rows.map(({ a, u }) => ({
          id: a.id,
          userId: a.userId,
          shopName: a.shopName,
          city: a.city,
          region: a.region,
          about: a.about,
          productTypes: a.productTypes,
          status: a.status,
          note: a.note,
          userName: u.name,
          userEmail: u.email,
          createdAt: new Date(a.createdAt).toISOString(),
        })),
      });
    }

    if (sub === "sellers") {
      const rows = await db
        .select({ s: sellers, u: users })
        .from(sellers)
        .innerJoin(users, eq(sellers.userId, users.id))
        .orderBy(desc(sellers.joinedAt))
        .limit(300);
      return NextResponse.json({
        items: rows.map(({ s, u }) => ({
          id: s.id,
          slug: s.slug,
          shopName: s.shopName,
          region: s.region,
          city: s.city,
          status: s.status,
          rating: Number(s.rating),
          orderCount: s.orderCount,
          joinedAt: new Date(s.joinedAt).toISOString(),
          userName: u.name,
          userEmail: u.email,
        })),
      });
    }

    if (sub === "products") {
      const filter = sp.get("status") ?? "";
      const rows = await db
        .select({ p: products, c: categories, s: sellers })
        .from(products)
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .innerJoin(sellers, eq(products.sellerId, sellers.id))
        .where(filter ? eq(products.status, filter as "active") : undefined)
        .orderBy(desc(products.createdAt))
        .limit(400);
      return NextResponse.json({
        items: rows.map(({ p, c, s }) => ({
          id: p.id,
          slug: p.slug,
          nameAr: p.nameAr,
          nameEn: p.nameEn,
          priceCents: p.priceCents,
          stock: p.stock,
          status: p.status,
          isFeatured: p.isFeatured,
          salesCount: p.salesCount,
          image: (p.images ?? [])[0] ?? null,
          category: { slug: c.slug, nameAr: c.nameAr, nameEn: c.nameEn },
          seller: { id: s.id, shopName: s.shopName, city: s.city },
          createdAt: new Date(p.createdAt).toISOString(),
        })),
      });
    }

    if (sub === "orders") {
      const rows = await db
        .select({ o: orders, s: sellers, usr: users })
        .from(orders)
        .innerJoin(sellers, eq(orders.sellerId, sellers.id))
        .innerJoin(users, eq(orders.userId, users.id))
        .orderBy(desc(orders.createdAt))
        .limit(200);
      const ids = rows.map((r) => r.o.id);
      const itemsRows = ids.length ? await db.select().from(orderItems).where(inArray(orderItems.orderId, ids)) : [];
      const byOrder = new Map<number, number>();
      for (const it of itemsRows) byOrder.set(it.orderId, (byOrder.get(it.orderId) ?? 0) + it.quantity);
      return NextResponse.json({
        items: rows.map(({ o, s, usr }) => ({
          id: o.id,
          orderNumber: o.orderNumber,
          status: o.status,
          totalCents: o.totalCents,
          createdAt: new Date(o.createdAt).toISOString(),
          itemCount: byOrder.get(o.id) ?? 0,
          customer: usr.name,
          customerEmail: usr.email,
          seller: { id: s.id, shopName: s.shopName },
        })),
      });
    }

    if (sub === "reviews") {
      const rows = await db
        .select({ r: reviews, p: products, u: users })
        .from(reviews)
        .innerJoin(products, eq(reviews.productId, products.id))
        .innerJoin(users, eq(reviews.userId, users.id))
        .orderBy(desc(reviews.createdAt))
        .limit(300);
      return NextResponse.json({
        items: rows.map(({ r, p, u }) => ({
          id: r.id,
          rating: r.rating,
          commentAr: r.commentAr,
          commentEn: r.commentEn,
          status: r.status,
          productId: r.productId,
          productAr: p.nameAr,
          productEn: p.nameEn,
          userName: u.name,
          createdAt: new Date(r.createdAt).toISOString(),
        })),
      });
    }

    if (sub === "reports") {
      const rows = await db
        .select({ rp: reports, u: users })
        .from(reports)
        .innerJoin(users, eq(reports.reporterId, users.id))
        .orderBy(desc(reports.createdAt))
        .limit(200);
      return NextResponse.json({
        items: rows.map(({ rp, u }) => ({
          id: rp.id,
          targetType: rp.targetType,
          targetId: rp.targetId,
          reason: rp.reason,
          status: rp.status,
          reporter: u.name,
          createdAt: new Date(rp.createdAt).toISOString(),
        })),
      });
    }

    if (sub === "content") {
      const rows = await db.select().from(siteContent).orderBy(asc(siteContent.key));
      return NextResponse.json({ items: rows.map((r) => ({ key: r.key, value: r.value })) });
    }

    if (sub === "currencies") {
      const rows = await db.select().from(currencies).orderBy(asc(currencies.id));
      return NextResponse.json({
        items: rows.map((r) => ({
          id: r.id,
          code: r.code,
          nameAr: r.nameAr,
          nameEn: r.nameEn,
          symbol: r.symbol,
          ratePerUsd: Number(r.ratePerUsd),
          active: r.active,
        })),
      });
    }

    if (sub === "shipping") {
      const [m, c] = await Promise.all([
        db.select().from(shippingMethods).orderBy(asc(shippingMethods.id)),
        db.select().from(countries).orderBy(asc(countries.nameEn)),
      ]);
      return NextResponse.json({
        methods: m.map((r) => ({
          id: r.id,
          nameAr: r.nameAr,
          nameEn: r.nameEn,
          daysMin: r.daysMin,
          daysMax: r.daysMax,
          baseCents: r.baseCents,
          perKgCents: r.perKgCents,
          active: r.active,
        })),
        countries: c.map((r) => ({
          id: r.id,
          code: r.code,
          nameAr: r.nameAr,
          nameEn: r.nameEn,
          region: r.region,
          surchargeCents: r.surchargeCents,
          active: r.active,
        })),
      });
    }

    if (sub === "offers") {
      const rows = await db.select().from(offers).orderBy(desc(offers.id));
      return NextResponse.json({
        items: rows.map((r) => ({
          id: r.id,
          code: r.code,
          type: r.type,
          value: r.value,
          minSubtotalCents: r.minSubtotalCents,
          active: r.active,
          expiresAt: r.expiresAt ? new Date(r.expiresAt).toISOString() : null,
          usageCount: r.usageCount,
        })),
      });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));

    if (sub === "offers") {
      const code = vStr(body.code, 40).toUpperCase();
      if (!code) throw new ApiError(400, "أدخل كود العرض", "Enter an offer code");
      const type = body.type === "fixed" ? "fixed" : "percent";
      const value = vInt(body.value, 1, type === "percent" ? 90 : 10_000_000);
      const [row] = await db
        .insert(offers)
        .values({
          code,
          type,
          value,
          minSubtotalCents: vInt(body.minSubtotalCents, 0, 10_000_000),
          active: body.active !== false,
          expiresAt: body.expiresAt ? new Date(body.expiresAt) : null,
        })
        .returning();
      return NextResponse.json(row);
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));

    if (sub === "users") {
      const id = vInt(body.id, 1);
      if (id === u.id && (body.role !== "admin" || body.suspended === true))
        throw new ApiError(400, "لا يمكنك تعديل حسابك بنفسك", "You cannot modify your own account here");
      const patch: Record<string, unknown> = {};
      if (typeof body.role === "string" && ["customer", "seller", "admin"].includes(body.role)) {
        patch.role = body.role;
        const sRows = await db.select({ id: sellers.id }).from(sellers).where(eq(sellers.userId, id));
        if (body.role === "seller" && sRows.length === 0) {
          const uRows = await db.select().from(users).where(eq(users.id, id));
          const target = uRows[0];
          if (target) {
            const slug = `${slugify(target.name)}-store-${Math.random().toString(36).slice(2, 6)}`;
            await db.insert(sellers).values({ userId: id, shopName: `${target.name} Store`, slug, city: "Palestine" });
          }
        }
      }
      if (typeof body.suspended === "boolean") patch.suspended = body.suspended;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(users).set(patch as never).where(eq(users.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "applications") {
      const id = vInt(body.id, 1);
      const decision = vStr(body.decision, 20);
      const rows = await db.select().from(sellerApplications).where(eq(sellerApplications.id, id));
      const app = rows[0];
      if (!app || app.status !== "pending") throw new ApiError(400, "الطلب غير معلق", "Application is not pending");
      if (decision === "approve") {
        const slug = `${slugify(app.shopName)}-${Math.random().toString(36).slice(2, 6)}`;
        await db.insert(sellers).values({
          userId: app.userId,
          shopName: app.shopName,
          slug,
          city: app.city,
          region: app.region,
          about: app.about,
        });
        await db.update(users).set({ role: "seller" }).where(eq(users.id, app.userId));
        await db.update(sellerApplications).set({ status: "approved", reviewedAt: new Date() }).where(eq(sellerApplications.id, id));
        await db.insert(notifications).values({
          userId: app.userId,
          type: "application",
          titleAr: "تمت الموافقة على طلبك 🎉",
          titleEn: "Your application was approved 🎉",
          bodyAr: "متجرك جاهز — ابدأ بإضافة منتجاتك.",
          bodyEn: "Your store is ready — start adding your products.",
          link: "/dashboard/seller",
        });
      } else if (decision === "reject") {
        await db.update(sellerApplications).set({ status: "rejected", note: vStr(body.note, 500) || null, reviewedAt: new Date() }).where(eq(sellerApplications.id, id));
        await db.insert(notifications).values({
          userId: app.userId,
          type: "application",
          titleAr: "لم يتم قبول طلب البيع",
          titleEn: "Seller application not approved",
          bodyAr: vStr(body.note, 200) || null,
          bodyEn: vStr(body.note, 200) || null,
          link: "/account",
        });
      } else throw new ApiError(400, "قرار غير صالح", "Invalid decision");
      return NextResponse.json({ ok: true });
    }

    if (sub === "sellers") {
      const id = vInt(body.id, 1);
      const status = vStr(body.status, 20);
      if (status !== "active" && status !== "suspended") throw new ApiError(400, "حالة غير صالحة", "Invalid status");
      await db.update(sellers).set({ status: status as never }).where(eq(sellers.id, id));
      const sRows = await db.select().from(sellers).where(eq(sellers.id, id));
      if (sRows[0]) {
        await db.insert(notifications).values({
          userId: sRows[0].userId,
          type: "info",
          titleAr: status === "suspended" ? "تم إيقاف متجرك مؤقتاً" : "تمت إعادة تفعيل متجرك",
          titleEn: status === "suspended" ? "Your store was suspended" : "Your store was re-activated",
          link: "/dashboard/seller",
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (sub === "products") {
      const id = vInt(body.id, 1);
      const pRows = await db.select().from(products).where(eq(products.id, id));
      const p = pRows[0];
      if (!p) throw new ApiError(404, "المنتج غير موجود", "Product not found");
      const patch: Record<string, unknown> = {};
      if (typeof body.status === "string" && ["pending", "active", "rejected", "archived"].includes(body.status)) patch.status = body.status;
      if (typeof body.isFeatured === "boolean") patch.isFeatured = body.isFeatured;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(products).set(patch as never).where(eq(products.id, id));
      const sRows = await db.select().from(sellers).where(eq(sellers.id, p.sellerId));
      const seller = sRows[0];
      if (seller && body.status) {
        const titles: Record<string, { ar: string; en: string }> = {
          active: { ar: `تمت الموافقة على منتجك: ${p.nameAr}`, en: `Your product was approved: ${p.nameEn}` },
          rejected: { ar: `تم رفض منتجك: ${p.nameAr}`, en: `Your product was rejected: ${p.nameEn}` },
          pending: { ar: `منتجك قيد المراجعة: ${p.nameAr}`, en: `Your product is under review: ${p.nameEn}` },
          archived: { ar: `تم أرشفة منتجك: ${p.nameAr}`, en: `Your product was archived: ${p.nameEn}` },
        };
        const t = titles[body.status];
        if (t)
          await db.insert(notifications).values({
            userId: seller.userId,
            type: body.status === "active" ? "product_approved" : "product_rejected",
            titleAr: t.ar,
            titleEn: t.en,
            link: "/dashboard/seller?tab=products",
          });
      }
      return NextResponse.json({ ok: true });
    }

    if (sub === "content") {
      const key = vStr(body.key, 60);
      if (!key || body.value === undefined) throw new ApiError(400, "مفتاح غير صالح", "Invalid key");
      const rows = await db.select().from(siteContent).where(eq(siteContent.key, key));
      if (rows[0]) await db.update(siteContent).set({ value: body.value as never }).where(eq(siteContent.key, key));
      else await db.insert(siteContent).values({ key, value: body.value as never });
      return NextResponse.json({ ok: true });
    }

    if (sub === "currencies") {
      const id = vInt(body.id, 1);
      const patch: Record<string, unknown> = {};
      if (typeof body.ratePerUsd === "number" && body.ratePerUsd > 0) patch.ratePerUsd = body.ratePerUsd.toFixed(4);
      if (typeof body.active === "boolean") patch.active = body.active;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(currencies).set(patch as never).where(eq(currencies.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "shipping") {
      const kind = vStr(body.kind, 20);
      const id = vInt(body.id, 1);
      if (kind === "method") {
        const patch: Record<string, unknown> = {};
        if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 120);
        if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 120);
        if (typeof body.daysMin === "number") patch.daysMin = vInt(body.daysMin, 1, 120);
        if (typeof body.daysMax === "number") patch.daysMax = vInt(body.daysMax, 1, 120);
        if (typeof body.baseCents === "number") patch.baseCents = vInt(body.baseCents, 0, 1_000_000);
        if (typeof body.perKgCents === "number") patch.perKgCents = vInt(body.perKgCents, 0, 1_000_000);
        if (typeof body.active === "boolean") patch.active = body.active;
        if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
        await db.update(shippingMethods).set(patch as never).where(eq(shippingMethods.id, id));
      } else if (kind === "country") {
        const patch: Record<string, unknown> = {};
        if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 120);
        if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 120);
        if (typeof body.surchargeCents === "number") patch.surchargeCents = vInt(body.surchargeCents, 0, 1_000_000);
        if (typeof body.active === "boolean") patch.active = body.active;
        if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
        await db.update(countries).set(patch as never).where(eq(countries.id, id));
      } else throw new ApiError(400, "نوع غير صالح", "Invalid kind");
      return NextResponse.json({ ok: true });
    }

    if (sub === "offers") {
      const id = vInt(body.id, 1);
      const patch: Record<string, unknown> = {};
      if (typeof body.code === "string" && body.code.trim()) patch.code = vStr(body.code, 40).toUpperCase();
      if (body.type === "fixed" || body.type === "percent") patch.type = body.type;
      if (typeof body.value === "number") patch.value = vInt(body.value, 1, 10_000_000);
      if (typeof body.minSubtotalCents === "number") patch.minSubtotalCents = vInt(body.minSubtotalCents, 0, 10_000_000);
      if (typeof body.active === "boolean") patch.active = body.active;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(offers).set(patch as never).where(eq(offers.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "reports") {
      const id = vInt(body.id, 1);
      const status = vStr(body.status, 20);
      if (!["resolved", "dismissed"].includes(status)) throw new ApiError(400, "حالة غير صالحة", "Invalid status");
      await db.update(reports).set({ status: status as never }).where(eq(reports.id, id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);

    if (sub === "users") {
      if (id === u.id) throw new ApiError(400, "لا يمكنك حذف حسابك", "You cannot delete your own account");
      try {
        await db.delete(users).where(eq(users.id, id));
      } catch {
        throw new ApiError(400, "لا يمكن حذف مستخدم مرتبط بطلبات أو متجر — علّق الحساب بدلاً من ذلك", "Cannot delete a user with orders or a store — suspend instead");
      }
      return NextResponse.json({ ok: true });
    }

    if (sub === "products") {
      await db.update(products).set({ status: "archived" }).where(eq(products.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "offers") {
      await db.delete(offers).where(eq(offers.id, id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}
