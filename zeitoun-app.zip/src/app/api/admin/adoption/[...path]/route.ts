import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  adoptionCertificates,
  adoptionPrograms,
  adoptionUpdates,
  adoptions,
  countries,
  farmers,
  farmerSupportPrograms,
  giftOccasions,
  notifications,
  oliveTrees,
  sellers,
  treeSeasons,
  users,
} from "@/db/schema";
import { and, asc, count, desc, eq, sql } from "drizzle-orm";
import { ApiError, errRes, requireRole, requireUser, type SessionUser } from "@/lib/auth";
import {
  nextTreeCode,
  notifySponsors,
  parseProgramInput,
  parseTreeInput,
  phaseProgress,
  programSlug,
  toFarmerMini,
  toProgramView,
  toTreeView,
  toUpdateView,
} from "@/lib/adoption";
import { slugify, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function admin(req: NextRequest): Promise<SessionUser> {
  const u = await requireUser(req);
  requireRole(u, ["admin"]);
  return u;
}

const TREE_STATUSES = ["available", "reserved", "adopted", "inactive", "under_review"];
const ADOPTION_STATUSES = ["pending", "active", "paused", "completed", "expired", "renewed", "cancelled"];

/* ============================== GET ============================== */
export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const sp = req.nextUrl.searchParams;

    if (sub === "analytics") {
      const [available, adopted, sponsors, value, renewals, treesAll, programsAll] = await Promise.all([
        db.select({ c: count() }).from(oliveTrees).where(eq(oliveTrees.status, "available")),
        db.select({ c: count() }).from(oliveTrees).where(sql`${oliveTrees.status} in ('adopted','reserved')`),
        db.select({ c: sql<number>`count(distinct user_id)` }).from(adoptions),
        db.select({ v: sql<number>`coalesce(sum(price_cents),0)` }).from(adoptions).where(sql`${adoptions.status} != 'cancelled'`),
        db.select({ c: count() }).from(adoptions).where(eq(adoptions.status, "renewed")),
        db.select({ c: count() }).from(oliveTrees),
        db.select({ c: count() }).from(adoptionPrograms).where(eq(adoptionPrograms.active, true)),
      ]);
      const topRegions = await db
        .select({ region: oliveTrees.region, c: count() })
        .from(oliveTrees)
        .where(sql`${oliveTrees.sponsorCount} > 0`)
        .groupBy(oliveTrees.region)
        .orderBy(desc(count()))
        .limit(6);
      const topPrograms = await db
        .select({ p: adoptionPrograms, c: count() })
        .from(adoptions)
        .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
        .groupBy(adoptionPrograms.id)
        .orderBy(desc(count()))
        .limit(6);
      const pendingTrees = (await db.select({ c: count() }).from(oliveTrees).where(eq(oliveTrees.status, "under_review")))[0].c;
      const activeAdoptions = (
        await db.select({ c: count() }).from(adoptions).where(sql`${adoptions.status} in ('pending','active','paused')`)
      )[0].c;
      const countriesCount = (await db.select({ c: count() }).from(countries).where(eq(countries.active, true)))[0].c;

      return NextResponse.json({
        availableTrees: available[0].c,
        adoptedTrees: adopted[0].c,
        totalTrees: treesAll[0].c,
        pendingTrees,
        sponsors: Number(sponsors[0].c),
        activeAdoptions,
        countries: countriesCount,
        valueCents: Number(value[0]?.v ?? 0),
        renewals: renewals[0].c,
        activePrograms: programsAll[0].c,
        topRegions: topRegions.filter((r) => r.region).map((r) => ({ label: r.region as string, count: r.c })),
        topPrograms: topPrograms.map((r) => ({ label: r.p.nameEn, count: r.c })),
      });
    }

    if (sub === "trees") {
      const status = sp.get("status") ?? "";
      const rows = await db
        .select({ t: oliveTrees, f: farmers })
        .from(oliveTrees)
        .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
        .where(status && TREE_STATUSES.includes(status) ? eq(oliveTrees.status, status as never) : undefined)
        .orderBy(desc(oliveTrees.createdAt))
        .limit(300);
      return NextResponse.json({ items: rows.map((r) => toTreeView({ ...r.f, ...r.t })) });
    }

    if (sub === "programs") {
      const rows = await db.select().from(adoptionPrograms).orderBy(asc(adoptionPrograms.sortOrder));
      return NextResponse.json({ items: rows.map(toProgramView) });
    }

    if (sub === "farmers") {
      const rows = await db
        .select({ f: farmers, s: sellers, c: sql<number>`(select count(*) from olive_trees where farmer_id = farmers.id)` })
        .from(farmers)
        .leftJoin(sellers, eq(farmers.sellerId, sellers.id))
        .orderBy(desc(farmers.createdAt))
        .limit(200);
      return NextResponse.json({
        items: rows.map((r) => ({ ...toFarmerMini(r.f), sellerId: r.s?.id ?? null, shopName: r.s?.shopName ?? null, trees: Number(r.c), active: r.f.active })),
        sellers: (await db.select({ id: sellers.id, shopName: sellers.shopName }).from(sellers)).map((s) => ({ id: s.id, shopName: s.shopName })),
      });
    }

    if (sub === "adoptions") {
      const rows = await db
        .select({ a: adoptions, t: oliveTrees, f: farmers, p: adoptionPrograms, u: users })
        .from(adoptions)
        .innerJoin(farmers, eq(adoptions.farmerId, farmers.id))
        .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
        .innerJoin(users, eq(adoptions.userId, users.id))
        .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
        .orderBy(desc(adoptions.createdAt))
        .limit(300);
      return NextResponse.json({
        items: rows.map((r) => ({
          id: r.a.id,
          status: r.a.status,
          orderNumber: r.a.orderNumber,
          certificateCode: r.a.certificateCode,
          priceCents: r.a.priceCents,
          isGift: r.a.isGift,
          giftRecipientName: r.a.giftRecipientName,
          displayName: r.a.displayName,
          startDate: new Date(r.a.startDate).toISOString(),
          endDate: r.a.endDate ? new Date(r.a.endDate).toISOString() : null,
          sponsor: r.u.name,
          sponsorEmail: r.u.email,
          farmer: r.f.nameEn,
          treeCode: r.t?.treeCode ?? null,
          program: r.p.nameEn,
        })),
      });
    }

    if (sub === "updates") {
      const rows = await db
        .select({ up: adoptionUpdates, f: farmers, t: oliveTrees })
        .from(adoptionUpdates)
        .innerJoin(farmers, eq(adoptionUpdates.farmerId, farmers.id))
        .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
        .orderBy(desc(adoptionUpdates.createdAt))
        .limit(200);
      return NextResponse.json({
        items: rows.map((r) => ({ ...toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null }), farmer: r.f.nameEn })),
      });
    }

    if (sub === "certificates") {
      const rows = await db
        .select({ c: adoptionCertificates, a: adoptions })
        .from(adoptionCertificates)
        .innerJoin(adoptions, eq(adoptionCertificates.adoptionId, adoptions.id))
        .orderBy(desc(adoptionCertificates.issuedAt))
        .limit(200);
      return NextResponse.json({
        items: rows.map((r) => ({
          id: r.c.id,
          code: r.c.code,
          adoptionId: r.c.adoptionId,
          sponsorName: r.c.sponsorName,
          treeName: r.c.treeName,
          treeCode: r.c.treeCode,
          farmerName: r.c.farmerName,
          region: r.c.region,
          season: r.c.season,
          status: r.a.status,
          issuedAt: new Date(r.c.issuedAt).toISOString(),
        })),
      });
    }

    if (sub === "occasions") {
      const rows = await db.select().from(giftOccasions).orderBy(asc(giftOccasions.sortOrder));
      return NextResponse.json({ items: rows.map((r) => ({ id: r.id, key: r.key, nameAr: r.nameAr, nameEn: r.nameEn, active: r.active })) });
    }

    if (sub === "farmer-programs") {
      const farmerId = vInt(sp.get("farmerId"), 1);
      const rows = await db
        .select({ fsp: farmerSupportPrograms, p: adoptionPrograms })
        .from(farmerSupportPrograms)
        .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
        .where(eq(farmerSupportPrograms.farmerId, farmerId));
      return NextResponse.json({ items: rows.map((r) => ({ ...r.fsp, programName: r.p.nameEn, programPrice: r.p.priceCents })) });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

/* ============================== POST ============================== */
export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));

    if (sub === "trees") {
      const farmerId = vInt(body.farmerId, 1);
      const f = (await db.select().from(farmers).where(eq(farmers.id, farmerId)))[0];
      if (!f) throw new ApiError(404, "المزارع غير موجود", "Farmer not found");
      const data = parseTreeInput(body);
      const treeCode = vStr(body.treeCode, 30).toUpperCase() || (await nextTreeCode());
      const [tree] = await db
        .insert(oliveTrees)
        .values({
          farmerId,
          treeCode,
          ...data,
          status: (TREE_STATUSES.includes(vStr(body.status, 30)) ? vStr(body.status, 30) : "available") as never,
          verified: body.verified === true,
          verifiedAt: body.verified === true ? new Date() : null,
          region: data.region ?? f.region ?? f.city ?? null,
          progressPercent: phaseProgress("season_start"),
        })
        .returning();
      await db.update(farmers).set({ treeCount: sql`tree_count + 1` }).where(eq(farmers.id, farmerId));
      return NextResponse.json({ ok: true, tree: toTreeView({ ...f, ...tree }) });
    }

    if (sub === "programs") {
      const nameAr = vStr(body.nameAr, 160);
      const nameEn = vStr(body.nameEn, 160);
      if (!nameAr || !nameEn) throw new ApiError(400, "أدخل اسمي البرنامج", "Enter both program names");
      const parsed = parseProgramInput(body);
      const kind = ["tree", "farmer", "both"].includes(vStr(body.kind, 10)) ? vStr(body.kind, 10) : "tree";
      const [row] = await db
        .insert(adoptionPrograms)
        .values({
          nameAr,
          nameEn,
          slug: programSlug(nameEn),
          descriptionAr: vStr(body.descriptionAr, 2000) || null,
          descriptionEn: vStr(body.descriptionEn, 2000) || null,
          kind: kind as never,
          priceCents: vInt(body.priceCents, 100, 10_000_000),
          renewalPriceCents: vInt(body.renewalPriceCents, 100, 10_000_000),
          durationDays: vInt(body.durationDays, 30, 3650),
          benefits: parsed.benefits as never,
          includedProducts: parsed.includedProducts as never,
          shippingIncluded: body.shippingIncluded === true,
          maxSponsorsPerTree: vInt(body.maxSponsorsPerTree, 1, 500),
          giftEnabled: body.giftEnabled !== false,
          active: body.active !== false,
          sortOrder: vInt(body.sortOrder, 0, 999),
        })
        .returning();
      return NextResponse.json({ ok: true, program: toProgramView(row) });
    }

    if (sub === "farmers") {
      const nameAr = vStr(body.nameAr, 140);
      const nameEn = vStr(body.nameEn, 140);
      if (!nameAr || !nameEn) throw new ApiError(400, "أدخل اسمي المزارع", "Enter both farmer names");
      const slug = `${slugify(nameEn)}-${Math.random().toString(36).slice(2, 6)}`;
      const [row] = await db
        .insert(farmers)
        .values({
          sellerId: vInt(body.sellerId, 0) || null,
          nameAr,
          nameEn,
          slug,
          farmNameAr: vStr(body.farmNameAr, 160) || null,
          farmNameEn: vStr(body.farmNameEn, 160) || null,
          region: vStr(body.region, 120) || null,
          city: vStr(body.city, 120) || null,
          yearsFarming: vInt(body.yearsFarming, 0, 120),
          storyAr: vStr(body.storyAr, 4000) || null,
          storyEn: vStr(body.storyEn, 4000) || null,
          aboutAr: vStr(body.aboutAr, 2000) || null,
          aboutEn: vStr(body.aboutEn, 2000) || null,
          images: parseTreeInput({ images: body.images }).images,
          videoUrl: vStr(body.videoUrl, 600) || null,
          active: body.active !== false,
        })
        .returning();
      return NextResponse.json({ ok: true, farmer: toFarmerMini(row) });
    }

    if (sub === "farmer-programs") {
      const farmerId = vInt(body.farmerId, 1);
      const programId = vInt(body.programId, 1);
      const exists = (
        await db
          .select()
          .from(farmerSupportPrograms)
          .where(and(eq(farmerSupportPrograms.farmerId, farmerId), eq(farmerSupportPrograms.programId, programId)))
      )[0];
      if (exists) {
        await db
          .update(farmerSupportPrograms)
          .set({
            allowed: body.allowed !== false,
            allowPriceOverride: body.allowPriceOverride === true,
            customPriceCents: body.customPriceCents != null ? vInt(body.customPriceCents, 100, 10_000_000) : null,
            slots: vInt(body.slots, 1, 10000),
          })
          .where(eq(farmerSupportPrograms.id, exists.id));
        return NextResponse.json({ ok: true, id: exists.id });
      }
      const [row] = await db
        .insert(farmerSupportPrograms)
        .values({
          farmerId,
          programId,
          allowed: body.allowed !== false,
          allowPriceOverride: body.allowPriceOverride === true,
          customPriceCents: body.customPriceCents != null ? vInt(body.customPriceCents, 100, 10_000_000) : null,
          slots: vInt(body.slots, 1, 10000),
        })
        .returning();
      return NextResponse.json({ ok: true, id: row.id });
    }

    if (sub === "occasions") {
      const key = slugify(vStr(body.key, 40)) || slugify(vStr(body.nameEn, 40));
      const [row] = await db
        .insert(giftOccasions)
        .values({ key, nameAr: vStr(body.nameAr, 80), nameEn: vStr(body.nameEn, 80), active: body.active !== false, sortOrder: vInt(body.sortOrder, 0, 999) })
        .returning();
      return NextResponse.json({ ok: true, occasion: row });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

/* ============================== PUT ============================== */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);

    if (sub === "trees") {
      const t = (await db.select().from(oliveTrees).where(eq(oliveTrees.id, id)))[0];
      if (!t) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
      const patch: Record<string, unknown> = {};
      if (body.verified === true && !t.verified) {
        patch.verified = true;
        patch.verifiedAt = new Date();
        if (t.status === "under_review") patch.status = "available";
      }
      if (body.verified === false) patch.verified = false;
      if (typeof body.status === "string" && TREE_STATUSES.includes(body.status)) patch.status = body.status;
      if (typeof body.farmerId === "number") {
        const f = (await db.select().from(farmers).where(eq(farmers.id, vInt(body.farmerId, 1))))[0];
        if (!f) throw new ApiError(404, "المزارع غير موجود", "Farmer not found");
        patch.farmerId = f.id;
      }
      const data = parseTreeInput(body);
      for (const [k, v] of Object.entries(data)) if (body[k] !== undefined) patch[k] = v;
      if (typeof body.phase === "string") {
        patch.phase = body.phase;
        patch.progressPercent = vInt(body.progressPercent, 0, 100) || phaseProgress(body.phase);
      }
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(oliveTrees).set(patch as never).where(eq(oliveTrees.id, id));

      /* verification → notify the farmer; phase change → notify sponsors */
      const f = (await db.select().from(farmers).where(eq(farmers.id, (patch.farmerId as number) ?? t.farmerId)))[0];
      if (body.verified === true && !t.verified && f?.sellerId) {
        const seller = (await db.select().from(sellers).where(eq(sellers.id, f.sellerId)))[0];
        if (seller)
          await db.insert(notifications).values({
            userId: seller.userId,
            type: "tree_verified",
            titleAr: `✅ تم اعتماد شجرتك ${t.treeCode}`,
            titleEn: `✅ Your tree ${t.treeCode} is now Zeitoun Verified`,
            link: "/dashboard/seller?tab=trees",
          });
      }
      if (typeof body.phase === "string" && f) {
        await notifySponsors({
          treeId: id,
          farmerId: f.id,
          type: "adoption_phase",
          titleAr: `🌿 مرحلة جديدة لشجرتك: ${body.phase}`,
          titleEn: `🌿 New phase for your tree: ${body.phase}`,
          link: "/my-trees",
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (sub === "programs") {
      const patch: Record<string, unknown> = {};
      if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 160);
      if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 160);
      if (typeof body.descriptionAr === "string") patch.descriptionAr = vStr(body.descriptionAr, 2000) || null;
      if (typeof body.descriptionEn === "string") patch.descriptionEn = vStr(body.descriptionEn, 2000) || null;
      if (["tree", "farmer", "both"].includes(vStr(body.kind, 10))) patch.kind = body.kind;
      if (typeof body.priceCents === "number") patch.priceCents = vInt(body.priceCents, 100, 10_000_000);
      if (typeof body.renewalPriceCents === "number") patch.renewalPriceCents = vInt(body.renewalPriceCents, 100, 10_000_000);
      if (typeof body.durationDays === "number") patch.durationDays = vInt(body.durationDays, 30, 3650);
      if (typeof body.shippingIncluded === "boolean") patch.shippingIncluded = body.shippingIncluded;
      if (typeof body.maxSponsorsPerTree === "number") patch.maxSponsorsPerTree = vInt(body.maxSponsorsPerTree, 1, 500);
      if (typeof body.giftEnabled === "boolean") patch.giftEnabled = body.giftEnabled;
      if (typeof body.active === "boolean") patch.active = body.active;
      if (typeof body.sortOrder === "number") patch.sortOrder = vInt(body.sortOrder, 0, 999);
      if (body.benefits !== undefined || body.includedProducts !== undefined) {
        const parsed = parseProgramInput(body);
        if (body.benefits !== undefined) patch.benefits = parsed.benefits as never;
        if (body.includedProducts !== undefined) patch.includedProducts = parsed.includedProducts as never;
      }
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(adoptionPrograms).set(patch as never).where(eq(adoptionPrograms.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "farmers") {
      const patch: Record<string, unknown> = {};
      if (typeof body.active === "boolean") patch.active = body.active;
      if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 140);
      if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 140);
      if (typeof body.region === "string") patch.region = vStr(body.region, 120) || null;
      if (typeof body.city === "string") patch.city = vStr(body.city, 120) || null;
      if (typeof body.yearsFarming === "number") patch.yearsFarming = vInt(body.yearsFarming, 0, 120);
      if (typeof body.sellerId === "number") patch.sellerId = vInt(body.sellerId, 1) || null;
      if (typeof body.storyAr === "string") patch.storyAr = vStr(body.storyAr, 4000) || null;
      if (typeof body.storyEn === "string") patch.storyEn = vStr(body.storyEn, 4000) || null;
      if (Array.isArray(body.images)) patch.images = parseTreeInput({ images: body.images }).images;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(farmers).set(patch as never).where(eq(farmers.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "adoptions") {
      const a = (await db.select().from(adoptions).where(eq(adoptions.id, id)))[0];
      if (!a) throw new ApiError(404, "الرعاية غير موجودة", "Sponsorship not found");
      const status = vStr(body.status, 20);
      if (!ADOPTION_STATUSES.includes(status)) throw new ApiError(400, "حالة غير صالحة", "Invalid status");
      await db.update(adoptions).set({ status: status as never }).where(eq(adoptions.id, id));
      if (status === "expired" || status === "completed") {
        await db.insert(notifications).values({
          userId: a.userId,
          type: "adoption_renew",
          titleAr: "⏳ ستنتهي رعاية شجرتك قريبًا",
          titleEn: "⏳ Your tree's sponsorship ends soon",
          bodyAr: "يمكنك تجديد الرعاية أو رعاية شجرة أخرى أو دعم المزارع.",
          bodyEn: "You can renew, sponsor another tree, or support the farmer.",
          link: "/my-trees",
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (sub === "updates") {
      const patch: Record<string, unknown> = {};
      if (typeof body.published === "boolean") patch.published = body.published;
      if (typeof body.titleAr === "string") patch.titleAr = vStr(body.titleAr, 200);
      if (typeof body.titleEn === "string") patch.titleEn = vStr(body.titleEn, 200);
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(adoptionUpdates).set(patch as never).where(eq(adoptionUpdates.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "occasions") {
      const patch: Record<string, unknown> = {};
      if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 80);
      if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 80);
      if (typeof body.active === "boolean") patch.active = body.active;
      if (typeof body.sortOrder === "number") patch.sortOrder = vInt(body.sortOrder, 0, 999);
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(giftOccasions).set(patch as never).where(eq(giftOccasions.id, id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

/* ============================== DELETE ============================== */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    await admin(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);

    if (sub === "trees") {
      const active = (
        await db.select({ c: count() }).from(adoptions).where(and(eq(adoptions.treeId, id), sql`${adoptions.status} in ('pending','active','paused')`))
      )[0].c;
      if (active > 0) {
        await db.update(oliveTrees).set({ status: "inactive" }).where(eq(oliveTrees.id, id));
        return NextResponse.json({ ok: true, deactivated: true });
      }
      await db.delete(treeSeasons).where(eq(treeSeasons.treeId, id));
      await db.delete(oliveTrees).where(eq(oliveTrees.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "programs") {
      await db.update(adoptionPrograms).set({ active: false }).where(eq(adoptionPrograms.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "occasions") {
      await db.delete(giftOccasions).where(eq(giftOccasions.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "updates") {
      await db.update(adoptionUpdates).set({ published: false }).where(eq(adoptionUpdates.id, id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}
