import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  adoptionPrograms,
  adoptionUpdates,
  adoptions,
  farmers,
  farmerSupportPrograms,
  notifications,
  oliveTrees,
  sellers,
  treeSeasons,
  users,
} from "@/db/schema";
import { and, asc, count, desc, eq, inArray, sql } from "drizzle-orm";
import { ApiError, errRes, requireRole, requireUser, type SessionUser } from "@/lib/auth";
import {
  notifySponsors,
  parseTreeInput,
  phaseProgress,
  toFarmerFull,
  toProgramView,
  toTreeView,
  toUpdateView,
} from "@/lib/adoption";
import { vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

/** Farmer profile owned by this seller account (admin may pass farmerId). */
async function myFarmer(u: SessionUser, explicitId?: number) {
  if (u.role === "admin" && explicitId) {
    const rows = await db.select().from(farmers).where(eq(farmers.id, explicitId));
    return rows[0] ?? null;
  }
  const sRows = await db.select().from(sellers).where(eq(sellers.userId, u.id));
  const seller = sRows[0];
  if (!seller) return null;
  const rows = await db.select().from(farmers).where(eq(farmers.sellerId, seller.id));
  return rows[0] ?? null;
}

const PHASE_NOTIF: Record<string, { ar: string; en: string }> = {
  harvest: { ar: "🫒 بدأ موسم الحصاد", en: "🫒 Harvest season has begun" },
  pressing: { ar: "🏺 تم عصر زيت موسم مزرعتك", en: "🏺 Your farm's season oil has been pressed" },
  packing: { ar: "📦 أصبح منتجك جاهزًا للشحن", en: "📦 Your products are ready to ship" },
  delivered: { ar: "🏠 تم تسليم منتجات الموسم", en: "🏠 Season products delivered" },
};

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["seller", "admin"]);
    const { path } = await params;
    const sub = path[0] ?? "";
    const farmerIdParam = vInt(req.nextUrl.searchParams.get("farmerId"), 0) || undefined;
    const f = await myFarmer(u, farmerIdParam);

    if (sub === "" || sub === "status") {
      if (!f) return NextResponse.json({ farmer: null });
      const [treesC, sponsoredC, sponsorsC, updatesC] = await Promise.all([
        db.select({ c: count() }).from(oliveTrees).where(eq(oliveTrees.farmerId, f.id)),
        db.select({ c: count() }).from(oliveTrees).where(and(eq(oliveTrees.farmerId, f.id), sql`${oliveTrees.status} in ('adopted','reserved')`)),
        db.select({ c: sql<number>`count(distinct user_id)` }).from(adoptions).where(and(eq(adoptions.farmerId, f.id), sql`${adoptions.status} in ('active','pending','renewed','completed')`)),
        db.select({ c: count() }).from(adoptionUpdates).where(eq(adoptionUpdates.farmerId, f.id)),
      ]);
      return NextResponse.json({
        farmer: toFarmerFull(f),
        stats: {
          trees: treesC[0].c,
          sponsoredTrees: sponsoredC[0].c,
          sponsors: Number(sponsorsC[0].c),
          updates: updatesC[0].c,
        },
      });
    }

    if (!f) throw new ApiError(403, "لا يوجد ملف مزارع لحسابك", "No farmer profile for your account");

    if (sub === "trees") {
      const [treeRows, progRows] = await Promise.all([
        db.select().from(oliveTrees).where(eq(oliveTrees.farmerId, f.id)).orderBy(desc(oliveTrees.createdAt)),
        db
          .select({ p: adoptionPrograms, fsp: farmerSupportPrograms })
          .from(farmerSupportPrograms)
          .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
          .where(eq(farmerSupportPrograms.farmerId, f.id))
          .orderBy(asc(adoptionPrograms.sortOrder)),
      ]);
      return NextResponse.json({
        items: treeRows.map((t) => toTreeView({ ...f, ...t })),
        programs: progRows.map((r) => ({
          ...toProgramView(r.p),
          allowed: r.fsp.allowed,
          allowPriceOverride: r.fsp.allowPriceOverride,
          customPriceCents: r.fsp.customPriceCents,
          slots: r.fsp.slots,
          fspId: r.fsp.id,
        })),
      });
    }

    if (sub === "updates") {
      const rows = await db
        .select({ up: adoptionUpdates, t: oliveTrees })
        .from(adoptionUpdates)
        .leftJoin(oliveTrees, eq(adoptionUpdates.treeId, oliveTrees.id))
        .where(eq(adoptionUpdates.farmerId, f.id))
        .orderBy(desc(adoptionUpdates.createdAt))
        .limit(50);
      return NextResponse.json({ items: rows.map((r) => toUpdateView({ ...r.up, treeCode: r.t?.treeCode ?? null })) });
    }

    if (sub === "sponsors") {
      const rows = await db
        .select({ a: adoptions, t: oliveTrees, p: adoptionPrograms, usr: users })
        .from(adoptions)
        .innerJoin(users, eq(adoptions.userId, users.id))
        .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
        .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
        .where(eq(adoptions.farmerId, f.id))
        .orderBy(desc(adoptions.createdAt))
        .limit(200);
      /* privacy: only the sponsor's first name + country, never email/phone */
      return NextResponse.json({
        items: rows.map((r) => ({
          id: r.a.id,
          sponsorName: r.usr.name.split(" ")[0],
          displayName: r.a.displayName,
          isGift: r.a.isGift,
          giftRecipientName: r.a.giftRecipientName,
          treeCode: r.t?.treeCode ?? null,
          treeName: r.t?.nameEn ?? r.t?.nameAr ?? null,
          program: r.p.nameEn,
          status: r.a.status,
          startDate: new Date(r.a.startDate).toISOString(),
          endDate: r.a.endDate ? new Date(r.a.endDate).toISOString() : null,
        })),
      });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["seller", "admin"]);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));

    if (sub === "trees") {
      const f = await myFarmer(u, vInt(body.farmerId, 0) || undefined);
      if (!f) throw new ApiError(403, "لا يوجد ملف مزارع لحسابك", "No farmer profile for your account");
      const data = parseTreeInput(body);
      const cnt = (await db.select({ c: count() }).from(oliveTrees))[0].c;
      const treeCode = vStr(body.treeCode, 30).toUpperCase() || `ZT-TREE-${String(cnt + 1).padStart(6, "0")}`;
      const [tree] = await db
        .insert(oliveTrees)
        .values({
          farmerId: f.id,
          treeCode,
          ...data,
          /* Anti-fraud: every farmer-added tree starts unverified & under review. */
          status: "under_review",
          verified: false,
          region: data.region ?? f.region ?? f.city ?? null,
          progressPercent: phaseProgress("season_start"),
        })
        .returning();
      if (!data.nameAr && !data.nameEn) {
        await db.update(oliveTrees).set({ nameEn: `Olive Tree #${tree.treeNumber ?? tree.id}` }).where(eq(oliveTrees.id, tree.id));
      }
      /* notify admins to verify */
      const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin"));
      if (admins.length)
        await db.insert(notifications).values(
          admins.map((a) => ({
            userId: a.id,
            type: "tree_review",
            titleAr: `شجرة جديدة بانتظار التحقق: ${treeCode}`,
            titleEn: `New tree awaiting verification: ${treeCode}`,
            link: "/dashboard/admin?tab=adoption&sub=trees",
          })),
        );
      return NextResponse.json({ ok: true, tree: toTreeView({ ...f, ...tree }) });
    }

    if (sub === "updates") {
      const f = await myFarmer(u, vInt(body.farmerId, 0) || undefined);
      if (!f) throw new ApiError(403, "لا يوجد ملف مزارع لحسابك", "No farmer profile for your account");
      const titleAr = vStr(body.titleAr, 200);
      const titleEn = vStr(body.titleEn, 200);
      if (!titleAr && !titleEn) throw new ApiError(400, "أدخل عنوان التحديث", "Enter an update title");
      const treeId = vInt(body.treeId, 0) || null;
      let phase = vStr(body.phase, 30) || null;

      if (treeId) {
        const t = (await db.select().from(oliveTrees).where(and(eq(oliveTrees.id, treeId), eq(oliveTrees.farmerId, f.id))))[0];
        if (!t) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
        if (phase) {
          const progress = vInt(body.progressPercent, 0, 100) || phaseProgress(phase);
          await db.update(oliveTrees).set({ phase, progressPercent: progress }).where(eq(oliveTrees.id, treeId));
          let sRow = (await db.select().from(treeSeasons).where(and(eq(treeSeasons.treeId, treeId), eq(treeSeasons.season, t.season))))[0];
          if (sRow) await db.update(treeSeasons).set({ phase, progressPercent: progress }).where(eq(treeSeasons.id, sRow.id));
          else await db.insert(treeSeasons).values({ treeId, season: t.season, phase, progressPercent: progress });
        }
      }

      const [up] = await db
        .insert(adoptionUpdates)
        .values({
          farmerId: f.id,
          treeId,
          titleAr: titleAr || titleEn,
          titleEn: titleEn || titleAr,
          bodyAr: vStr(body.bodyAr, 4000) || null,
          bodyEn: vStr(body.bodyEn, 4000) || null,
          image: vStr(body.image, 600) || null,
          video: vStr(body.video, 600) || null,
          phase,
        })
        .returning();

      const notif = phase && PHASE_NOTIF[phase] ? PHASE_NOTIF[phase] : { ar: "🌿 هناك تحديث جديد من مزرعتك", en: "🌿 New update from your farm" };
      const reached = await notifySponsors({
        treeId,
        farmerId: f.id,
        type: "adoption_update",
        titleAr: phase && PHASE_NOTIF[phase] ? PHASE_NOTIF[phase].ar : `🌿 ${titleAr || titleEn}`,
        titleEn: phase && PHASE_NOTIF[phase] ? PHASE_NOTIF[phase].en : `🌿 ${titleEn || titleAr}`,
        bodyAr: vStr(body.bodyAr, 160) || null,
        bodyEn: vStr(body.bodyEn, 160) || null,
        link: treeId ? `/my-trees` : `/farmers/${f.slug}`,
      });
      void notif;

      return NextResponse.json({ ok: true, update: toUpdateView(up), notified: reached });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["seller", "admin"]);
    const { path } = await params;
    const sub = path[0] ?? "";
    const body = await req.json().catch(() => ({}));
    const f = await myFarmer(u, vInt(body.farmerId, 0) || undefined);
    if (!f) throw new ApiError(403, "لا يوجد ملف مزارع لحسابك", "No farmer profile for your account");

    if (sub === "trees") {
      const id = vInt(body.id, 1);
      const t = (await db.select().from(oliveTrees).where(and(eq(oliveTrees.id, id), eq(oliveTrees.farmerId, f.id))))[0];
      if (!t) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
      const patch: Record<string, unknown> = {};
      const data = parseTreeInput(body);
      for (const [k, v] of Object.entries(data)) if (v !== null && !(Array.isArray(v) && v.length === 0)) patch[k] = v;
      if (typeof body.status === "string" && ["available", "reserved", "adopted", "inactive", "under_review"].includes(body.status))
        patch.status = body.status;
      /* Farmers may NOT set program pricing — only admins can (see farmerSupportPrograms). */
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(oliveTrees).set(patch as never).where(eq(oliveTrees.id, id));
      return NextResponse.json({ ok: true });
    }

    if (sub === "profile") {
      const patch: Record<string, unknown> = {};
      if (typeof body.nameAr === "string") patch.nameAr = vStr(body.nameAr, 140);
      if (typeof body.nameEn === "string") patch.nameEn = vStr(body.nameEn, 140);
      if (typeof body.farmNameAr === "string") patch.farmNameAr = vStr(body.farmNameAr, 160) || null;
      if (typeof body.farmNameEn === "string") patch.farmNameEn = vStr(body.farmNameEn, 160) || null;
      if (typeof body.storyAr === "string") patch.storyAr = vStr(body.storyAr, 4000) || null;
      if (typeof body.storyEn === "string") patch.storyEn = vStr(body.storyEn, 4000) || null;
      if (typeof body.aboutAr === "string") patch.aboutAr = vStr(body.aboutAr, 2000) || null;
      if (typeof body.aboutEn === "string") patch.aboutEn = vStr(body.aboutEn, 2000) || null;
      if (typeof body.yearsFarming === "number") patch.yearsFarming = vInt(body.yearsFarming, 0, 120);
      if (typeof body.region === "string") patch.region = vStr(body.region, 120) || null;
      if (typeof body.city === "string") patch.city = vStr(body.city, 120) || null;
      if (Array.isArray(body.images)) patch.images = parseTreeInput({ images: body.images }).images;
      if (typeof body.videoUrl === "string") patch.videoUrl = vStr(body.videoUrl, 600) || null;
      if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
      await db.update(farmers).set(patch as never).where(eq(farmers.id, f.id));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["seller", "admin"]);
    const { path } = await params;
    const body = await req.json().catch(() => ({}));
    const f = await myFarmer(u, vInt(body.farmerId, 0) || undefined);
    if (!f) throw new ApiError(403, "لا يوجد ملف مزارع لحسابك", "No farmer profile for your account");
    if (path[0] !== "trees") throw new ApiError(404, "غير موجود", "Not found");

    const id = vInt(body.id, 1);
    const t = (await db.select().from(oliveTrees).where(and(eq(oliveTrees.id, id), eq(oliveTrees.farmerId, f.id))))[0];
    if (!t) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
    const active = (
      await db.select({ c: count() }).from(adoptions).where(and(eq(adoptions.treeId, id), sql`${adoptions.status} in ('pending','active','paused')`))
    )[0].c;
    if (active > 0) {
      /* never delete a sponsored tree — deactivate instead */
      await db.update(oliveTrees).set({ status: "inactive" }).where(eq(oliveTrees.id, id));
      return NextResponse.json({ ok: true, deactivated: true });
    }
    await db.delete(oliveTrees).where(eq(oliveTrees.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
