import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, favorites, products, sellers } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { errRes, requireUser } from "@/lib/auth";
import { vInt } from "@/lib/utils";
import { toProductView } from "@/lib/views";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const rows = await db
      .select({ p: products, c: categories, s: sellers, f: favorites })
      .from(favorites)
      .innerJoin(products, eq(favorites.productId, products.id))
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .innerJoin(sellers, eq(products.sellerId, sellers.id))
      .where(eq(favorites.userId, u.id))
      .orderBy(desc(favorites.createdAt))
      .limit(200);
    return NextResponse.json({
      items: rows
        .filter((r) => r.p.status === "active")
        .map((r) => toProductView({ ...r.c, ...r.s, ...r.p })),
    });
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const productId = vInt(body.productId, 1);
    await db.insert(favorites).values({ userId: u.id, productId }).onConflictDoNothing();
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const productId = vInt(body.productId, 1);
    await db.delete(favorites).where(and(eq(favorites.userId, u.id), eq(favorites.productId, productId)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
