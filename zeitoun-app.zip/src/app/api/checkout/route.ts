import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  offers,
  orderItems,
  orders,
  payments,
  products,
  sellers,
  shippingMethods,
  countries,
  shipments,
  notifications,
} from "@/db/schema";
import { and, count, eq, gte, inArray, sql } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { etaRange, quoteShipping, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length) throw new ApiError(400, "السلة فارغة", "Your cart is empty");

    const raw = body.address ?? {};
    const address = {
      fullName: vStr(raw.fullName, 120),
      phone: vStr(raw.phone, 40),
      country: vStr(raw.country, 80),
      countryCode: vStr(raw.countryCode, 8).toUpperCase(),
      state: vStr(raw.state, 80),
      city: vStr(raw.city, 80),
      addressLine: vStr(raw.addressLine, 200),
      postalCode: vStr(raw.postalCode, 20),
    };
    if (!address.fullName || !address.phone || !address.country || !address.city || !address.addressLine || !address.postalCode)
      throw new ApiError(400, "أكمل بيانات العنوان الدولي", "Please complete the international shipping address");

    const methodId = vInt(body.methodId, 1);
    const mRows = await db.select().from(shippingMethods).where(eq(shippingMethods.id, methodId));
    const method = mRows.find((r) => r.active);
    const cRows = await db.select().from(countries).where(eq(countries.code, address.countryCode));
    const country = cRows.find((r) => r.active);
    if (!method) throw new ApiError(400, "طريقة الشحن غير صالحة", "Invalid shipping method");
    if (!country) throw new ApiError(400, "الدولة غير مدعومة حالياً", "Destination country not supported");

    const paymentProvider = body.paymentProvider === "cod" ? "mock_cod" : "mock_card";
    const last4 = (vStr(body.cardLast4, 4) || "").replace(/\D/g, "").slice(-4) || null;

    const ids = items.map((i: any) => vInt(i?.productId, 1));
    const pRows = await db.select().from(products).where(inArray(products.id, ids));

    const groups = new Map<
      number,
      { sellerId: number; items: { p: (typeof pRows)[number]; qty: number }[]; weightGrams: number; subtotal: number }
    >();
    for (const it of items) {
      const id = vInt((it as any)?.productId, 1);
      const qty = vInt((it as any)?.quantity, 1, 99);
      const p = pRows.find((r) => r.id === id);
      if (!p) throw new ApiError(400, "منتج غير موجود", "Product not found");
      if (p.status !== "active") throw new ApiError(400, `منتج غير متاح: ${p.nameEn}`, `Product unavailable: ${p.nameEn}`);
      if (p.stock < qty) throw new ApiError(400, `المخزون غير كافٍ: ${p.nameEn}`, `Not enough stock: ${p.nameEn}`);
      let g = groups.get(p.sellerId);
      if (!g) {
        g = { sellerId: p.sellerId, items: [], weightGrams: 0, subtotal: 0 };
        groups.set(p.sellerId, g);
      }
      g.items.push({ p, qty });
      g.weightGrams += p.weightGrams * qty;
      g.subtotal += p.priceCents * qty;
    }

    const grandSubtotal = [...groups.values()].reduce((s, g) => s + g.subtotal, 0);

    /* Discount code */
    let discount = 0;
    let appliedOffer: { id: number } | null = null;
    const code = vStr(body.offerCode, 40).toUpperCase();
    if (code) {
      const orows = await db.select().from(offers).where(eq(offers.code, code));
      const off = orows[0];
      if (off && off.active && (!off.expiresAt || off.expiresAt > new Date()) && grandSubtotal >= off.minSubtotalCents) {
        discount = off.type === "percent" ? Math.round((grandSubtotal * off.value) / 100) : Math.min(off.value, grandSubtotal);
        appliedOffer = { id: off.id };
      }
    }

    /* Multi-vendor split: one order per seller */
    const checkoutId = `ZC-${Date.now().toString(36).toUpperCase()}`;
    const year = new Date().getFullYear();
    const cntRow = await db.select({ c: count() }).from(orders);
    let seq = cntRow[0]?.c ?? 0;

    const sellerIds = [...groups.keys()];
    const sellerRows = await db.select().from(sellers).where(inArray(sellers.id, sellerIds));
    const sellerById = new Map(sellerRows.map((s) => [s.id, s]));

    const orderNumbers: string[] = [];
    let remainingDiscount = discount;
    let grandTotal = 0;

    for (const g of groups.values()) {
      const shipCents = quoteShipping({
        baseCents: method.baseCents,
        perKgCents: method.perKgCents,
        surchargeCents: country.surchargeCents,
        weightGrams: g.weightGrams,
        daysMin: method.daysMin,
        daysMax: method.daysMax,
      });
      const d = Math.min(remainingDiscount, g.subtotal);
      remainingDiscount -= d;

      seq += 1;
      const orderNumber = `ZT-${year}-${String(seq).padStart(6, "0")}`;
      const [order] = await db
        .insert(orders)
        .values({
          orderNumber,
          checkoutId,
          userId: u.id,
          sellerId: g.sellerId,
          subtotalCents: g.subtotal,
          discountCents: d,
          shippingCents: shipCents,
          totalCents: g.subtotal - d + shipCents,
          currency: "USD",
          status: "pending",
          address,
          note: vStr(body.note, 500) || null,
        })
        .returning();
      orderNumbers.push(orderNumber);
      grandTotal += order.totalCents;

      for (const { p, qty } of g.items) {
        await db.insert(orderItems).values({
          orderId: order.id,
          productId: p.id,
          productNameAr: p.nameAr,
          productNameEn: p.nameEn,
          priceCents: p.priceCents,
          quantity: qty,
          weightGrams: p.weightGrams * qty,
          image: p.images[0] ?? null,
        });
        const dec = await db
          .update(products)
          .set({ stock: sql`stock - ${qty}`, salesCount: sql`sales_count + ${qty}` })
          .where(and(eq(products.id, p.id), gte(products.stock, qty)))
          .returning({ id: products.id });
        if (!dec.length) throw new ApiError(409, `تغير المخزون: ${p.nameEn}`, `Stock changed: ${p.nameEn}`);
      }

      /* Payment — MOCK provider. Replace with Stripe/PayPal provider in the payment layer (README). */
      await db.insert(payments).values({
        orderId: order.id,
        provider: paymentProvider,
        status: "succeeded",
        amountCents: order.totalCents,
        last4,
      });

      const eta = etaRange(method.daysMin, method.daysMax, "en");
      await db.insert(shipments).values({
        orderId: order.id,
        carrier: null,
        trackingNumber: null,
        status: "pending",
        eta,
        events: [
          {
            status: "pending",
            at: new Date().toISOString(),
            noteAr: "تم استلام الطلب",
            noteEn: "Order received",
          },
        ],
      });

      const seller = sellerById.get(g.sellerId);
      if (seller) {
        await db.update(sellers).set({ orderCount: sql`order_count + 1` }).where(eq(sellers.id, seller.id));
        await db.insert(notifications).values({
          userId: seller.userId,
          type: "new_order",
          titleAr: `طلب جديد ${orderNumber}`,
          titleEn: `New order ${orderNumber}`,
          bodyAr: `طلب جديد بـ ${g.items.length} صنف من ${address.country}.`,
          bodyEn: `A new ${g.items.length}-item order from ${address.country}.`,
          link: "/dashboard/seller?tab=orders",
        });
      }
    }

    if (appliedOffer) await db.update(offers).set({ usageCount: sql`usage_count + 1` }).where(eq(offers.id, appliedOffer.id));

    await db.insert(notifications).values({
      userId: u.id,
      type: "order_created",
      titleAr: "تم استلام طلبك 🎉",
      titleEn: "Your order is confirmed 🎉",
      bodyAr: `رقم الطلب: ${orderNumbers.join("، ")} — سيتواصل معك البائع لتجهيزه.`,
      bodyEn: `Order number: ${orderNumbers.join(", ")} — the seller will prepare it shortly.`,
      link: "/orders",
    });

    return NextResponse.json({ ok: true, orderNumbers, totalCents: grandTotal, grandSubtotal, discount, checkoutId });
  } catch (e) {
    return errRes(e);
  }
}
