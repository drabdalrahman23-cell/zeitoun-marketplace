import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { countries, shippingMethods } from "@/db/schema";
import { eq } from "drizzle-orm";
import { errRes } from "@/lib/auth";
import { etaRange, quoteShipping, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

/**
 * Mock shipping calculator — rates come from the database (admin-editable).
 * Swap the internals with a real carrier API (DHL / Aramex / FedEx) later.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const countryCode = vStr(body.countryCode, 8).toUpperCase();
    const weightGrams = vInt(body.weightGrams, 100, 1000000);
    const methodId = vInt(body.methodId, 1);
    if (!countryCode) return NextResponse.json({ error: { ar: "اختر الدولة", en: "Select a country" } }, { status: 400 });

    const [cRows, mRows] = await Promise.all([
      db.select().from(countries).where(eq(countries.code, countryCode)),
      db.select().from(shippingMethods).where(eq(shippingMethods.id, methodId)),
    ]);
    const c = cRows.find((r) => r.active);
    const m = mRows.find((r) => r.active);
    if (!c || !m) return NextResponse.json({ error: { ar: "وجهة غير مدعومة حالياً", en: "Destination not supported" } }, { status: 400 });

    const quoteCents = quoteShipping({
      baseCents: m.baseCents,
      perKgCents: m.perKgCents,
      surchargeCents: c.surchargeCents,
      weightGrams,
      daysMin: m.daysMin,
      daysMax: m.daysMax,
    });
    return NextResponse.json({
      quoteCents,
      daysMin: m.daysMin,
      daysMax: m.daysMax,
      eta: etaRange(m.daysMin, m.daysMax, "en"),
    });
  } catch (e) {
    return errRes(e);
  }
}
