import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  adoptionCertificates,
  adoptionOrders,
  adoptionPrograms,
  adoptionUpdates,
  adoptions,
  farmers,
  farmerSupportPrograms,
  notifications,
  oliveTrees,
  orders,
  payments,
  sellers,
  treeSeasons,
} from "@/db/schema";
import { and, count, desc, eq, inArray, sql } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { issueCertificate, phaseProgress, toAdoptionView } from "@/lib/adoption";
import { vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function loadAdoption(id: number) {
  const rows = await db
    .select({ a: adoptions, t: oliveTrees, f: farmers, p: adoptionPrograms })
    .from(adoptions)
    .innerJoin(farmers, eq(adoptions.farmerId, farmers.id))
    .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
    .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
    .where(eq(adoptions.id, id));
  const row = rows[0];
  if (!row) return null;
  const last = (
    await db
      .select()
      .from(adoptionUpdates)
      .where(
        row.t
          ? and(eq(adoptionUpdates.farmerId, row.f.id), sql`(${adoptionUpdates.treeId} = ${row.t.id} or ${adoptionUpdates.treeId} is null)`)
          : eq(adoptionUpdates.farmerId, row.f.id),
      )
      .orderBy(desc(adoptionUpdates.createdAt))
      .limit(1)
  )[0];
  return { row, last };
}

function shape(row: any, last: any) {
  return toAdoptionView({
    ...row.a,
    program: row.p,
    tree: row.t,
    farmerRow: row.f,
    lastUpdate: last ? { ...last, treeCode: row.t?.treeCode ?? null } : null,
  });
}

/* ---------- GET: my adoptions, or one adoption ---------- */
export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    const { path } = await params;
    const sub = path[0] ?? "";

    if (sub) {
      const id = vInt(sub, 1);
      const loaded = await loadAdoption(id);
      if (!loaded) throw new ApiError(404, "الرعاية غير موجودة", "Sponsorship not found");
      if (loaded.row.a.userId !== u.id && u.role !== "admin") throw new ApiError(403, "لا تملك هذه الرعاية", "Not your sponsorship");
      const certRows = await db.select().from(adoptionCertificates).where(eq(adoptionCertificates.adoptionId, id));
      const orderRows = loaded.row.a.orderNumber
        ? await db.select().from(orders).where(eq(orders.orderNumber, loaded.row.a.orderNumber))
        : [];
      return NextResponse.json({
        adoption: shape(loaded.row, loaded.last),
        certificate: certRows[0]
          ? { code: certRows[0].code, qrDataUrl: certRows[0].qrDataUrl, issuedAt: new Date(certRows[0].issuedAt).toISOString() }
          : null,
        order: orderRows[0] ? { id: orderRows[0].id, orderNumber: orderRows[0].orderNumber, status: orderRows[0].status } : null,
      });
    }

    const rows = await db
      .select({ a: adoptions, t: oliveTrees, f: farmers, p: adoptionPrograms })
      .from(adoptions)
      .innerJoin(farmers, eq(adoptions.farmerId, farmers.id))
      .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
      .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
      .where(eq(adoptions.userId, u.id))
      .orderBy(desc(adoptions.createdAt))
      .limit(100);

    const farmerIds = [...new Set(rows.map((r) => r.f.id))];
    const updates = farmerIds.length
      ? await db
          .select()
          .from(adoptionUpdates)
          .where(and(inArray(adoptionUpdates.farmerId, farmerIds), eq(adoptionUpdates.published, true)))
          .orderBy(desc(adoptionUpdates.createdAt))
          .limit(200)
      : [];

    const items = rows.map((r) => {
      const last = updates.find((up) => up.farmerId === r.f.id && (!r.t || up.treeId === r.t.id || up.treeId === null));
      return shape(r, last);
    });

    /* renewal reminders: ending within 30 days or already expired */
    const soon = items.filter((i) => {
      if (i.status !== "active" || !i.endDate) return false;
      const days = (new Date(i.endDate).getTime() - Date.now()) / 86400000;
      return days <= 30;
    });

    return NextResponse.json({ items, renewSoon: soon.map((s) => s.id) });
  } catch (e) {
    return errRes(e);
  }
}

/* ---------- PATCH: rename the tree, or cancel ---------- */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    const { path } = await params;
    const id = vInt(path[0] ?? "", 1);
    const loaded = await loadAdoption(id);
    if (!loaded) throw new ApiError(404, "الرعاية غير موجودة", "Sponsorship not found");
    if (loaded.row.a.userId !== u.id && u.role !== "admin") throw new ApiError(403, "لا تملك هذه الرعاية", "Not your sponsorship");
    const a = loaded.row.a;

    const body = await req.json().catch(() => ({}));

    if (typeof body.displayName === "string") {
      if (a.renameCount >= 3) throw new ApiError(400, "وصلت الحد الأقصى لتغيير الاسم (3 مرات)", "Rename limit reached (3 times)");
      if (!["pending", "active", "paused"].includes(a.status)) throw new ApiError(400, "لا يمكن تغيير الاسم بعد انتهاء الرعاية", "Cannot rename after the sponsorship ends");
      const name = vStr(body.displayName, 120);
      await db.update(adoptions).set({ displayName: name || null, renameCount: a.renameCount + 1 }).where(eq(adoptions.id, id));
      await db.update(adoptionCertificates).set({ treeName: name || loaded.row.t?.nameEn || null }).where(eq(adoptionCertificates.adoptionId, id));
      return NextResponse.json({ ok: true });
    }

    if (body.status === "cancelled") {
      if (!["pending", "active"].includes(a.status)) throw new ApiError(400, "لا يمكن إلغاء هذه الرعاية", "This sponsorship cannot be cancelled");
      await db.update(adoptions).set({ status: "cancelled" }).where(eq(adoptions.id, id));
      if (a.treeId) {
        const t = loaded.row.t;
        if (t) {
          const newCount = Math.max(0, t.sponsorCount - 1);
          await db.update(oliveTrees).set({ sponsorCount: newCount, status: newCount > 0 ? "reserved" : "available" }).where(eq(oliveTrees.id, t.id));
        }
      }
      await db.update(farmers).set({ sponsorCount: sql`greatest(sponsor_count - 1, 0)` }).where(eq(farmers.id, a.farmerId));
      return NextResponse.json({ ok: true });
    }

    throw new ApiError(400, "طلب غير صالح", "Invalid request");
  } catch (e) {
    return errRes(e);
  }
}

/* ---------- POST: renew a sponsorship (mock payment; no auto-recurring billing) ---------- */
export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    const { path } = await params;
    if (path[1] !== "renew") throw new ApiError(404, "غير موجود", "Not found");
    const id = vInt(path[0] ?? "", 1);
    const loaded = await loadAdoption(id);
    if (!loaded) throw new ApiError(404, "الرعاية غير موجودة", "Sponsorship not found");
    if (loaded.row.a.userId !== u.id) throw new ApiError(403, "لا تملك هذه الرعاية", "Not your sponsorship");
    const a = loaded.row.a;
    if (!["active", "expired", "completed", "paused"].includes(a.status))
      throw new ApiError(400, "لا يمكن تجديد هذه الرعاية", "This sponsorship cannot be renewed");

    const program = loaded.row.p;
    const farmer = loaded.row.f;
    const tree = loaded.row.t;
    const body = await req.json().catch(() => ({}));
    const origin = req.headers.get("origin") ?? req.headers.get("host") ?? "";
    const publicBase = origin.startsWith("http") ? origin : origin ? `https://${origin}` : "";

    const fsp = (
      await db
        .select()
        .from(farmerSupportPrograms)
        .where(and(eq(farmerSupportPrograms.farmerId, farmer.id), eq(farmerSupportPrograms.programId, program.id)))
    )[0];
    if (!fsp || !fsp.allowed) throw new ApiError(400, "البرنامج لم يعد متاحًا لهذا المزارع", "Program no longer available for this farmer");
    const priceCents = fsp.allowPriceOverride && fsp.customPriceCents ? fsp.customPriceCents : program.renewalPriceCents;

    if (!farmer.sellerId) throw new ApiError(400, "المزارع غير مرتبط بمتجر", "Farmer not linked to a store");
    const seller = (await db.select().from(sellers).where(eq(sellers.id, farmer.sellerId)))[0];

    const year = new Date().getFullYear();
    const seq = ((await db.select({ c: count() }).from(orders))[0]?.c ?? 0) + 1;
    const orderNumber = `ZT-${year}-${String(seq).padStart(6, "0")}`;

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber,
        checkoutId: `ZR-${Date.now().toString(36).toUpperCase()}`,
        orderType: "ADOPTION_ORDER" as never,
        userId: u.id,
        sellerId: seller.id,
        subtotalCents: priceCents,
        shippingCents: 0,
        totalCents: priceCents,
        currency: "USD",
        status: "confirmed",
        address: { note: "adoption renewal" },
      })
      .returning();

    await db.insert(payments).values({
      orderId: order.id,
      provider: body.paymentProvider === "cod" ? "mock_cod" : "mock_card",
      status: "succeeded",
      amountCents: priceCents,
      last4: (vStr(body.cardLast4, 4) || "").replace(/\D/g, "").slice(-4) || null,
    });

    const startDate = new Date();
    const endDate = new Date(startDate.getTime() + program.durationDays * 86400000);
    const [renewal] = await db
      .insert(adoptions)
      .values({
        userId: u.id,
        treeId: a.treeId,
        farmerId: a.farmerId,
        programId: a.programId,
        seasonId: a.seasonId,
        orderNumber,
        displayName: a.displayName,
        status: "active",
        startDate,
        endDate,
        renewedFromId: a.id,
        priceCents,
      })
      .returning();

    await db.insert(adoptionOrders).values({
      orderId: order.id,
      adoptionId: renewal.id,
      programId: program.id,
      treeId: a.treeId,
      amountCents: priceCents,
      isRenewal: true,
    });
    await db.update(adoptions).set({ status: "renewed" }).where(eq(adoptions.id, a.id));

    if (tree) {
      await db.update(oliveTrees).set({ status: "adopted" }).where(eq(oliveTrees.id, tree.id));
      const sRow = (await db.select().from(treeSeasons).where(and(eq(treeSeasons.treeId, tree.id), eq(treeSeasons.season, tree.season))))[0];
      if (sRow) await db.update(adoptions).set({ seasonId: sRow.id }).where(eq(adoptions.id, renewal.id));
    }

    const cert = await issueCertificate(renewal.id, { publicBase });

    await db.insert(notifications).values({
      userId: u.id,
      type: "adoption_renewed",
      titleAr: "🌿 تم تجديد رعاية شجرتك",
      titleEn: "🌿 Your tree sponsorship was renewed",
      bodyAr: tree ? `${tree.treeCode} — موسم جديد يبدأ الآن.` : `موسم جديد مع ${farmer.nameAr}.`,
      bodyEn: tree ? `${tree.treeCode} — a new season starts now.` : `A new season with ${farmer.nameEn}.`,
      link: cert ? `/certificate/${cert.code}` : "/my-trees",
    });

    return NextResponse.json({
      ok: true,
      adoptionId: renewal.id,
      orderNumber,
      certificateCode: cert?.code ?? null,
      totalCents: priceCents,
      endDate: endDate.toISOString(),
    });
  } catch (e) {
    return errRes(e);
  }
}
