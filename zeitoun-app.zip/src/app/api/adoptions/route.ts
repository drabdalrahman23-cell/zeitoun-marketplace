import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adoptionPrograms, adoptionUpdates, adoptions, farmers, oliveTrees } from "@/db/schema";
import { and, desc, eq, inArray } from "drizzle-orm";
import { errRes, requireUser } from "@/lib/auth";
import { toAdoptionView } from "@/lib/adoption";

export const dynamic = "force-dynamic";

/**
 * GET /api/adoptions — the signed-in user's sponsorships ("My olive trees").
 * Sub-routes (/:id, /:id/renew) live in [...path]/route.ts.
 */
export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);

    const rows = await db
      .select({ a: adoptions, t: oliveTrees, f: farmers, p: adoptionPrograms })
      .from(adoptions)
      .innerJoin(farmers, eq(adoptions.farmerId, farmers.id))
      .innerJoin(adoptionPrograms, eq(adoptions.programId, adoptionPrograms.id))
      .leftJoin(oliveTrees, eq(adoptions.treeId, oliveTrees.id))
      .where(eq(adoptions.userId, u.id))
      .orderBy(desc(adoptions.createdAt))
      .limit(100);

    const farmerIds = [...new Set(rows.map((r) => r.f.id))];
    const updates = farmerIds.length
      ? await db
          .select()
          .from(adoptionUpdates)
          .where(and(inArray(adoptionUpdates.farmerId, farmerIds), eq(adoptionUpdates.published, true)))
          .orderBy(desc(adoptionUpdates.createdAt))
          .limit(200)
      : [];

    const items = rows.map((r) => {
      const last = updates.find((up) => up.farmerId === r.f.id && (!r.t || up.treeId === r.t.id || up.treeId === null));
      return toAdoptionView({
        ...r.a,
        program: r.p,
        tree: r.t,
        farmerRow: r.f,
        lastUpdate: last ? { ...last, treeCode: r.t?.treeCode ?? null } : null,
      });
    });

    /* renewal reminders: active sponsorships ending within 30 days */
    const renewSoon = items
      .filter((i) => {
        if (i.status !== "active" || !i.endDate) return false;
        return (new Date(i.endDate).getTime() - Date.now()) / 86400000 <= 30;
      })
      .map((i) => i.id);

    return NextResponse.json({ items, renewSoon });
  } catch (e) {
    return errRes(e);
  }
}
