import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notifications, orderItems, orders, payments, products, sellers, shipments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { mockCarrier, mockTrackingNumber, vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

const NOTES: Record<string, { ar: string; en: string }> = {
  pending: { ar: "تم استلام الطلب", en: "Order received" },
  confirmed: { ar: "تم تأكيد الطلب", en: "Order confirmed" },
  preparing: { ar: "جارٍ تجهيز المنتج", en: "Being prepared" },
  ready: { ar: "جاهز للشحن", en: "Ready for shipping" },
  shipped: { ar: "تم الشحن", en: "Shipped" },
  in_transit: { ar: "في الطريق إليك", en: "In transit" },
  delivered: { ar: "تم التسليم", en: "Delivered" },
  cancelled: { ar: "تم إلغاء الطلب", en: "Order cancelled" },
  refunded: { ar: "تم استرداد المبلغ", en: "Refunded" },
};

const SELLER_NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["ready"],
  ready: ["shipped"],
  shipped: ["in_transit"],
  in_transit: ["delivered"],
  delivered: ["refunded"],
  cancelled: [],
  refunded: [],
};

async function getOrder(id: number) {
  const rows = await db
    .select({ o: orders, s: sellers, p: payments })
    .from(orders)
    .innerJoin(sellers, eq(orders.sellerId, sellers.id))
    .leftJoin(payments, eq(payments.orderId, orders.id))
    .where(eq(orders.id, id));
  return rows[0] ?? null;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const u = await requireUser(req);
    const { id: rawId } = await params;
    const id = vInt(rawId, 1);
    const row = await getOrder(id);
    if (!row) throw new ApiError(404, "الطلب غير موجود", "Order not found");

    const sellerRows = await db.select().from(sellers).where(eq(sellers.id, row.o.sellerId));
    const seller = sellerRows[0];
    const isOwner = row.o.userId === u.id;
    const isSeller = seller.userId === u.id;
    if (!isOwner && !isSeller && u.role !== "admin") throw new ApiError(403, "لا تملك هذا الطلب", "You don't have access to this order");

    const itemRows = await db
      .select({ it: orderItems, p: products })
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, id));

    const shipRows = await db.select().from(shipments).where(eq(shipments.orderId, id));
    const ship = shipRows[0];

    return NextResponse.json({
      order: {
        id: row.o.id,
        orderNumber: row.o.orderNumber,
        status: row.o.status,
        createdAt: new Date(row.o.createdAt).toISOString(),
        updatedAt: new Date(row.o.updatedAt).toISOString(),
        subtotalCents: row.o.subtotalCents,
        discountCents: row.o.discountCents,
        shippingCents: row.o.shippingCents,
        totalCents: row.o.totalCents,
        currency: row.o.currency,
        address: row.o.address,
        note: row.o.note,
        seller: { id: row.s.id, slug: row.s.slug, shopName: row.s.shopName, city: row.s.city },
        payment: row.p
          ? { provider: row.p.provider, status: row.p.status, last4: row.p.last4, amountCents: row.p.amountCents }
          : null,
        isOwner,
        isSeller,
      },
      items: itemRows.map(({ it, p }) => ({
        id: it.id,
        productId: it.productId,
        productSlug: p?.slug ?? null,
        productNameAr: it.productNameAr,
        productNameEn: it.productNameEn,
        priceCents: it.priceCents,
        quantity: it.quantity,
        image: it.image,
      })),
      shipment: ship
        ? {
            carrier: ship.carrier,
            trackingNumber: ship.trackingNumber,
            status: ship.status,
            eta: ship.eta,
            events: (ship.events ?? []) as { status: string; at: string; noteAr?: string; noteEn?: string }[],
          }
        : null,
    });
  } catch (e) {
    return errRes(e);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const u = await requireUser(req);
    const { id: rawId } = await params;
    const id = vInt(rawId, 1);
    const rows = await db.select().from(orders).where(eq(orders.id, id));
    const o = rows[0];
    if (!o) throw new ApiError(404, "الطلب غير موجود", "Order not found");

    const sellerRows = await db.select().from(sellers).where(eq(sellers.id, o.sellerId));
    const seller = sellerRows[0];
    const isOwner = o.userId === u.id;
    const isSeller = seller.userId === u.id;
    if (!isOwner && !isSeller && u.role !== "admin") throw new ApiError(403, "لا تملك هذا الطلب", "You don't have access to this order");

    const body = await req.json().catch(() => ({}));
    const to = vStr(body.status, 30);
    const ALL = Object.keys(NOTES);
    let allowed: string[];
    if (u.role === "admin") allowed = ALL;
    else if (isSeller) allowed = SELLER_NEXT[o.status] ?? [];
    else allowed = o.status === "pending" || o.status === "confirmed" ? ["cancelled"] : [];

    if (!ALL.includes(to) || !allowed.includes(to) || to === o.status)
      throw new ApiError(400, "لا يمكن تغيير الحالة إلى هذا", "Cannot change to this status");

    await db.update(orders).set({ status: to as never, updatedAt: new Date() }).where(eq(orders.id, o.id));

    let ship = (await db.select().from(shipments).where(eq(shipments.orderId, o.id)))[0];
    if (!ship) {
      [ship] = await db.insert(shipments).values({ orderId: o.id, status: to }).returning();
    }
    const events = [...((ship.events ?? []) as { status: string; at: string; noteAr?: string; noteEn?: string }[])];
    events.push({ status: to, at: new Date().toISOString(), noteAr: NOTES[to].ar, noteEn: NOTES[to].en });
    const patch: Record<string, unknown> = { status: to, events };
    if (to === "shipped" && !ship.trackingNumber) {
      patch.trackingNumber = mockTrackingNumber();
      patch.carrier = mockCarrier();
    }
    await db.update(shipments).set(patch as never).where(eq(shipments.id, ship.id));

    await db.insert(notifications).values({
      userId: o.userId,
      type: "order_status",
      titleAr: `طلبك ${o.orderNumber}: ${NOTES[to].ar}`,
      titleEn: `Order ${o.orderNumber}: ${NOTES[to].en}`,
      bodyAr: NOTES[to].ar,
      bodyEn: NOTES[to].en,
      link: `/orders/${o.id}`,
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
