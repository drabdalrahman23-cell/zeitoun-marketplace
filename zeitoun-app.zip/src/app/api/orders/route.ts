import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orderItems, orders, sellers, users } from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import { errRes, requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const scope = req.nextUrl.searchParams.get("scope") ?? "me";

    let where;
    if (scope === "seller" && u.role === "seller") {
      const sRows = await db.select().from(sellers).where(eq(sellers.userId, u.id));
      const seller = sRows[0];
      if (!seller) return NextResponse.json({ items: [] });
      where = eq(orders.sellerId, seller.id);
    } else {
      where = eq(orders.userId, u.id);
    }

    const rows = await db
      .select({ o: orders, s: sellers, usr: users })
      .from(orders)
      .innerJoin(sellers, eq(orders.sellerId, sellers.id))
      .innerJoin(users, eq(orders.userId, users.id))
      .where(where)
      .orderBy(desc(orders.createdAt))
      .limit(100);

    const ids = rows.map((r) => r.o.id);
    const itemRows = ids.length ? await db.select().from(orderItems).where(inArray(orderItems.orderId, ids)) : [];
    const byOrder = new Map<number, typeof itemRows>();
    for (const it of itemRows) {
      const arr = byOrder.get(it.orderId) ?? [];
      arr.push(it);
      byOrder.set(it.orderId, arr);
    }

    const items = rows.map(({ o, s, usr }) => {
      const its = byOrder.get(o.id) ?? [];
      const first = its[0];
      return {
        id: o.id,
        orderNumber: o.orderNumber,
        status: o.status,
        createdAt: new Date(o.createdAt).toISOString(),
        updatedAt: new Date(o.updatedAt).toISOString(),
        subtotalCents: o.subtotalCents,
        discountCents: o.discountCents,
        shippingCents: o.shippingCents,
        totalCents: o.totalCents,
        currency: o.currency,
        itemCount: its.reduce((n: number, x) => n + x.quantity, 0),
        firstItemNameAr: first?.productNameAr ?? null,
        firstItemNameEn: first?.productNameEn ?? null,
        firstItemImage: first?.image ?? null,
        seller: { id: s.id, slug: s.slug, shopName: s.shopName, city: s.city },
        customerName: usr.name,
        address: o.address,
      };
    });

    return NextResponse.json({ items });
  } catch (e) {
    return errRes(e);
  }
}
