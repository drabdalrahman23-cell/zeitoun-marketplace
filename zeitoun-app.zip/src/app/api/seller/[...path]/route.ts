import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories, orders, products, sellerApplications, sellers } from "@/db/schema";
import { and, asc, count, desc, eq, gte, inArray, ne, sql } from "drizzle-orm";
import { ApiError, errRes, requireRole, requireUser, type SessionUser } from "@/lib/auth";
import { vInt, vStr, vUrls } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function mySeller(u: SessionUser) {
  const rows = await db.select().from(sellers).where(eq(sellers.userId, u.id));
  return rows[0] ?? null;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    const { path } = await params;
    const sub = path[0] ?? "";
    const s = await mySeller(u);

    if (sub === "" || sub === "status") {
      const apps = await db
        .select()
        .from(sellerApplications)
        .where(eq(sellerApplications.userId, u.id))
        .orderBy(desc(sellerApplications.id))
        .limit(3);
      return NextResponse.json({
        seller: s
          ? {
              id: s.id,
              slug: s.slug,
              shopName: s.shopName,
              region: s.region,
              city: s.city,
              about: s.about,
              story: s.story,
              images: s.images,
              allowMessages: s.allowMessages,
              rating: Number(s.rating),
              orderCount: s.orderCount,
              joinedAt: new Date(s.joinedAt).toISOString(),
              status: s.status,
            }
          : null,
        applications: apps.map((a) => ({
          id: a.id,
          shopName: a.shopName,
          status: a.status,
          note: a.note,
          createdAt: new Date(a.createdAt).toISOString(),
        })),
      });
    }

    if (sub === "stats") {
      if (!s) throw new ApiError(403, "لا يوجد متجر بعد", "No store yet");
      const daySince = new Date(Date.now() - 13 * 86400000);
      const monthSince = new Date();
      monthSince.setMonth(monthSince.getMonth() - 5);

      const [totalsArr, pendArr, doneArr, prodArr, dayRows, monthRows] = await Promise.all([
        db
          .select({ c: count(), revenue: sql<number>`coalesce(sum(total_cents),0)` })
          .from(orders)
          .where(and(eq(orders.sellerId, s.id), ne(orders.status, "cancelled"), ne(orders.status, "refunded"))),
        db
          .select({ c: count() })
          .from(orders)
          .where(and(eq(orders.sellerId, s.id), inArray(orders.status, ["pending", "confirmed", "preparing", "ready"]))),
        db.select({ c: count() }).from(orders).where(and(eq(orders.sellerId, s.id), eq(orders.status, "delivered"))),
        db
          .select({ c: count(), active: sql<number>`count(*) filter (where "status" = 'active')` })
          .from(products)
          .where(eq(products.sellerId, s.id)),
        db
          .select({ day: sql<string>`to_char(date_trunc('day', created_at), 'YYYY-MM-DD')`, total: sql<number>`coalesce(sum(total_cents),0)` })
          .from(orders)
          .where(and(eq(orders.sellerId, s.id), ne(orders.status, "cancelled"), ne(orders.status, "refunded"), gte(orders.createdAt, daySince)))
          .groupBy(sql`date_trunc('day', created_at)`)
          .orderBy(sql`date_trunc('day', created_at)`),
        db
          .select({ m: sql<string>`to_char(date_trunc('month', created_at), 'YYYY-MM')`, total: sql<number>`coalesce(sum(total_cents),0)` })
          .from(orders)
          .where(and(eq(orders.sellerId, s.id), ne(orders.status, "cancelled"), ne(orders.status, "refunded"), gte(orders.createdAt, monthSince)))
          .groupBy(sql`date_trunc('month', created_at)`)
          .orderBy(sql`date_trunc('month', created_at)`),
      ]);

      const byDay: { label: string; cents: number }[] = [];
      const dayKey = (i: number) => new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      const dayIndex = new Map<string, number>();
      for (let i = 13; i >= 0; i--) {
        const key = dayKey(i);
        dayIndex.set(key, byDay.length);
        byDay.push({ label: new Date(Date.now() - i * 86400000).toLocaleDateString("en", { day: "numeric", month: "numeric" }), cents: 0 });
      }
      for (const r of dayRows) {
        const idx = dayIndex.get(r.day);
        if (idx !== undefined) byDay[idx].cents = Number(r.total);
      }

      const byMonth: { label: string; cents: number }[] = [];
      const monthIndex = new Map<string, number>();
      for (let i = 5; i >= 0; i--) {
        const dt = new Date();
        dt.setMonth(dt.getMonth() - i);
        const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}`;
        monthIndex.set(key, byMonth.length);
        byMonth.push({ label: dt.toLocaleDateString("en", { month: "short", year: "2-digit" }), cents: 0 });
      }
      for (const r of monthRows) {
        const idx = monthIndex.get(r.m);
        if (idx !== undefined) byMonth[idx].cents = Number(r.total);
      }

      return NextResponse.json({
        totalSalesCents: Number(totalsArr[0]?.revenue ?? 0),
        totalOrders: totalsArr[0]?.c ?? 0,
        pendingOrders: pendArr[0]?.c ?? 0,
        completedOrders: doneArr[0]?.c ?? 0,
        productCount: prodArr[0]?.c ?? 0,
        activeProducts: Number(prodArr[0]?.active ?? 0),
        byDay,
        byMonth,
      });
    }

    if (sub === "products") {
      if (!s) throw new ApiError(403, "No store yet", "No store yet");
      const [prods, cats] = await Promise.all([
        db.select().from(products).where(eq(products.sellerId, s.id)).orderBy(desc(products.createdAt)),
        db.select().from(categories).where(eq(categories.active, true)).orderBy(asc(categories.sortOrder)),
      ]);
      return NextResponse.json({
        items: prods.map((p) => ({
          id: p.id,
          slug: p.slug,
          nameAr: p.nameAr,
          nameEn: p.nameEn,
          descriptionAr: p.descriptionAr,
          descriptionEn: p.descriptionEn,
          priceCents: p.priceCents,
          stock: p.stock,
          weightGrams: p.weightGrams,
          dimensions: p.dimensions,
          originRegion: p.originRegion,
          images: p.images,
          storyAr: p.storyAr,
          storyEn: p.storyEn,
          productionMethodAr: p.productionMethodAr,
          productionMethodEn: p.productionMethodEn,
          ingredientsAr: p.ingredientsAr,
          ingredientsEn: p.ingredientsEn,
          usageAr: p.usageAr,
          usageEn: p.usageEn,
          allergensAr: p.allergensAr,
          allergensEn: p.allergensEn,
          harvestSeason: p.harvestSeason,
          shipsInternational: p.shipsInternational,
          status: p.status,
          isFeatured: p.isFeatured,
          salesCount: p.salesCount,
          rating: Number(p.rating),
          reviewCount: p.reviewCount,
          categoryId: p.categoryId,
        })),
        categories: cats,
      });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["seller", "admin"]);
    const s = await mySeller(u);
    if (!s) throw new ApiError(404, "لا يوجد متجر بعد", "No store yet");
    const body = await req.json().catch(() => ({}));
    const patch: Record<string, unknown> = {};
    if (typeof body.shopName === "string" && body.shopName.trim()) patch.shopName = vStr(body.shopName, 140);
    if (typeof body.city === "string") patch.city = vStr(body.city, 120) || null;
    if (typeof body.region === "string") patch.region = vStr(body.region, 120) || null;
    if (typeof body.about === "string") patch.about = vStr(body.about, 2000) || null;
    if (typeof body.story === "string") patch.story = vStr(body.story, 4000) || null;
    if (Array.isArray(body.images)) patch.images = vUrls(body.images, 6);
    if (typeof body.allowMessages === "boolean") patch.allowMessages = body.allowMessages;
    if (Object.keys(patch).length === 0) throw new ApiError(400, "لا توجد تعديلات", "Nothing to update");
    await db.update(sellers).set(patch as never).where(eq(sellers.id, s.id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
