import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reports } from "@/db/schema";
import { vStr } from "@/lib/utils";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { vInt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const targetType = vStr(body.targetType, 20);
    const targetId = vInt(body.targetId, 1);
    const reason = vStr(body.reason, 1000);
    if (targetType !== "user" && targetType !== "message") throw new ApiError(400, "نوع التبليغ غير صالح", "Invalid report type");
    if (!reason) throw new ApiError(400, "اكتب سبب التبليغ", "Please provide a reason");
    await db.insert(reports).values({ targetType, targetId, reporterId: u.id, reason });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
