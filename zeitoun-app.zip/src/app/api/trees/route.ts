import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adoptionPrograms, farmers, farmerSupportPrograms, oliveTrees } from "@/db/schema";
import { and, asc, count, desc, eq, gte, ilike, inArray, type SQL } from "drizzle-orm";
import { errRes } from "@/lib/auth";
import { toTreeView } from "@/lib/adoption";

export const dynamic = "force-dynamic";

/**
 * Public tree listing. Only verified + available trees are exposed,
 * so unverified/fake trees never reach the public adoption page.
 */
export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const region = sp.get("region") ?? "";
    const farmerSlug = sp.get("farmer") ?? "";
    const programId = parseInt(sp.get("program") ?? "", 10);
    const q = (sp.get("q") ?? "").trim();
    const sort = sp.get("sort") ?? "newest";
    const includeAll = sp.get("all") === "1"; // admin/farmer dashboards
    const page = Math.max(1, parseInt(sp.get("page") ?? "1", 10) || 1);
    const limit = 24;

    const conds: SQL[] = [];
    if (!includeAll) {
      conds.push(eq(oliveTrees.verified, true), eq(oliveTrees.status, "available"));
    }
    if (region) conds.push(ilike(oliveTrees.region, `%${region}%`));
    if (q)
      conds.push(
        ilike(oliveTrees.nameAr, `%${q}%`),
        ilike(oliveTrees.nameEn, `%${q}%`),
        ilike(oliveTrees.oliveVariety, `%${q}%`),
        ilike(oliveTrees.treeCode, `%${q}%`),
      );
    if (farmerSlug) conds.push(eq(farmers.slug, farmerSlug));
    if (!Number.isNaN(programId)) {
      // only trees whose farmer participates in this program
      conds.push(
        inArray(
          oliveTrees.farmerId,
          db.select({ fid: farmerSupportPrograms.farmerId }).from(farmerSupportPrograms).where(and(eq(farmerSupportPrograms.programId, programId), eq(farmerSupportPrograms.allowed, true))),
        ),
      );
    }

    const where = conds.length ? and(...conds) : undefined;
    const totalRow = await db.select({ c: count() }).from(oliveTrees).where(where);
    const total = totalRow[0]?.c ?? 0;

    const orderBy =
      sort === "age"
        ? [desc(oliveTrees.approximateAge)]
        : sort === "region"
          ? [asc(oliveTrees.region)]
          : [desc(oliveTrees.verifiedAt), desc(oliveTrees.createdAt)];

    const rows = await db
      .select({ t: oliveTrees, f: farmers })
      .from(oliveTrees)
      .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
      .where(where)
      .orderBy(...orderBy)
      .limit(limit)
      .offset((page - 1) * limit);

    const regions = await db
      .select({ region: oliveTrees.region, c: count() })
      .from(oliveTrees)
      .where(eq(oliveTrees.verified, true))
      .groupBy(oliveTrees.region);

    return NextResponse.json({
      items: rows.map((r) => toTreeView({ ...r.f, ...r.t })),
      total,
      page,
      pages: Math.max(1, Math.ceil(total / limit)),
      regions: regions.filter((r) => r.region).map((r) => ({ region: r.region as string, count: r.c })),
    });
  } catch (e) {
    return errRes(e);
  }
}
