import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adoptionPrograms, adoptionUpdates, farmers, farmerSupportPrograms, oliveTrees, products, treeSeasons } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { ApiError, errRes } from "@/lib/auth";
import { latestUpdates, toFarmerFull, toProgramView, toTreeFull } from "@/lib/adoption";

export const dynamic = "force-dynamic";

/** Public tree page data: tree + farmer + season timeline + updates + available programs. */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await params;
    const rows = await db
      .select({ t: oliveTrees, f: farmers })
      .from(oliveTrees)
      .innerJoin(farmers, eq(oliveTrees.farmerId, farmers.id))
      .where(eq(oliveTrees.treeCode, code.toUpperCase()));
    const row = rows[0];
    if (!row) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");
    if (!row.t.verified) throw new ApiError(404, "الشجرة غير موجودة", "Tree not found");

    const [seasonRows, progRows, prodRows] = await Promise.all([
      db.select().from(treeSeasons).where(eq(treeSeasons.treeId, row.t.id)).orderBy(desc(treeSeasons.startedAt)).limit(5),
      db
        .select({ p: adoptionPrograms })
        .from(farmerSupportPrograms)
        .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
        .where(and(eq(farmerSupportPrograms.farmerId, row.f.id), eq(farmerSupportPrograms.allowed, true), eq(adoptionPrograms.active, true)))
        .orderBy(asc(adoptionPrograms.sortOrder)),
      db.select().from(products).where(and(eq(products.sellerId, row.f.sellerId as never), eq(products.status, "active"))).limit(8),
    ]);

    const updates = await latestUpdates(row.f.id, 10);

    return NextResponse.json({
      tree: toTreeFull({ ...row.f, ...row.t }),
      farmer: toFarmerFull(row.f),
      seasons: seasonRows.map((s) => ({
        id: s.id,
        season: s.season,
        phase: s.phase,
        progressPercent: s.progressPercent,
        startedAt: new Date(s.startedAt).toISOString(),
        endedAt: s.endedAt ? new Date(s.endedAt).toISOString() : null,
        notesAr: s.notesAr,
        notesEn: s.notesEn,
      })),
      programs: progRows.map((r) => toProgramView(r.p)),
      updates: updates.filter((u) => u.treeId === row.t.id || u.treeId === null),
      products: prodRows.map((p) => ({
        id: p.id,
        slug: p.slug,
        nameAr: p.nameAr,
        nameEn: p.nameEn,
        priceCents: p.priceCents,
        images: p.images,
        stock: p.stock,
        rating: Number(p.rating),
        reviewCount: p.reviewCount,
        salesCount: p.salesCount,
        weightGrams: p.weightGrams,
      })),
      qrTarget: `/trees/${row.t.treeCode}`,
    });
  } catch (e) {
    return errRes(e);
  }
}
