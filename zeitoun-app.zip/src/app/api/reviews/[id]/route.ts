import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ApiError, errRes, requireRole, requireUser } from "@/lib/auth";
import { vInt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const u = await requireUser(req);
    requireRole(u, ["admin"]);
    const id = vInt(params.then((p) => p.id), 1);
    const rows = await db.select().from(reviews).where(eq(reviews.id, id));
    if (!rows[0]) throw new ApiError(404, "التقييم غير موجود", "Review not found");
    await db.update(reviews).set({ status: "removed" }).where(eq(reviews.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
