import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notifications, orderItems, orders, products, reviews, sellers } from "@/db/schema";
import { and, count, eq, inArray, sql } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const productId = vInt(body.productId, 1);
    const rating = vInt(body.rating, 1, 5);
    if (rating < 1) throw new ApiError(400, "اختر تقييماً من 1 إلى 5", "Choose a rating from 1 to 5");

    const pRows = await db.select().from(products).where(eq(products.id, productId));
    const p = pRows[0];
    if (!p) throw new ApiError(404, "المنتج غير موجود", "Product not found");

    /* Reviews are only allowed after a delivered order containing this product */
    const myOrders = await db
      .select({ id: orders.id })
      .from(orders)
      .where(and(eq(orders.userId, u.id), eq(orders.status, "delivered")));
    if (!myOrders.length) throw new ApiError(403, "يمكنك التقييم بعد تسليم الطلب", "You can review once your order is delivered");
    const itemRows = await db
      .select({ orderId: orderItems.orderId })
      .from(orderItems)
      .where(and(eq(orderItems.productId, productId), inArray(orderItems.orderId, myOrders.map((o) => o.id))));
    if (!itemRows.length) throw new ApiError(403, "يمكنك التقييم بعد تسليم الطلب", "You can review once your order is delivered");
    const orderId = itemRows[0].orderId;

    const existing = await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.userId, u.id), eq(reviews.productId, productId)));

    const data = {
      rating,
      qualityRating: vInt(body.qualityRating, 1, 5),
      packagingRating: vInt(body.packagingRating, 1, 5),
      shippingRating: vInt(body.shippingRating, 1, 5),
      commentAr: vStr(body.commentAr, 2000) || null,
      commentEn: vStr(body.commentEn, 2000) || null,
      status: "active" as const,
      orderId,
    };

    if (existing.length) {
      await db.update(reviews).set(data as never).where(eq(reviews.id, existing[0].id));
    } else {
      await db.insert(reviews).values({ ...data, userId: u.id, productId });
    }

    const agg = await db
      .select({ avg: sql<number>`avg(rating)`, c: count() })
      .from(reviews)
      .where(and(eq(reviews.productId, productId), eq(reviews.status, "active")));
    await db
      .update(products)
      .set({ rating: (Number(agg[0]?.avg ?? 0) || 0).toFixed(1), reviewCount: agg[0]?.c ?? 0 })
      .where(eq(products.id, productId));

    const sellerRows = await db.select().from(sellers).where(eq(sellers.id, p.sellerId));
    const seller = sellerRows[0];
    if (seller) {
      await db.insert(notifications).values({
        userId: seller.userId,
        type: "review",
        titleAr: `تقييم جديد (${rating}★) على ${p.nameAr}`,
        titleEn: `New ${rating}-star review on ${p.nameEn}`,
        bodyAr: vStr(body.commentAr, 200) || null,
        bodyEn: vStr(body.commentEn, 200) || null,
        link: "/dashboard/seller?tab=products",
      });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
