import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { shippingAddresses } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

function validate(body: Record<string, unknown>) {
  const a = {
    label: vStr(body.label, 60) || "Home",
    fullName: vStr(body.fullName, 120),
    phone: vStr(body.phone, 40),
    country: vStr(body.country, 80),
    countryCode: vStr(body.countryCode, 8).toUpperCase(),
    state: vStr(body.state, 80),
    city: vStr(body.city, 80),
    addressLine: vStr(body.addressLine, 200),
    postalCode: vStr(body.postalCode, 20),
    isDefault: !!body.isDefault,
  };
  if (!a.fullName || !a.phone || !a.country || !a.city || !a.addressLine || !a.postalCode)
    throw new ApiError(400, "أكمل بيانات العنوان", "Please complete the address");
  return a;
}

export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const rows = await db.select().from(shippingAddresses).where(eq(shippingAddresses.userId, u.id)).orderBy(desc(shippingAddresses.isDefault), desc(shippingAddresses.id));
    return NextResponse.json({ items: rows });
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const a = validate(body);
    if (a.isDefault) await db.update(shippingAddresses).set({ isDefault: false }).where(eq(shippingAddresses.userId, u.id));
    const [row] = await db.insert(shippingAddresses).values({ ...a, userId: u.id }).returning();
    return NextResponse.json(row);
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);
    const a = validate(body);
    const rows = await db.select().from(shippingAddresses).where(and(eq(shippingAddresses.id, id), eq(shippingAddresses.userId, u.id)));
    if (!rows[0]) throw new ApiError(404, "العنوان غير موجود", "Address not found");
    if (a.isDefault) await db.update(shippingAddresses).set({ isDefault: false }).where(eq(shippingAddresses.userId, u.id));
    await db.update(shippingAddresses).set(a as never).where(eq(shippingAddresses.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const id = vInt(body.id, 1);
    await db.delete(shippingAddresses).where(and(eq(shippingAddresses.id, id), eq(shippingAddresses.userId, u.id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
