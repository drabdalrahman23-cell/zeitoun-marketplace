import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, currencies, countries, shippingMethods, siteContent } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { errRes } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [curRows, countryRows, catRows, methodRows, contentRows] = await Promise.all([
      db.select().from(currencies).where(eq(currencies.active, true)).orderBy(asc(currencies.id)),
      db.select().from(countries).where(eq(countries.active, true)).orderBy(asc(countries.nameEn)),
      db.select().from(categories).where(eq(categories.active, true)).orderBy(asc(categories.sortOrder)),
      db.select().from(shippingMethods).where(eq(shippingMethods.active, true)).orderBy(asc(shippingMethods.id)),
      db.select().from(siteContent),
    ]);
    return NextResponse.json({
      currencies: curRows.map((r) => ({
        code: r.code,
        nameAr: r.nameAr,
        nameEn: r.nameEn,
        symbol: r.symbol,
        ratePerUsd: Number(r.ratePerUsd),
      })),
      countries: countryRows.map((r) => ({
        code: r.code,
        nameAr: r.nameAr,
        nameEn: r.nameEn,
        region: r.region,
      })),
      categories: catRows.map((r) => ({
        id: r.id,
        slug: r.slug,
        nameAr: r.nameAr,
        nameEn: r.nameEn,
        icon: r.icon,
        sortOrder: r.sortOrder,
      })),
       shippingMethods: methodRows.map((r) => ({
        id: r.id,
        nameAr: r.nameAr,
        nameEn: r.nameEn,
        daysMin: r.daysMin,
        daysMax: r.daysMax,
      })),
      content: contentRows.map((r) => ({ key: r.key, value: r.value })),
    });
  } catch (e) {
    return errRes(e);
  }
}
