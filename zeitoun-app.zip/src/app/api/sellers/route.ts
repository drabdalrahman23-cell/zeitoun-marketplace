import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notifications, sellerApplications, sellers, users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { ApiError, errRes, requireUser } from "@/lib/auth";
import { vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    if (u.role !== "customer") throw new ApiError(400, "لديك متجر بالفعل", "You already have a store");
    const body = await req.json().catch(() => ({}));
    if (!body.agree) throw new ApiError(400, "يجب الموافقة على الشروط", "You must agree to the terms");
    const shopName = vStr(body.shopName, 140);
    if (!shopName) throw new ApiError(400, "أدخل اسم المتجر", "Enter a shop name");

    const sellerRows = await db.select({ id: sellers.id }).from(sellers).where(eq(sellers.userId, u.id));
    if (sellerRows.length) throw new ApiError(400, "لديك متجر بالفعل", "You already have a store");
    const pending = await db
      .select({ id: sellerApplications.id })
      .from(sellerApplications)
      .where(and(eq(sellerApplications.userId, u.id), eq(sellerApplications.status, "pending")));
    if (pending.length) throw new ApiError(400, "لديك طلب معلق بالفعل", "You already have a pending application");

    const types = Array.isArray(body.productTypes)
      ? body.productTypes
          .filter((x: unknown): x is string => typeof x === "string")
          .map((x: string) => vStr(x, 60))
          .filter(Boolean)
          .slice(0, 8)
      : [];

    await db.insert(sellerApplications).values({
      userId: u.id,
      shopName,
      city: vStr(body.city, 120) || null,
      region: vStr(body.region, 120) || null,
      about: vStr(body.about, 2000) || null,
      productTypes: types,
    });

    const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin"));
    if (admins.length) {
      await db.insert(notifications).values(
        admins.map((a) => ({
          userId: a.id,
          type: "application",
          titleAr: `طلب بيع جديد: ${shopName}`,
          titleEn: `New seller application: ${shopName}`,
          bodyAr: `${u.name} (${u.email}) تقدّم للبيع على زيتون.`,
          bodyEn: `${u.name} (${u.email}) applied to sell on Zeitoun.`,
          link: "/dashboard/admin?tab=sellers",
        })),
      );
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
