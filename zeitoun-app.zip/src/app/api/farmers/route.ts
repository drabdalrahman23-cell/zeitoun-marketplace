import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { farmers, oliveTrees } from "@/db/schema";
import { and, asc, desc, eq, ilike, sql } from "drizzle-orm";
import { errRes } from "@/lib/auth";
import { toFarmerMini } from "@/lib/adoption";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const region = sp.get("region") ?? "";
    const q = (sp.get("q") ?? "").trim();
    const sort = sp.get("sort") ?? "rating";

    const conds = [eq(farmers.active, true)];
    if (region) conds.push(ilike(farmers.region, `%${region}%`));
    if (q) conds.push(ilike(farmers.nameAr, `%${q}%`), ilike(farmers.nameEn, `%${q}%`), ilike(farmers.farmNameEn, `%${q}%`));

    const orderBy =
      sort === "trees" ? [desc(farmers.treeCount)] : sort === "newest" ? [desc(farmers.createdAt)] : [desc(farmers.rating), desc(farmers.sponsorCount)];

    const rows = await db
      .select({ f: farmers, available: sql<number>`(select count(*) from olive_trees where farmer_id = farmers.id and verified and status = 'available')` })
      .from(farmers)
      .where(and(...conds))
      .orderBy(...orderBy)
      .limit(60);

    return NextResponse.json({
      items: rows.map((r) => ({ ...toFarmerMini(r.f), availableTrees: Number(r.available) })),
    });
  } catch (e) {
    return errRes(e);
  }
}
