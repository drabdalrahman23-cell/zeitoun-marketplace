import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adoptionPrograms, farmers, farmerSupportPrograms, oliveTrees, products } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { ApiError, errRes } from "@/lib/auth";
import { latestUpdates, toFarmerFull, toProgramView, toTreeView } from "@/lib/adoption";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const rows = await db.select().from(farmers).where(eq(farmers.slug, slug));
    const f = rows[0];
    if (!f || !f.active) throw new ApiError(404, "المزارع غير موجود", "Farmer not found");

    const [treeRows, progRows, prodRows] = await Promise.all([
      db
        .select()
        .from(oliveTrees)
        .where(and(eq(oliveTrees.farmerId, f.id), eq(oliveTrees.verified, true)))
        .orderBy(desc(oliveTrees.createdAt))
        .limit(24),
      db
        .select({ p: adoptionPrograms, fsp: farmerSupportPrograms })
        .from(farmerSupportPrograms)
        .innerJoin(adoptionPrograms, eq(farmerSupportPrograms.programId, adoptionPrograms.id))
        .where(and(eq(farmerSupportPrograms.farmerId, f.id), eq(farmerSupportPrograms.allowed, true), eq(adoptionPrograms.active, true)))
        .orderBy(asc(adoptionPrograms.sortOrder)),
      f.sellerId
        ? db.select().from(products).where(and(eq(products.sellerId, f.sellerId), eq(products.status, "active"))).orderBy(desc(products.salesCount)).limit(8)
        : Promise.resolve([]),
    ]);

    const updates = await latestUpdates(f.id, 12);

    return NextResponse.json({
      farmer: toFarmerFull(f),
      trees: treeRows.map((t) => toTreeView({ ...f, ...t })),
      programs: progRows.map((r) => ({
        ...toProgramView(r.p),
        // farmer-specific price override (only when admin allowed it)
        priceCents: r.fsp.allowPriceOverride && r.fsp.customPriceCents ? r.fsp.customPriceCents : r.p.priceCents,
        slots: r.fsp.slots,
      })),
      products: prodRows.map((p) => ({
        id: p.id,
        slug: p.slug,
        nameAr: p.nameAr,
        nameEn: p.nameEn,
        priceCents: p.priceCents,
        images: p.images,
        stock: p.stock,
        rating: Number(p.rating),
        reviewCount: p.reviewCount,
        salesCount: p.salesCount,
        weightGrams: p.weightGrams,
      })),
      updates,
    });
  } catch (e) {
    return errRes(e);
  }
}
