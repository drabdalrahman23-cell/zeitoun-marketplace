import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { and, desc, eq, isNull } from "drizzle-orm";
import { errRes, requireUser } from "@/lib/auth";
import { vInt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const rows = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, u.id))
      .orderBy(desc(notifications.createdAt))
      .limit(60);
    const unread = rows.filter((r) => !r.readAt).length;
    return NextResponse.json({
      items: rows.map((r) => ({
        id: r.id,
        type: r.type,
        titleAr: r.titleAr,
        titleEn: r.titleEn,
        bodyAr: r.bodyAr,
        bodyEn: r.bodyEn,
        link: r.link,
        readAt: r.readAt ? new Date(r.readAt).toISOString() : null,
        createdAt: new Date(r.createdAt).toISOString(),
      })),
      unread,
    });
  } catch (e) {
    return errRes(e);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    if (body.all) {
      await db
        .update(notifications)
        .set({ readAt: new Date() })
        .where(and(eq(notifications.userId, u.id), isNull(notifications.readAt)));
    } else {
      const id = vInt(body.id, 1);
      await db
        .update(notifications)
        .set({ readAt: new Date() })
        .where(and(eq(notifications.userId, u.id), eq(notifications.id, id)));
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errRes(e);
  }
}
