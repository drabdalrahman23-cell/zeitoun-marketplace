import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages, notifications, sellers, users } from "@/db/schema";
import { and, asc, desc, eq, inArray, isNull, ne } from "drizzle-orm";
import { ApiError, errRes, requireUser, type SessionUser } from "@/lib/auth";
import { vInt, vStr } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function mySellerOf(userId: number) {
  const rows = await db.select().from(sellers).where(eq(sellers.userId, userId));
  return rows[0] ?? null;
}

async function isParticipant(conv: { buyerId: number; sellerId: number }, u: SessionUser) {
  if (conv.buyerId === u.id) return true;
  const s = await mySellerOf(u.id);
  return s ? s.id === conv.sellerId : false;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const u = await requireUser(req);
    const { path } = await params;
    const sub = path[0] ?? "";

    if (sub === "thread") {
      const cid = vInt(req.nextUrl.searchParams.get("cid"), 1);
      const convs = await db.select().from(conversations).where(eq(conversations.id, cid));
      const conv = convs[0];
      if (!conv) throw new ApiError(404, "المحادثة غير موجودة", "Conversation not found");
      if (!(await isParticipant(conv, u))) throw new ApiError(403, "ليس لديك صلاحية", "No access");
      const rows = await db.select().from(messages).where(eq(messages.conversationId, cid)).orderBy(asc(messages.createdAt)).limit(300);
      await db
        .update(messages)
        .set({ readAt: new Date() })
        .where(and(eq(messages.conversationId, cid), ne(messages.senderId, u.id), isNull(messages.readAt)));
      return NextResponse.json({
        messages: rows.map((m) => ({
          id: m.id,
          conversationId: m.conversationId,
          senderId: m.senderId,
          body: m.body,
          createdAt: new Date(m.createdAt).toISOString(),
        })),
        conversation: { id: conv.id, buyerId: conv.buyerId, sellerId: conv.sellerId, productId: conv.productId },
      });
    }

    if (sub === "") {
      const s = u.role !== "customer" ? await mySellerOf(u.id) : null;
      let items;
      if (s) {
        const rows = await db
          .select({ c: conversations, usr: users })
          .from(conversations)
          .innerJoin(users, eq(conversations.buyerId, users.id))
          .where(eq(conversations.sellerId, s.id))
          .orderBy(desc(conversations.createdAt))
          .limit(100);
        const cids = rows.map((r) => r.c.id);
        const allMsgs = cids.length ? await db.select().from(messages).where(inArray(messages.conversationId, cids)) : [];
        const byConv = new Map<number, typeof allMsgs>();
        for (const m of allMsgs) {
          const arr = byConv.get(m.conversationId) ?? [];
          arr.push(m);
          byConv.set(m.conversationId, arr);
        }
        items = rows.map((r) => {
          const ms = byConv.get(r.c.id) ?? [];
          const last = ms[ms.length - 1];
          const unread = ms.filter((m) => m.senderId !== u.id && !m.readAt).length;
          return {
            id: r.c.id,
            sellerId: r.c.sellerId,
            shopName: r.usr.name,
            buyerName: r.usr.name,
            lastBody: last?.body ?? null,
            lastAt: last ? new Date(last.createdAt).toISOString() : null,
            unread,
            productId: r.c.productId,
          };
        });
      } else {
        const rows = await db
          .select({ c: conversations, sl: sellers })
          .from(conversations)
          .innerJoin(sellers, eq(conversations.sellerId, sellers.id))
          .where(eq(conversations.buyerId, u.id))
          .orderBy(desc(conversations.createdAt))
          .limit(100);
        const cids = rows.map((r) => r.c.id);
        const allMsgs = cids.length ? await db.select().from(messages).where(inArray(messages.conversationId, cids)) : [];
        const byConv = new Map<number, typeof allMsgs>();
        for (const m of allMsgs) {
          const arr = byConv.get(m.conversationId) ?? [];
          arr.push(m);
          byConv.set(m.conversationId, arr);
        }
        items = rows.map((r) => {
          const ms = byConv.get(r.c.id) ?? [];
          const last = ms[ms.length - 1];
          const unread = ms.filter((m) => m.senderId !== u.id && !m.readAt).length;
          return {
            id: r.c.id,
            sellerId: r.sl.id,
            shopName: r.sl.shopName,
            buyerName: r.sl.shopName,
            lastBody: last?.body ?? null,
            lastAt: last ? new Date(last.createdAt).toISOString() : null,
            unread,
            productId: r.c.productId,
          };
        });
      }
      return NextResponse.json({ items });
    }

    throw new ApiError(404, "غير موجود", "Not found");
  } catch (e) {
    return errRes(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const u = await requireUser(req);
    const body = await req.json().catch(() => ({}));

    if (typeof body.conversationId === "number") {
      const cid = vInt(body.conversationId, 1);
      const text = vStr(body.body, 2000);
      if (!text) throw new ApiError(400, "اكتب رسالتك", "Type a message");
      const convs = await db.select().from(conversations).where(eq(conversations.id, cid));
      const conv = convs[0];
      if (!conv) throw new ApiError(404, "المحادثة غير موجودة", "Conversation not found");
      if (!(await isParticipant(conv, u))) throw new ApiError(403, "ليس لديك صلاحية", "No access");
      const [m] = await db.insert(messages).values({ conversationId: cid, senderId: u.id, body: text }).returning();
      const sellerOfConv = (await db.select().from(sellers).where(eq(sellers.id, conv.sellerId)))[0];
      const recipientId = u.id === conv.buyerId ? sellerOfConv.userId : conv.buyerId;
      if (recipientId) {
        await db.insert(notifications).values({
          userId: recipientId,
          type: "message",
          titleAr: `رسالة جديدة من ${u.name}`,
          titleEn: `New message from ${u.name}`,
          bodyAr: text.slice(0, 120),
          bodyEn: text.slice(0, 120),
          link: "/messages",
        });
      }
      return NextResponse.json({
        ok: true,
        message: { id: m.id, conversationId: cid, senderId: u.id, body: text, createdAt: new Date().toISOString() },
      });
    }

    /* Start a new conversation: { sellerId, productId? } */
    const sellerId = vInt(body.sellerId, 1);
    const productId = vInt(body.productId, 0) || null;
    const sRows = await db.select().from(sellers).where(eq(sellers.id, sellerId));
    const seller = sRows[0];
    if (!seller) throw new ApiError(404, "البائع غير موجود", "Seller not found");
    if (!seller.allowMessages) throw new ApiError(403, "البائع لا يستقبل الرسائل", "The seller does not accept messages");
    const existing = await db
      .select()
      .from(conversations)
      .where(and(eq(conversations.buyerId, u.id), eq(conversations.sellerId, sellerId)))
      .limit(1);
    if (existing[0]) return NextResponse.json({ conversationId: existing[0].id });
    const [c] = await db.insert(conversations).values({ buyerId: u.id, sellerId, productId }).returning();
    return NextResponse.json({ conversationId: c.id });
  } catch (e) {
    return errRes(e);
  }
}
