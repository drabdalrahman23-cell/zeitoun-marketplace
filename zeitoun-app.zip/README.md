# Zeitoun | زيتون 🫒

**"From the land of Palestine, to your door."**
**"من أرض فلسطين إلى بيتك مباشرة."**

Zeitoun is a multilingual (العربية / English, RTL & LTR) multi-vendor marketplace that connects
Palestinian farmers, artisans and local producers directly with customers in the US, Europe, the
Gulf and around the world — olive oil, honey, za'atar, tatreez, pottery, woodwork and more.
Every product has a face, a story and a place.

> Amazon-scale marketplace UX · Etsy-style maker stories · Palestinian identity

---

## Quick start

```bash
npm install
npm run dev            # or: npm run build && npm start
```

Open `http://localhost:3000`.

### 1. Apply the database schema

```bash
npx drizzle-kit push
```

### 2. Seed demo data

```bash
npx tsx src/db/seed.ts            # marketplace: users, sellers, products, orders, reviews
npx tsx src/db/seed-adoption.ts   # adoption: farmers, programs, trees, certificates, updates
```

### Demo accounts (development only — documented here, NOT in the UI)

| Role     | Email                | Password  |
|----------|----------------------|-----------|
| Admin    | `admin@zeitoun.app`  | `admin123`|
| Customer | `customer@zeitoun.app`| `demo123` |
| Seller   | `seller@zeitoun.app` | `demo123` |

The demo customer already has orders in different states (delivered / in-transit / pending) so you
can test tracking, reviews and notifications immediately.

---

## Environment variables (`.env`)

| Variable        | Purpose                                              |
|-----------------|------------------------------------------------------|
| `DATABASE_URL`  | PostgreSQL connection string                         |
| `AUTH_SECRET`   | JWT signing secret (HS256) — change in production    |
| `PAYMENT_PROVIDER` | `mock` today; swap for `stripe` / `paypal` later |
| `SHIPPING_PROVIDER`| `mock` today; swap for `aramex` / `dhl` / `fedex` |

Secrets are only read server-side. Never commit real secrets.

## Architecture

- **Framework**: Next.js (App Router) + TypeScript, Tailwind CSS v4
- **Database**: PostgreSQL via Drizzle ORM (`src/db/schema.ts`)
- **Auth**: JWT (jose) in an httpOnly cookie, bcrypt password hashing, role-based access
  (`customer` / `seller` / `admin`), in-memory rate limiting on auth endpoints
- **i18n**: centralized dictionary (`src/lib/i18n.ts`) + bilingual DB fields (`*_Ar` / `*_En`),
  RTL/LTR switching via a client store (`src/components/store.tsx`)
- **PWA**: `app/manifest.ts` + `public/sw.js` (installable, offline fallback for static assets)

```
src/
├── app/
│   ├── api/               # REST API (route handlers, all server-side)
│   │   ├── auth/[...path]    login/register/logout/google(mock)/forgot/reset/me
│   │   ├── products         search, filter, sort, paginate + seller create
│   │   ├── products/[slug]   detail / update / archive
│   │   ├── categories       public list + admin CRUD
│   │   ├── checkout         multi-vendor order split + mock payment
│   │   ├── orders           list / detail / status transitions
│   │   ├── reviews          post (purchase-gated) / admin remove
│   │   ├── favorites, addresses, notifications, reports
│   │   ├── sellers          seller application
│   │   ├── seller/[...path] my shop / stats / products / profile
│   │   ├── messages/[...path] conversations + threads
│   │   ├── admin/[...path]  stats, users, applications, sellers, products,
│   │   │                    orders, reviews, reports, content, currencies,
│   │   │                    shipping, offers
│   │   └── meta, shipping   public meta + mock shipping calculator
│   ├── products/[slug]     SEO-friendly product pages (generateMetadata + OG)
│   ├── dashboard/seller    seller dashboard (stats, products, orders, messages, profile)
│   └── dashboard/admin     admin dashboard (12 tabs)
├── components/            UI kit, store (lang/cart/currency/toasts), chrome, dashboards
├── db/                    schema.ts, seed.ts, index.ts
└── lib/                   i18n dictionary, auth, validation, views, mock providers
```

## Key flows

**Customer**: browse → product page (gallery, story, live shipping estimate per country) →
cart (grouped per seller) → checkout (address → method → payment → review) → mock payment →
order numbers (`ZT-2026-XXXXXX`) → timeline + mock tracking → review after delivery.

**Seller**: apply (`/apply-seller`) → admin approval → seller dashboard → add product
(story, images, weight, stock, price) → **pending moderation** → admin approval →
products go live → receive orders → advance status (confirmed → preparing → ready →
shipped → in transit → delivered) → earnings charts (by day / by month).

**Admin**: users (role/suspend/delete) · seller applications (approve/reject) · product
moderation + featuring · categories CRUD · all orders & statuses · review removal ·
report queue · home-page content · currency rates · shipping methods & country surcharges ·
discount offers.

## Adopt a Tree / Support a Farmer 🌿

A second pillar of Zeitoun alongside the marketplace: symbolic sponsorship of a real olive tree
or direct support for a farmer, with season tracking, updates and a digital certificate.

### Pages

| Route | Purpose |
|---|---|
| `/adopt` | Hero, impact stats, programs, verified tree cards, farmers, how-it-works, FAQ |
| `/trees/:treeCode` | Tree page: gallery, `ZT-TREE-000127` ID, story, season timeline, updates, QR, adopt |
| `/farmers` · `/farmers/:slug` | Farmer directory and profile (story, trees, programs, products, support) |
| `/my-trees` | Sponsor dashboard: progress, rename (3× limit), renew, cancel, updates feed |
| `/certificate/:code` | Printable digital certificate with QR → public tree page (owner/admin only) |
| `/dashboard/seller?tab=trees` | Farmer: add/edit trees, advance season phase, publish updates, see sponsors |
| `/dashboard/admin?tab=adoption` | 8 sub-tabs: analytics, trees, programs, farmers, sponsorships, updates, certificates, gift occasions |

### Guardrails built in

- **Transparency**: the wording is *symbolic sponsorship / care*, never ownership. The disclaimer
  "Adoption does not grant legal ownership of the land or the tree" is shown on the program,
  in checkout and on every certificate. Yield wording is program-level, never promised per tree.
- **Anti-fraud**: farmer-added trees are created `under_review` + `verified = false` and are
  invisible publicly (list *and* detail 404) until an admin verifies them → "Zeitoun Verified Tree".
- **Privacy**: only region/village is public — no GPS, no phone, no address, no financials.
  The farmer's sponsor list shows first names only.
- **Pricing control**: farmers cannot set program prices; admins grant `allowPriceOverride`
  per farmer-program (`farmer_support_programs`).
- **Order types**: `PRODUCT_ORDER`, `ADOPTION_ORDER`, `ADOPTION_AND_PRODUCT_ORDER` — adoption reuses
  the existing orders/payments/shipping stack (products in the same order get a real shipping quote).
- **Renewals**: manual renewal at `renewalPriceCents` (old adoption → `renewed`, new one linked via
  `renewedFromId`). No automatic recurring billing until a real payment gateway supports it.
- **Certificates**: `ZT-CERT-000001`, QR generated server-side (`qrcode`) → `/trees/:treeCode`,
  denormalized snapshot so certificates stay valid forever; gift certificates carry the recipient's name.

### Data model

`farmers`, `olive_trees`, `tree_images`, `tree_seasons`, `adoption_programs`,
`farmer_support_programs`, `adoptions`, `adoption_updates`, `adoption_certificates`,
`adoption_gifts`, `adoption_orders`, `gift_occasions` (+ `orders.order_type`).

Nine agricultural phases drive the timeline and notifications:
`season_start → growth → flowering → fruiting → ripening → harvest → pressing → packing → delivered`.

### Adoption API

```
GET  /api/trees?region=&farmer=&program=&q=&sort=&page=     GET /api/trees/:code
GET  /api/farmers                                          GET /api/farmers/:slug
GET  /api/adoption/programs | stats | occasions | updates | certificate?code= | qr?target=
POST /api/adoption/checkout            # program + tree/farmer + name + gift + optional products
GET  /api/adoptions                    # my sponsorships (+ renewSoon reminders)
GET/PATCH /api/adoptions/:id           # detail / rename / cancel
POST /api/adoptions/:id/renew
GET/POST/PUT/DELETE /api/farmer/status|trees|updates|sponsors|profile
GET/POST/PUT/DELETE /api/admin/adoption/analytics|trees|programs|farmers|adoptions|updates|certificates|occasions|farmer-programs
```

## Extensibility hooks (intentional seams)

- **Payments**: `src/app/api/checkout/route.ts` creates a `payments` row with a provider field.
  Card data is **never stored** (only `last4` in the mock). To go live: create a
  `PaymentProvider` interface (createPaymentIntent / verify) and wire Stripe or PayPal —
  no schema change needed.
- **Shipping**: rates are fully DB-driven (`shipping_methods`, `countries.surchargeCents`)
  and admin-editable. `src/lib/utils.ts → mockCarrier()/mockTrackingNumber()` are the swap
  points for Aramex/DHL/FedEx APIs; the `shipments.events` jsonb already models tracking events.
- **FX**: `currencies.rate_per_usd` is admin-editable; implement
  `fetchExternalRates()` in `src/lib/utils.ts` to pull live rates into the table.
- **Email**: forgot-password currently returns the code in the API response (mock mode).
  Replace with your EMAIL provider in `src/app/api/auth/[...path]/route.ts`.

## API endpoints (primary)

```
POST /api/auth/register | login | logout | google | forgot | reset     GET /api/auth/me
GET  /api/products?q=&category=&seller=&region=&min=&max=&minRating=&intl=1&stock=1&sort=&page=
GET/PATCH/DELETE /api/products/:slug        POST /api/products (seller)
GET/POST/PUT/DELETE /api/categories         GET /api/meta               POST /api/shipping
POST /api/checkout                          GET /api/orders?scope=me|seller
GET/PATCH /api/orders/:id                   POST /api/reviews           DELETE /api/reviews/:id (admin)
GET/POST/DELETE /api/favorites              GET/POST/PUT/DELETE /api/addresses
GET/PUT /api/notifications                  GET/POST /api/messages      GET /api/messages/thread?cid=
POST /api/sellers (application)             GET /api/seller/status|stats|products    PUT /api/seller
GET /api/admin/stats|users|applications|sellers|products|orders|reviews|reports|content|currencies|shipping|offers
PUT/DELETE /api/admin/...                   POST /api/reports
```

## Security

- bcrypt (cost 10) password hashing; JWT httpOnly cookies; no secrets in client bundles
- Role checks on every mutating endpoint; ownership checks on orders/messages/favorites
- Rate limiting on auth endpoints (per-IP, in-memory)
- Input validation/sanitization on all APIs; URL allow-list for image fields
- No card data persisted; demo payment is an explicit mock

## Deployment

1. Set `DATABASE_URL`, `AUTH_SECRET` (strong random) and any provider keys.
2. `npx drizzle-kit push` (or generate migrations with `npx drizzle-kit generate` and migrate).
3. `npm run build && npm start`.
4. Serve over HTTPS (cookies use `secure` in production).
